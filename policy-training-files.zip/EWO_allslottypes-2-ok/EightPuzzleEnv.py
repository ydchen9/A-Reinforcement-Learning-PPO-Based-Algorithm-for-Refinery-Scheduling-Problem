#coding:UTF-8
#八数码问题的环境
# import gym
import numpy as np
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
from Env_PRO_solve import PRO_opt_TT
from refinery_1MiniS_211_0FS3_solve_allslottypes import refinery as PRO2
import sys
from tabulate import tabulate
import xlwt

numOC_g = 5
numOC_d = 3
numO_g = 5
numO_d = 3
numU = 9
numM = 4
numS = 4
numO = 8
numOC = 8
numP = 4
hours = 1
Mlist = range(numM)
Ulist = range(numU)
Slist = range(numS)
Plist = range(numP)
OClist = range(numOC)
Olist = range(numO)
TTlist = [3, 2, 1]
OPC = 3.88   # crude oil cost per ton388.2
apoc =  0.5  # inv cost50.0
apo =  0.75   # inv cost75.0
bp = 300  # penalty for stockout of order l per ton30000.
# OPC = 388.2
# apoc =  50.0
# apo =  75.0
# bp = 30000.
OpCost = [11.,11.5,0.,0.,
          11.,11.5,0.,0.,
          58.,57.,56.5,56.,
          49.56,47.11,46.7,44.66,
          28.98,27.18,26.73,24.48,
          9.,8., 0., 0.,
          11.,10., 0., 0.,
          83.,0.,0.,0.,
          13.84,0.,0.,0.] # numU*numM

def write_test_order(all_numL1, all_DV1, all_DS_num, all_OCtank_ini, all_Otank_ini):
    book = xlwt.Workbook(encoding='utf-8', style_compression=0)
    sheet = book.add_sheet('test_case', cell_overwrite_ok=True)
    # numL1
    sheet.write(0, 0, "numL1")
    n1 = 1
    for L in range(len(all_numL1)):
        sheet.write(0, L + 1, all_numL1[L])
    sheet.write(0, 0, "numL1")
    # numDV1
    n2 = np.sum(all_numL1)
    for L in range(len(all_DV1)):
        for l in range(all_numL1[L]):
            sheet.write(int(n1+1 + np.sum(all_numL1[:L])), 0, "case"+str(L))
            for c in range(numO):
                sheet.write(int(n1+1 + np.sum(all_numL1[:L])+l), c + 1, all_DV1[L][l,c])
    # DS_num
    n3 = np.sum(all_numL1)
    for L in range(len(all_DS_num)):
        for l in range(all_numL1[L]):
            sheet.write(int(n1+1 + n2+1 + np.sum(all_numL1[:L])), 0, "case"+str(L))
            for c in range(2):
                sheet.write(int(n1+1 + n2+1 + np.sum(all_numL1[:L])+l), c + 1, all_DS_num[L][l,c])
    # OCtank_ini
    n4 = len(all_numL1)
    for L in range(n4):
            sheet.write(int(n1+1 + n2+1 + n3+1 + L), 0, "case"+str(L))
            for c in range(numO):
                sheet.write(int(n1+1 + n2+1 + n3+1 + L), c + 1, all_OCtank_ini[L][c])
    # Otank_ini
    n5 = len(all_numL1)
    for L in range(n5):
            sheet.write(int(n1+1 + n2+1 + n3+1 + n4+1 + L), 0, "case"+str(L))
            for c in range(numO):
                sheet.write(int(n1+1 + n2+1 + n3+1 + n4+1 + L), c + 1, all_Otank_ini[L][c])
    book.save('reward_test' + '.xls')#Order_test_case

class EightPuzzleEnv():
    def __init__(self):
        self.numT = 0
        self.ActionDim=8
        self.Statelength=176
        self.MageDim=[2, 8, 12]
        self.Mode_Unit = 0
        self.numL1 = 0
        self.H = [[]] * 6
        self.solution = 0

    def FeasibleMode(self, Mode):
        for u in [0, 1]:
            TT = 0
            for t in self.Tlist[1:]:
                if t >= self.numT - TTlist[0]:
                    Mode[u, :, t] = Mode[u, :, t - 1]
                elif TT > 0:
                    Mode[u, :, t] = Mode[u, :, t - 1]
                    TT -= 1
                elif np.argmax(Mode[u, :, t]) != np.argmax(Mode[u, :, t - 1]):
                    TT = TTlist[0]
        for u in [2, 3, 4]:
            TT = 0
            for t in self.Tlist[1:]:
                if t >= self.numT - TTlist[1]:
                    Mode[u, :, t] = Mode[u, :, t - 1]
                elif TT > 0:
                    Mode[u, :, t] = Mode[u, :, t - 1]
                    TT -= 1
                elif np.argmax(Mode[u, :, t]) != np.argmax(Mode[u, :, t - 1]):
                    TT = TTlist[1]
        for u in [5, 6]:
            TT = 0
            for t in self.Tlist[1:]:
                if t >= self.numT - TTlist[2]:
                    Mode[u, :, t] = Mode[u, :, t - 1]
                elif TT > 0:
                    Mode[u, :, t] = Mode[u, :, t - 1]
                    TT -= 1
                elif np.argmax(Mode[u, :, t]) != np.argmax(Mode[u, :, t - 1]):
                    TT = TTlist[2]
        return Mode

    def initOrder(self,):
        if self.numT == 100:
            epoch = self.H[0].pop()
            print "order case:", epoch,
            OCtank_ini_1 = np.random.randint(0, 10, (numOC_g))
            OCtank_ini_2 = np.random.randint(0, 20, (numOC_d))
            OCtank_ini = np.hstack((OCtank_ini_1, OCtank_ini_2))
            Otank_ini_1 = np.random.randint(0, 10, (numO_g))
            Otank_ini_2 = np.random.randint(0, 20, (numO_d))
            Otank_ini = np.hstack((Otank_ini_1, Otank_ini_2))
            gaso_lo = 20
            dies_lo = 80
            gaso_up = 90
            dies_up = 210
            if epoch % 9 == 0:
                numL1_1 = 6
                numL1_2 = 4
                numL1_3 = 4
                # numL1_1 = np.random.randint(10, 14)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 1:
                numL1_1 = 7
                numL1_2 = 4
                numL1_3 = 4
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(10, 14)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 2:
                numL1_1 = 7
                numL1_2 = 5
                numL1_3 = 4
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(10, 14)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 3:
                numL1_1 = 8
                numL1_2 = 5
                numL1_3 = 4
                # numL1_1 = np.random.randint(9, 12)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 12)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(6, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 4:
                numL1_1 = 8
                numL1_2 = 5
                numL1_3 = 5
                # numL1_1 = np.random.randint(9, 12)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 11)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 5:
                numL1_1 = 9
                numL1_2 = 5
                numL1_3 = 5
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 12)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 11)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 6:
                numL1_1 = 9
                numL1_2 = 6
                numL1_3 = 5
                # numL1_1 = np.random.randint(8, 11)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(8, 11)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 10)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 7:
                numL1_1 = 8
                numL1_2 = 6
                numL1_3 = 6
                # numL1_1 = np.random.randint(9, 11)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 11)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(6, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 8:
                numL1_1 = 6
                numL1_2 = 6
                numL1_3 = 7
                # numL1_1 = np.random.randint(10, 14)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            if epoch in range(9):
                DS_num = np.zeros((numL1, 2))
                DS_num[0, 0] = 0
                DS_num[0, 1] = np.random.randint(40, self.numT)
                if numL1_1 == 0:
                    Llist1_1A = []
                else:
                    Llist1_1A = Llist1_1[1:]
                for L1 in Llist1_1A:  # start from 0-70; end randomly
                    DS_num[L1, 0] = np.random.randint(0, 40)  # 70 - 5
                    DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 10, self.numT - 30)

                if numL1_1 == 0 and numL1_2 != 0:
                    Llist1_2A = Llist1_2[1:]
                else:
                    Llist1_2A = Llist1_2
                for L2 in Llist1_2A:  # start from 70-140; end randomly
                    DS_num[L2 + numL1_1, 0] = np.random.randint(40, 70)  #
                    DS_num[L2 + numL1_1, 1] = np.random.randint(DS_num[L2 + numL1_1, 0] + 10, self.numT - 15)

                if numL1_1 == 0 and numL1_2 == 0 and numL1_3 != 0:
                    Llist1_3A = Llist1_3[1:]
                else:
                    Llist1_3A = Llist1_3
                for L3 in Llist1_3A:  # start from 140-200; end randomly
                    DS_num[L3 + numL1_1 + numL1_2, 0] = np.random.randint(70, 85)  #
                    DS_num[L3 + numL1_1 + numL1_2, 1] = np.random.randint(DS_num[L3 + numL1_1 + numL1_2, 0] + 10, self.numT)
            DS1 = np.zeros((numL1, self.numT))
            for L1 in Llist1:
                DS1[L1, DS_num[L1, 0].astype(int):DS_num[L1, 1].astype(int) + 1] = 1
            FOout = np.zeros((numL1, numO_g + numO_d))
            Self_numL1 = numL1
            print "numL1:", numL1,
            # write_test_order([Self_numL1], [DV1], [DS_num], [OCtank_ini], [Otank_ini])
        elif self.numT == 120:
            epoch = self.H[1].pop()
            print "order case:", epoch,
            OCtank_ini_1 = np.random.randint(0, 10, (numOC_g))
            OCtank_ini_2 = np.random.randint(0, 20, (numOC_d))
            OCtank_ini = np.hstack((OCtank_ini_1, OCtank_ini_2))
            Otank_ini_1 = np.random.randint(0, 10, (numO_g))
            Otank_ini_2 = np.random.randint(0, 20, (numO_d))
            Otank_ini = np.hstack((Otank_ini_1, Otank_ini_2))
            gaso_lo = 20
            dies_lo = 80
            gaso_up = 90
            dies_up = 210
            if epoch % 9 == 0:
                numL1_1 = 6
                numL1_2 = 6
                numL1_3 = 4
                # numL1_1 = np.random.randint(10, 14)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 1:
                numL1_1 = 7
                numL1_2 = 6
                numL1_3 = 4
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(10, 14)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 2:
                numL1_1 = 7
                numL1_2 = 6
                numL1_3 = 5
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(10, 14)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 3:
                numL1_1 = 6
                numL1_2 = 7
                numL1_3 = 6
                # numL1_1 = np.random.randint(9, 12)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 12)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(6, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 4:
                numL1_1 = 6
                numL1_2 = 7
                numL1_3 = 7
                # numL1_1 = np.random.randint(9, 12)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 11)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 5:
                numL1_1 = 7
                numL1_2 = 7
                numL1_3 = 7
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 12)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 11)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 6:
                numL1_1 = 7
                numL1_2 = 8
                numL1_3 = 7
                # numL1_1 = np.random.randint(8, 11)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(8, 11)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 10)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 7:
                numL1_1 = 8
                numL1_2 = 8
                numL1_3 = 7
                # numL1_1 = np.random.randint(9, 11)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 11)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(6, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 8:
                numL1_1 = 7
                numL1_2 = 7
                numL1_3 = 9
                # numL1_1 = np.random.randint(10, 14)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            if epoch in range(9):
                DS_num = np.zeros((numL1, 2))
                DS_num[0, 0] = 0
                DS_num[0, 1] = np.random.randint(50, self.numT)
                if numL1_1 == 0:
                    Llist1_1A = []
                else:
                    Llist1_1A = Llist1_1[1:]
                for L1 in Llist1_1A:  # start from 0-70; end randomly
                    DS_num[L1, 0] = np.random.randint(0, 50)  # 70 - 5
                    DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 10, self.numT - 40)

                if numL1_1 == 0 and numL1_2 != 0:
                    Llist1_2A = Llist1_2[1:]
                else:
                    Llist1_2A = Llist1_2
                for L2 in Llist1_2A:  # start from 70-140; end randomly
                    DS_num[L2 + numL1_1, 0] = np.random.randint(40, 90)  #
                    DS_num[L2 + numL1_1, 1] = np.random.randint(DS_num[L2 + numL1_1, 0] + 10, self.numT - 15)

                if numL1_1 == 0 and numL1_2 == 0 and numL1_3 != 0:
                    Llist1_3A = Llist1_3[1:]
                else:
                    Llist1_3A = Llist1_3
                for L3 in Llist1_3A:  # start from 140-200; end randomly
                    DS_num[L3 + numL1_1 + numL1_2, 0] = np.random.randint(70, 105)  #
                    DS_num[L3 + numL1_1 + numL1_2, 1] = np.random.randint(DS_num[L3 + numL1_1 + numL1_2, 0] + 10, self.numT)
            DS1 = np.zeros((numL1, self.numT))
            for L1 in Llist1:
                DS1[L1, DS_num[L1, 0].astype(int):DS_num[L1, 1].astype(int) + 1] = 1
            FOout = np.zeros((numL1, numO_g + numO_d))
            Self_numL1 = numL1
            print "numL1:", numL1,
            # write_test_order([Self_numL1], [DV1], [DS_num], [OCtank_ini], [Otank_ini])
        elif self.numT == 140:
            epoch = self.H[2].pop()
            print "order case:", epoch,
            OCtank_ini_1 = np.random.randint(0, 10, (numOC_g))
            OCtank_ini_2 = np.random.randint(0, 20, (numOC_d))
            OCtank_ini = np.hstack((OCtank_ini_1, OCtank_ini_2))
            Otank_ini_1 = np.random.randint(0, 10, (numO_g))
            Otank_ini_2 = np.random.randint(0, 20, (numO_d))
            Otank_ini = np.hstack((Otank_ini_1, Otank_ini_2))
            gaso_lo = 20
            dies_lo = 80
            gaso_up = 90
            dies_up = 220
            if epoch % 9 == 0:
                numL1_1 = 8
                numL1_2 = 7
                numL1_3 = 4
                # numL1_1 = np.random.randint(10, 14)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 1:
                numL1_1 = 8
                numL1_2 = 7
                numL1_3 = 5
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(10, 14)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 2:
                numL1_1 = 7
                numL1_2 = 8
                numL1_3 = 6
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(10, 14)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 3:
                numL1_1 = 7
                numL1_2 = 7
                numL1_3 = 8
                # numL1_1 = np.random.randint(9, 12)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 12)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(6, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 4:
                numL1_1 = 8
                numL1_2 = 8
                numL1_3 = 7
                # numL1_1 = np.random.randint(9, 12)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 11)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 5:
                numL1_1 = 8
                numL1_2 = 8
                numL1_3 = 8
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 12)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 11)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 6:
                numL1_1 = 8
                numL1_2 = 9
                numL1_3 = 8
                # numL1_1 = np.random.randint(8, 11)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(8, 11)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 10)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 7:
                numL1_1 = 8
                numL1_2 = 8
                numL1_3 = 9
                # numL1_1 = np.random.randint(9, 11)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 11)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(6, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 8:
                numL1_1 = 7
                numL1_2 = 4
                numL1_3 = 8
                # numL1_1 = np.random.randint(10, 14)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            if epoch in range(9):
                DS_num = np.zeros((numL1, 2))
                DS_num[0, 0] = 0
                DS_num[0, 1] = np.random.randint(60, self.numT)
                if numL1_1 == 0:
                    Llist1_1A = []
                else:
                    Llist1_1A = Llist1_1[1:]
                for L1 in Llist1_1A:  # start from 0-70; end randomly
                    DS_num[L1, 0] = np.random.randint(0, 60)  # 70 - 5
                    DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 10, self.numT - 50)

                if numL1_1 == 0 and numL1_2 != 0:
                    Llist1_2A = Llist1_2[1:]
                else:
                    Llist1_2A = Llist1_2
                for L2 in Llist1_2A:  # start from 70-140; end randomly
                    DS_num[L2 + numL1_1, 0] = np.random.randint(50, 90)  #
                    DS_num[L2 + numL1_1, 1] = np.random.randint(DS_num[L2 + numL1_1, 0] + 10, self.numT - 15)

                if numL1_1 == 0 and numL1_2 == 0 and numL1_3 != 0:
                    Llist1_3A = Llist1_3[1:]
                else:
                    Llist1_3A = Llist1_3
                for L3 in Llist1_3A:  # start from 140-200; end randomly
                    DS_num[L3 + numL1_1 + numL1_2, 0] = np.random.randint(70, 125)  #
                    DS_num[L3 + numL1_1 + numL1_2, 1] = np.random.randint(DS_num[L3 + numL1_1 + numL1_2, 0] + 10, self.numT)
            DS1 = np.zeros((numL1, self.numT))
            for L1 in Llist1:
                DS1[L1, DS_num[L1, 0].astype(int):DS_num[L1, 1].astype(int) + 1] = 1
            FOout = np.zeros((numL1, numO_g + numO_d))
            Self_numL1 = numL1
            print "numL1:", numL1,
            # write_test_order([Self_numL1], [DV1], [DS_num], [OCtank_ini], [Otank_ini])
        elif self.numT == 160:
            epoch = self.H[3].pop()
            print "order case:", epoch,
            OCtank_ini_1 = np.random.randint(0, 10, (numOC_g))
            OCtank_ini_2 = np.random.randint(0, 20, (numOC_d))
            OCtank_ini = np.hstack((OCtank_ini_1, OCtank_ini_2))
            Otank_ini_1 = np.random.randint(0, 10, (numO_g))
            Otank_ini_2 = np.random.randint(0, 20, (numO_d))
            Otank_ini = np.hstack((Otank_ini_1, Otank_ini_2))
            if epoch % 9 == 0:
                gaso_lo = 15
                dies_lo = 80
                gaso_up = 90
                dies_up = 210
                numL1_1 = 9
                numL1_2 = 7
                numL1_3 = 6
                # numL1_1 = np.random.randint(10, 14)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 1:
                gaso_lo = 15
                dies_lo = 80
                gaso_up = 90
                dies_up = 210
                numL1_1 = 9
                numL1_2 = 7
                numL1_3 = 7
                # numL1_1 = np.random.randint(10, 14)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 2:
                gaso_lo = 15
                dies_lo = 80
                gaso_up = 90
                dies_up = 210
                numL1_1 = 9
                numL1_2 = 8
                numL1_3 = 7
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(10, 14)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 3:
                gaso_lo = 15
                dies_lo = 80
                gaso_up = 90
                dies_up = 210
                numL1_1 = 10
                numL1_2 = 8
                numL1_3 = 7
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(10, 14)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 4:
                gaso_lo = 15
                dies_lo = 80
                gaso_up = 90
                dies_up = 210
                numL1_1 = 10
                numL1_2 = 8
                numL1_3 = 8
                # numL1_1 = np.random.randint(9, 12)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 12)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(6, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 5:
                gaso_lo = 20
                dies_lo = 80
                gaso_up = 90
                dies_up = 220
                numL1_1 = 11
                numL1_2 = 8
                numL1_3 = 8
                # numL1_1 = np.random.randint(9, 12)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 11)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 6:
                gaso_lo = 20
                dies_lo = 80
                gaso_up = 90
                dies_up = 220
                numL1_1 = 11
                numL1_2 = 9
                numL1_3 = 8
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 12)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 11)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 7:
                gaso_lo = 15
                dies_lo = 70
                gaso_up = 90
                dies_up = 220
                numL1_1 = 12
                numL1_2 = 8
                numL1_3 = 9
                # numL1_1 = np.random.randint(8, 11)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(8, 11)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 10)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 8:
                gaso_lo = 15
                dies_lo = 70
                gaso_up = 90
                dies_up = 220
                numL1_1 = 10
                numL1_2 = 9
                numL1_3 = 10
                # numL1_1 = np.random.randint(9, 11)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 11)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(6, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            if epoch in range(9):
                DS_num = np.zeros((numL1, 2))
                DS_num[0, 0] = 0
                DS_num[0, 1] = np.random.randint(60, self.numT)
                if numL1_1 == 0:
                    Llist1_1A = []
                else:
                    Llist1_1A = Llist1_1[1:]
                for L1 in Llist1_1A:  # start from 0-70; end randomly
                    DS_num[L1, 0] = np.random.randint(0, 60)  # 70 - 5
                    DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 10, self.numT - 70)

                if numL1_1 == 0 and numL1_2 != 0:
                    Llist1_2A = Llist1_2[1:]
                else:
                    Llist1_2A = Llist1_2
                for L2 in Llist1_2A:  # start from 70-140; end randomly
                    DS_num[L2 + numL1_1, 0] = np.random.randint(50, 100)  #
                    DS_num[L2 + numL1_1, 1] = np.random.randint(DS_num[L2 + numL1_1, 0] + 10, self.numT - 35)

                if numL1_1 == 0 and numL1_2 == 0 and numL1_3 != 0:
                    Llist1_3A = Llist1_3[1:]
                else:
                    Llist1_3A = Llist1_3
                for L3 in Llist1_3A:  # start from 140-200; end randomly
                    DS_num[L3 + numL1_1 + numL1_2, 0] = np.random.randint(90, 140)  #
                    DS_num[L3 + numL1_1 + numL1_2, 1] = np.random.randint(DS_num[L3 + numL1_1 + numL1_2, 0] + 15, self.numT)
            DS1 = np.zeros((numL1, self.numT))
            for L1 in Llist1:
                DS1[L1, DS_num[L1, 0].astype(int):DS_num[L1, 1].astype(int) + 1] = 1
            FOout = np.zeros((numL1, numO_g + numO_d))
            Self_numL1 = numL1
            print "numL1:", numL1,
            # write_test_order([Self_numL1], [DV1], [DS_num], [OCtank_ini], [Otank_ini])
        elif self.numT == 180:
            epoch = self.H[4].pop()
            print "order case:", epoch,
            OCtank_ini_1 = np.random.randint(0, 10, (numOC_g))
            OCtank_ini_2 = np.random.randint(0, 20, (numOC_d))
            OCtank_ini = np.hstack((OCtank_ini_1, OCtank_ini_2))
            Otank_ini_1 = np.random.randint(0, 10, (numO_g))
            Otank_ini_2 = np.random.randint(0, 20, (numO_d))
            Otank_ini = np.hstack((Otank_ini_1, Otank_ini_2))
            if epoch % 9 == 0:
                gaso_lo = 15
                dies_lo = 90
                gaso_up = 90
                dies_up = 220
                numL1_1 = 10
                numL1_2 = 7
                numL1_3 = 7
                # numL1_1 = np.random.randint(10, 14)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 1:
                gaso_lo = 15
                dies_lo = 90
                gaso_up = 90
                dies_up = 220
                numL1_1 = 10
                numL1_2 = 7
                numL1_3 = 7
                # numL1_1 = np.random.randint(10, 14)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 2:
                gaso_lo = 15
                dies_lo = 80
                gaso_up = 90
                dies_up = 220
                numL1_1 = 10
                numL1_2 = 8
                numL1_3 = 7
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(10, 14)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 3:
                gaso_lo = 15
                dies_lo = 80
                gaso_up = 90
                dies_up = 220
                numL1_1 = 11
                numL1_2 = 8
                numL1_3 = 7
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(10, 14)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 4:
                gaso_lo = 15
                dies_lo = 80
                gaso_up = 90
                dies_up = 230
                numL1_1 = 11
                numL1_2 = 8
                numL1_3 = 8
                # numL1_1 = np.random.randint(9, 12)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 12)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(6, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 5:
                gaso_lo = 20
                dies_lo = 80
                gaso_up = 90
                dies_up = 250
                numL1_1 = 12
                numL1_2 = 8
                numL1_3 = 8
                # numL1_1 = np.random.randint(9, 12)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 11)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 6:
                gaso_lo = 20
                dies_lo = 80
                gaso_up = 90
                dies_up = 250
                numL1_1 = 12
                numL1_2 = 9
                numL1_3 = 8
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 12)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 11)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 7:
                gaso_lo = 20
                dies_lo = 80
                gaso_up = 90
                dies_up = 250
                numL1_1 = 12
                numL1_2 = 9
                numL1_3 = 9
                # numL1_1 = np.random.randint(8, 11)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(8, 11)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 10)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 8:
                gaso_lo = 20
                dies_lo = 80
                gaso_up = 90
                dies_up = 250
                numL1_1 = 12
                numL1_2 = 9
                numL1_3 = 9
                # numL1_1 = np.random.randint(9, 11)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 11)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(6, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            if epoch in range(9):
                DS_num = np.zeros((numL1, 2))
                DS_num[0, 0] = 0
                DS_num[0, 1] = np.random.randint(60, self.numT)
                if numL1_1 == 0:
                    Llist1_1A = []
                else:
                    Llist1_1A = Llist1_1[1:]
                for L1 in Llist1_1A:  # start from 0-70; end randomly
                    DS_num[L1, 0] = np.random.randint(0, 60)  # 70 - 5
                    DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 10, self.numT - 70)

                if numL1_1 == 0 and numL1_2 != 0:
                    Llist1_2A = Llist1_2[1:]
                else:
                    Llist1_2A = Llist1_2
                for L2 in Llist1_2A:  # start from 70-140; end randomly
                    DS_num[L2 + numL1_1, 0] = np.random.randint(50, 120)  #
                    DS_num[L2 + numL1_1, 1] = np.random.randint(DS_num[L2 + numL1_1, 0] + 10, self.numT - 35)

                if numL1_1 == 0 and numL1_2 == 0 and numL1_3 != 0:
                    Llist1_3A = Llist1_3[1:]
                else:
                    Llist1_3A = Llist1_3
                for L3 in Llist1_3A:  # start from 140-200; end randomly
                    DS_num[L3 + numL1_1 + numL1_2, 0] = np.random.randint(100, 160)  #
                    DS_num[L3 + numL1_1 + numL1_2, 1] = np.random.randint(DS_num[L3 + numL1_1 + numL1_2, 0] + 15, self.numT)
            DS1 = np.zeros((numL1, self.numT))
            for L1 in Llist1:
                DS1[L1, DS_num[L1, 0].astype(int):DS_num[L1, 1].astype(int) + 1] = 1
            FOout = np.zeros((numL1, numO_g + numO_d))
            Self_numL1 = numL1
            print "numL1:", numL1,
            # write_test_order([Self_numL1], [DV1], [DS_num], [OCtank_ini], [Otank_ini])
        elif self.numT == 200:
            epoch = self.H[5].pop()
            print "order case:", epoch,
            OCtank_ini_1 = np.random.randint(0, 10, (numOC_g))
            OCtank_ini_2 = np.random.randint(0, 20, (numOC_d))
            OCtank_ini = np.hstack((OCtank_ini_1, OCtank_ini_2))
            Otank_ini_1 = np.random.randint(0, 10, (numO_g))
            Otank_ini_2 = np.random.randint(0, 20, (numO_d))
            Otank_ini = np.hstack((Otank_ini_1, Otank_ini_2))
            if epoch % 9 == 0:
                gaso_lo = 15
                dies_lo = 90
                gaso_up = 100
                dies_up = 220
                numL1_1 = 11
                numL1_2 = 8
                numL1_3 = 7
                # numL1_1 = np.random.randint(10, 14)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 1:
                gaso_lo = 15
                dies_lo = 90
                gaso_up = 100
                dies_up = 220
                numL1_1 = 10
                numL1_2 = 7
                numL1_3 = 8
                # numL1_1 = np.random.randint(10, 14)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 2:
                gaso_lo = 15
                dies_lo = 90
                gaso_up = 100
                dies_up = 220
                numL1_1 = 10
                numL1_2 = 8
                numL1_3 = 7
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(10, 14)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(7, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 3:
                gaso_lo = 15
                dies_lo = 90
                gaso_up = 100
                dies_up = 220
                numL1_1 = 11
                numL1_2 = 8
                numL1_3 = 7
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(10, 14)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 4:
                gaso_lo = 15
                dies_lo = 90
                gaso_up = 100
                dies_up = 230
                numL1_1 = 11
                numL1_2 = 8
                numL1_3 = 8
                # numL1_1 = np.random.randint(9, 12)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 12)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(6, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 5:
                gaso_lo = 20
                dies_lo = 100
                gaso_up = 100
                dies_up = 250
                numL1_1 = 12
                numL1_2 = 8
                numL1_3 = 8
                # numL1_1 = np.random.randint(9, 12)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(7, 9)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 11)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 6:
                gaso_lo = 20
                dies_lo = 100
                gaso_up = 100
                dies_up = 250
                numL1_1 = 12
                numL1_2 = 9
                numL1_3 = 8
                # numL1_1 = np.random.randint(7, 9)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 12)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 11)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 7:
                gaso_lo = 20
                dies_lo = 100
                gaso_up = 100
                dies_up = 250
                numL1_1 = 12
                numL1_2 = 9
                numL1_3 = 9
                # numL1_1 = np.random.randint(8, 11)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(8, 11)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(8, 10)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            elif epoch % 9 == 8:
                gaso_lo = 20
                dies_lo = 100
                gaso_up = 100
                dies_up = 250
                numL1_1 = 13
                numL1_2 = 9
                numL1_3 = 9
                # numL1_1 = np.random.randint(9, 11)  # for 1-6
                Llist1_1 = range(numL1_1)
                # numL1_2 = np.random.randint(9, 11)  # for 1-6
                Llist1_2 = range(numL1_2)
                # numL1_3 = np.random.randint(6, 9)  # for 1-6
                Llist1_3 = range(numL1_3)
                numL1 = numL1_1 + numL1_2 + numL1_3
                Llist1 = range(numL1)

                DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
                DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
                DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
                DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
                DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
                DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
                DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
                DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
                DV1 = np.hstack((DV1_g, DV1_d))
            if epoch in range(9):
                DS_num = np.zeros((numL1, 2))
                DS_num[0, 0] = 0
                DS_num[0, 1] = np.random.randint(100, self.numT)
                if numL1_1 == 0:
                    Llist1_1A = []
                else:
                    Llist1_1A = Llist1_1[1:]
                for L1 in Llist1_1A:  # start from 0-70; end randomly
                    DS_num[L1, 0] = np.random.randint(0, 60)#70 - 5
                    DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 10, self.numT-70)

                if numL1_1 == 0 and numL1_2 != 0:
                    Llist1_2A = Llist1_2[1:]
                else:
                    Llist1_2A = Llist1_2
                for L2 in Llist1_2A:  # start from 70-140; end randomly
                    DS_num[L2+numL1_1, 0] = np.random.randint(60, 120)#
                    DS_num[L2+numL1_1, 1] = np.random.randint(DS_num[L2+numL1_1, 0] + 10, self.numT-25)

                if numL1_1 == 0 and numL1_2 == 0 and numL1_3 != 0:
                    Llist1_3A = Llist1_3[1:]
                else:
                    Llist1_3A = Llist1_3
                for L3 in Llist1_3A:  # start from 140-200; end randomly
                    DS_num[L3+numL1_1+numL1_2, 0] = np.random.randint(120, 170)#
                    DS_num[L3+numL1_1+numL1_2, 1] = np.random.randint(DS_num[L3+numL1_1+numL1_2, 0] + 15, self.numT)
            DS1 = np.zeros((numL1, self.numT))
            for L1 in Llist1:
                DS1[L1, DS_num[L1, 0].astype(int):DS_num[L1, 1].astype(int) + 1] = 1
            FOout = np.zeros((numL1, numO_g + numO_d))
            Self_numL1 = numL1
            print "numL1:", numL1,
            # write_test_order([Self_numL1], [DV1], [DS_num], [OCtank_ini], [Otank_ini])

        return Self_numL1, DV1, DS_num, OCtank_ini, Otank_ini, DS1, FOout

    def reset(self, numT):
        '''
          重置订单
        '''
        self.numT = numT
        self.Tlist = range(self.numT)
        self.Mode_Unit = np.zeros((numU, numM, self.numT))
        for i in range(6):
            if self.H[i] == []:
                self.H[i] = np.random.permutation(9).tolist()
        return self.initOrder()
    def reset_eval(self, numT):
        '''
          验证时重置订单
        '''
        self.numT = numT
        self.Tlist = range(self.numT)
        self.Mode_Unit = np.zeros((numU, numM, self.numT))

    def step(self, t, numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, FOout, action, evaluate_is):
        # calculate next Env and Reward.
        results_par = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
        mode_T = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                  0, 0]
        T_state = [0, 0, 0, 0, 0, 0, 0, 0, 0]
        T_Yield = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                   0, 0]
        T_OpCost = [0, 0, 0, 0, 0, 0, 0, 0, 0]
        Llist1 = range(numL1)
        if t == 0:
            self.DV1 = np.copy(DV1_left).astype("float32")
            self.OCtank_ini = np.copy(OCtank_ini).astype("float32").tolist()
            self.Otank_ini = np.copy(Otank_ini).astype("float32").tolist()
        OC_inventory_last = OCtank_ini
        O_inventory_last = Otank_ini
        Pri = 0
        DS1 = np.zeros((numL1, self.numT))
        for L1 in Llist1:
            DS1[L1, DS_num[L1, 0].astype(int):DS_num[L1, 1].astype(int) + 1] = 1
        DV1_left = DV1_left - FOout
        try:
            OC_inventory, O_inventory, FOout, Mode_act, Fin = PRO_opt_TT(self.numT,t,numL1,range(numL1),Pri,DV1_left,DS1,
                                            DS_num,OCtank_ini,Otank_ini,action.tolist(),results_par,mode_T,T_state,T_Yield,T_OpCost)
        except:
            print "################ PRO_TT no solution. t:",t
            print "numL1:",numL1
            print "PRO_TT:",OCtank_ini,Otank_ini,action.tolist()
            # print "PRO_TT:",DV1_left
            # sys.exit(0)
        else:
            self.Mode_Unit[:, :, t] = np.array(Mode_act).reshape((numU, numM))  # Mcount = numU * numM in PRO_opt.
            solution_exist = 1
            if t != self.numT-1:
                # reward = self.Reward(OC_inventory_last, O_inventory_last,OC_inventory, O_inventory, FOout, Mode_act, Fin)
                reward = 0
            else:
                # self.numT, Tlist, numL, Llist, DS1, DV1, Pri, DS_num, OCtank_ini, Otank_ini, Mode
                Mode = self.FeasibleMode(self.Mode_Unit)
                # print "mode:",Mode.tolist()
                Mode = Mode.reshape((-1)).tolist()
                try:
                    print "numT:",self.numT,
                    OCinv, Oinv, Mode, FUin, FOout, reward = PRO2(self.numT, range(self.numT), numL1, range(numL1), DS1,
                                                            self.DV1, Pri, DS_num, self.OCtank_ini, self.Otank_ini, Mode,evaluate_is)

                    if evaluate_is == 1:
                        self.solution = reward
                        reward = self.Reward_last(OCinv, Oinv, Mode, FUin, FOout)
                    else:
                        self.solution = reward
                        reward = self.Reward_last(OCinv, Oinv, Mode, FUin, FOout)
                except:
                    print "####### PRO2 no solutions! #######"
                    solution_exist = 0
                    reward = 0
        return t+1, numL1, DV1_left, DS_num, np.array(OC_inventory), np.array(O_inventory), FOout, \
               reward, solution_exist,self.solution

    def Reward(self,OC_inventory_last, O_inventory_last,OC_inventory, O_inventory, FOout, Mode_act, Fin):
        '''
        奖励函数
        '''
        cost = 0
        cost += OPC*hours * (Fin[0]-200)
        cost += apo * np.sum(O_inventory - O_inventory_last)
        cost += apoc * np.sum(OC_inventory - OC_inventory_last)
        cost += -bp*hours * np.sum(FOout)
        for U in Ulist:
            cost += OpCost[U * numM + Mode_act[U]] * (Fin[U])

        return cost/np.sum(self.DV1) #

    def Reward_last(self,OCinv, Oinv, Mode, Fin, FOout):
        '''
        奖励函数
        '''
        Fin = np.array(Fin).reshape(numU,self.numT)
        OCinv = np.array(OCinv).reshape(numOC,self.numT)
        Oinv = np.array(Oinv).reshape(numO,self.numT)
        Mode = np.array(Mode).reshape(numU,numM,self.numT)
        # FOout = np.array(FOout).reshape(numO,self.numL1,self.numT)
        cost = 0
        CRO = 0
        for T in self.Tlist:
            CRO += Fin[0,T]
            cost += OPC*hours * (Fin[0,T]-200)
        # print "OPC:",cost
        INV = 0
        for T in self.Tlist:
            for O in Olist:
                if T == self.Tlist[-1]:  # initial invertory is zero
                    INV += Oinv[O,T]*0.5 * apo
                    # prob.objective.set_linear(O * self.numT + T + OINV_c, 0.5 * apo)
                else:
                    INV += Oinv[O,T] * apo
                    # prob.objective.set_linear(O * self.numT + T + OINV_c, apo)
            for OC in OClist:
                if T == self.Tlist[-1]:  # initial invertory is zero
                    INV += OCinv[OC,T]*0.5 * apoc
                    # prob.objective.set_linear(OC * self.numT + T + OCINV_c, 0.5 * apoc)
                else:
                    INV += OCinv[OC,T] * apoc
                    # prob.objective.set_linear(OC * self.numT + T + OCINV_c, apoc)
        cost += INV
        # print "OPC+inv:",cost
        Op_Cost = 0
        for U in Ulist:
            for T in self.Tlist:
                for M in Mlist:
                    Op_Cost += OpCost[U * numM + M] * Mode[U,M,T] * Fin[U,T]*0.01
        cost += Op_Cost
        # print "OPC+inv+op:",cost
        cost += -bp*hours * np.sum(FOout)
        # print "OPC+inv+op+stockout:",cost
        DV_sum = np.sum(self.DV1)
        cost += bp*hours * DV_sum
        # print "OPC+inv+op+stockout+DV:",cost
        # print "DV1:",DV_sum
        Re = cost/DV_sum  #(200.0/self.numT)*
        print "reward:",np.round(Re,6),"  CRO:",np.round(CRO,3),"  INV:",np.round(INV,3),"  OPC:", np.round(Op_Cost, 3), \
            "  DV:", np.round(DV_sum, 3), "  FOout:", np.round(np.sum(FOout),3),\
            "  objective value:", np.round(self.solution, 3)

        return Re
