# from __future__ import print_function
import cplex
from tabulate import tabulate
import numpy as np
import xlwt
import xlrd


numOC_g = 5
numOC_d = 3
numO_g = 5
numO_d = 3
OClist_g = range(numOC_g)
OClist_d = range(numOC_d)
Olist_g = range(numO_g)
Olist_d = range(numO_d)
MININPUT = [200.0, 0, 0, 5.0,   0, 5.0, 0, 0,   0]
MAXINPUT = [300.0]*9
FOCOmax = 100
PtVmax = 2000
C_order = 30000
numU = 9
numM = 4

# Pri = 1
# sample = 0
# Mode_Unit = 0
numS = 4
numO = 8
numO_g = 5
numO_d = 3
numOC = 8
numOC_g = 5
numOC_d = 3
numP = 4
hours = 1
numL = 3
# MAXINPUT = 300
Mlist = range(numM)
Ulist = range(numU)

Slist = range(numS)
Plist = range(numP)
OClist = range(numOC)
OCglist = range(numOC_g)
OCdlist = range(numOC_d)
Olist = range(numO)
Oglist = range(numO_g)
Odlist = range(numO_d)
Llist = range(numL)
TLlist = range(2) # TL1 and TL2
OPC = 388.2   # crude oil cost per ton
apoc = 50.0    # inv cost
apo = 75.0    # inv cost
bp = 30000.  # penalty for stockout of order l per ton
# PRO = [97,99.,96.,93.,89.,0.,0.,0.,
#        0.,0.,0.,0.,0.,48.,49.,59.,
#        0.0001,0.0002,0.0004,0.02,0.03,0.001,0.001,0.038,
#        0.,0.,0.,0.,0.,1.68,1.1,1.6] #P /RON,S,CN,CPF/  # PRO(P,OC)
PRO = [#96.,98.,99.,93.,89.,0.,0.,0.,
       83.,100.,117.,93.,90.,0.,0.,0.,
       #0.,0.,0.,0.,0.,48.,49.,59.,
       0.,0.,0.,0.,0.,47.,55.,48.,
       #0.0001,0.0002,0.0004,0.02,0.03,0.038,0.002,0.001,
       0.0001,0.0002,0.04,0.01,0.02,0.001,0.001,0.038,
       #0.0001,0.0001,0.05,0.01,0.01,0.038,0.002,0.001,
       0.,0.,0.,0.,0.,1.68,1.1,1.6] #P /RON,S,CN,CPF/  # PRO(P,OC)
# PRO = [94.,99.,94.,98.,89.,0.,0.,0.,
#        0.,0.,0.,0.,0.,48.,49.,59.,
#        0.0001,0.0002,0.0004,0.02,0.03,0.001,0.001,0.038,
#        0.,0.,0.,0.,0.,1.68,1.1,1.6] #P /RON,CN,S,CPF/  # PRO(P,OC)

PROMAX = [0.]*numP*numO
PROMAX[16:24] = [0.0005,0.0006,0.015,0.015,0.015,0.035,0.035,0.01] # PROMAX(P,O) S content unit is %
PROMAX[24:32] = [0.,0.,0.,0.,0.,1.6184,1.1995,1.6184]  # CPF(P,O)
PROMIN = [93.,97.,90.,93.,97.,0.,0.,0.,
          0.,0.,0.,0.,0.,49.,49.,51.,
          0.,0.,0.,0.,0.,0.,0.,0.,
          0.,0.,0.,0.,0.,0.,0.,0.] # PROMIN(P,O)

rMIN = [0.]*numOC*numO  #  rMIN(OC,O)

rMAX = [1.]*numOC*numO
rMAX[16:21] = [0.1]*5  # rMAX(OC,O)
TTlist = [3,2,1]
# case 1  2 orders ####
# DV = [[100.,400.,200.,100.,550.,1000.,600.,700.],
#       [200.,300.,100.,100.,700.,800.,700.,900.]] # numL*numO
# DT = [[1, 1, 1, 1, 1, 1, 0, 0], [0, 0, 1, 1, 1, 1, 1, 1]]
QIinputL = [200.,300.,0.,300.,0.,300.,5.,300.,0.,300.,5.,300.,0.,300.,0.,300.,0.,300.]  # numU*2
OCtankLmin = [0]*numOC
OCtankLmax = [4500]*numOC
OtankLmin = [0]*numO
OtankLmax = [2000]*numO
H = 300
H_E = 4500
FOout_MAX = 100
Yield = [0]*numU*numM*numS
Yieldlist = [7.008,15.349,8.109,64.534,4.576,19.403,9.267,61.754,
             11.286,37.352, 12.580,35.652,
             22.216, 5.02, 45.664, 23.104, 5.01, 42.583, 23.418, 4.15, 42.261, 26.683, 4.13, 39.580,
             98.1, 94.1, 93.2, 90,
             97., 88., 86.2, 79.,
             99.4, 99.4,
             9., 89., 4., 93.,
             10., 90.,
             120]
for U in [Ulist[0]]: # ATM
    for M in Mlist[0:2]:
        for S in Slist[0:4]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)*0.01
for U in [Ulist[1]]: # VDU
    for M in Mlist[0:2]:
        for S in Slist[0:2]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)*0.01
for U in [Ulist[0+2]]: # FCCU
    for M in Mlist:
        for S in Slist[0:3]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)*0.01
for U in [Ulist[1+2]]: # ETH
    for M in Mlist:
        for S in [Slist[0]]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)*0.01
for U in [Ulist[2+2]]:  # HDS
    for M in Mlist:
        for S in [Slist[0]]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)*0.01
for U in [Ulist[3+2]]:  # HTU1
    for M in Mlist[0:2]:
        for S in [Slist[0]]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)*0.01
for U in [Ulist[4+2]]:  # HTU2
    for M in Mlist[0:2]:
        for S in Slist[0:2]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)*0.01
for U in [Ulist[5+2]]:  # RF
    for M in [Mlist[0]]:
        for S in Slist[0:2]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)*0.01
for U in [Ulist[6+2]]:  # MTBE
    for M in [Mlist[0]]:
        for S in [Slist[0]]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)*0.01

# For Parameter tYieldlist
tYield = [0]*numU*numM*numM*numS
for U in [Ulist[0],Ulist[1]]: # ATM,VDU
    for M in Mlist[0:2]:
        for M1 in Mlist[0:2]:
            if M1 != M:
                for S in Slist[0:4]:
                    tYield[U*numM*numM*numS+M*numM*numS+M1*numS+S] = 0.5*(Yield[U*numM*numS+M*numS+S]+Yield[U*numM*numS+M1*numS+S])
for U in [Ulist[0+2]]: # FCCU
    for M in Mlist[0:4]:
        for M1 in Mlist[0:4]:
            if M1 != M:
                for S in Slist[0:3]:
                    tYield[U*numM*numM*numS+M*numM*numS+M1*numS+S] = 0.5*(Yield[U*numM*numS+M*numS+S]+Yield[U*numM*numS+M1*numS+S])
for U in [Ulist[1+2]]: # ETH
    for M in Mlist[0:4]:
        for M1 in Mlist[0:4]:
            if M1 != M:
                for S in [Slist[0]]:
                    tYield[U*numM*numM*numS+M*numM*numS+M1*numS+S] = 0.5*(Yield[U*numM*numS+M*numS+S]+Yield[U*numM*numS+M1*numS+S])
for U in [Ulist[2+2]]:  # HDS
    for M in Mlist[0:4]:
        for M1 in Mlist[0:4]:
            if M1 != M:
                for S in [Slist[0]]:
                    tYield[U*numM*numM*numS+M*numM*numS+M1*numS+S] = 0.5*(Yield[U*numM*numS+M*numS+S]+Yield[U*numM*numS+M1*numS+S])
for U in [Ulist[3+2]]:  # HTU1
    for M in Mlist[0:2]:
        for M1 in Mlist[0:2]:
            if M1 != M:
                for S in [Slist[0]]:
                    tYield[U*numM*numM*numS+M*numM*numS+M1*numS+S] = 0.5*(Yield[U*numM*numS+M*numS+S]+Yield[U*numM*numS+M1*numS+S])
for U in [Ulist[4+2]]:  # HTU2
    for M in Mlist[0:2]:
        for M1 in Mlist[0:2]:
            if M1 != M:
                for S in Slist[0:2]:
                    tYield[U*numM*numM*numS+M*numM*numS+M1*numS+S] = 0.5*(Yield[U*numM*numS+M*numS+S]+Yield[U*numM*numS+M1*numS+S])
OpCost = [11.,11.5,0.,0.,
          11.,11.5,0.,0.,
          58.,57.,56.5,56.,
          49.56,47.11,46.7,44.66,
          28.98,27.18,26.73,24.48,
          9.,8., 0., 0.,
          11.,10., 0., 0.,
          83.,0.,0.,0.,
          13.84,0.,0.,0.] # numU*numM
tOpCost = [0]*numU*numM*numM
# For Parameter tOpCostlist
for U in Ulist[0:2]:
    for M in Mlist[0:4]:
        for M1 in Mlist[0:4]:
            tOpCost[U*numM*numM+M*numM+M1] = 0.5*(OpCost[U*numM+M]+OpCost[U*numM+M1])+0
for U in Ulist[0+2:3+2]:
    for M in Mlist[0:4]:
        for M1 in Mlist[0:4]:
            tOpCost[U*numM*numM+M*numM+M1] = 0.5*(OpCost[U*numM+M]+OpCost[U*numM+M1])+0
for U in Ulist[3+2:5+2]:
    for M in Mlist[0:2]:
        for M1 in Mlist[0:2]:
            tOpCost[U*numM*numM+M*numM+M1] = 0.5*(OpCost[U*numM+M]+OpCost[U*numM+M1])+0

def PRO_opt_TT(numT_total,now_T,numL1,Llist1,Pri,DV1_left,DS1,DS_num,OCtank_ini,Otank_ini,results,results_par,mode_T,T_state,T_Yield,T_OpCost):#

    prob = cplex.Cplex("Env_PRO_oneslot-4500.sav")
    out = prob.set_results_stream(None)  # don't display the solution process.
    out = prob.set_log_stream(None)  # don't display the solution process.
    # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Production Scheduling
    # ====================================== Operation Variable FinM : input Flowrate of Units
    FinMcount = numU * numM
    FinM_c = 0
    FOCincount = numOC
    FOCin_c = FinM_c + FinMcount
    Mcount = numU * numM
    M_c = FOCin_c + FOCincount
    FOCOcount = numOC * numO
    FOCO_c = M_c + Mcount
    # FOoutcount = numO * numL1
    # FOout_c = FOCO_c + FOCOcount
    VOCcount = numOC
    VOC_c = FOCO_c + FOCOcount
    VOcount = numO
    VO_c = VOC_c + VOCcount
    Poutcount = (numOC)  # numO+1+
    Pout_c = VO_c + VOcount
    PoutAcount = (numOC)  # numO+1+
    PoutA_c = Pout_c + Poutcount
    Qoutcount = numOC
    Qout_c = PoutA_c + PoutAcount
    Oprocount = numO * numP
    Opro_c = Qout_c + Qoutcount
    # ====================================== Operation Variable FOout : output Flowrate of oil
    obj = [0] * numO * numL1
    ct = ['C'] * numO * numL1
    FOoutcount = numO * numL1
    FOout_c = Opro_c + Oprocount
    namey = []
    charlist = [str(i) for i in range(0, FOoutcount)]
    for i in charlist:
        namey.append('FOout' + i)
    prob.variables.add(obj=obj, types=ct, names=namey)

    # ================================= Volume State Function of component oil tank =================================
    #                                  State Function of Volume C5  ==================================================
    i = 0
    i += 1
    names = "Volume_C5 " + str(i)
    ind = []
    val = []
    ind.append(0 + VOC_c)  # OUT: inventory of T
    val.append(1.0)
    ind.append(Ulist[7]* numM + FinM_c)  # IN: from RF(7) M0T0 output
    val.append(-1.0 * hours * Yield[Ulist[7] * numM * numS + 0 * numS + 0])   # IN: from RF(7) M0S1 output
    for O in Olist[0:5]:
        ind.append(0 * numO + O + FOCO_c)  # OUT: to blend
        val.append(hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[0]], names=[names])
    #                                  State Function of Volume Ref  ==================================================
    i = 0
    i += 1
    names = "Volume_Ref " + str(i)
    ind = []
    val = []
    ind.append(1 + VOC_c)  # OUT: inventory of T
    val.append(1.0)
    ind.append(Ulist[7]* numM + FinM_c)  # IN: from RF(7) M0T0 output
    val.append(-1.0 * hours * Yield[Ulist[7] * numM * numS + 0 * numS + 1]) # IN: from RF(7) M0S2 output
    for O in Olist[0:5]:
        ind.append(1 * numO + O + FOCO_c)  # OUT: to blend
        val.append(hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[1]], names=[names])
    #                                  State Function of Volume MTBE  ==================================================
    i = 0
    i += 1
    names = "Volume_MTBE " + str(i)
    ind = []
    val = []
    ind.append(2 + VOC_c)  # OUT: inventory of T
    val.append(1.0)
    ind.append(Ulist[8]* numM + FinM_c)  # IN: from MTBE(8) M0T0 output
    val.append(-1.0 * hours * Yield[Ulist[8] * numM * numS + 0 * numS + 0])  # IN: from MTBE(8) M0S1 output
    for O in Olist[0:5]:
        ind.append(2 * numO + O + FOCO_c)  # OUT: to blend
        val.append(hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[2]], names=[names])
    #                                  State Function of Volume HDS_g  ================================================
    i = 0
    i += 1
    names = "Volume_HDS " + str(i)
    ind = []
    val = []
    ind.append(3 + VOC_c)  # OUT: inventory of T
    val.append(1.0)
    ind.append(OClist[3] + FOCin_c)  # IN: from OClist[3] T0 output
    val.append(-1.0)
    for O in Olist[0:5]:
        ind.append(3 * numO + O + FOCO_c)  # OUT: to blend
        val.append(hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[3]], names=[names])
    #                                  State Function of Volume Eth_g  ================================================
    i = 0
    i += 1
    names = "Volume_Eth_g " + str(i)
    ind = []
    val = []
    ind.append(4 + VOC_c)  # OUT: inventory of T
    val.append(1.0)
    for M in Mlist[0:4]:
        ind.append(Ulist[3]* numM + M + FinM_c)  # IN: from ETH(3)  T0 output   # IN: from ETH(3) S1 output
        val.append(-1.0 * hours * ((1-T_state[Ulist[3]])*Yield[Ulist[3] * numM * numS + M * numS + 0] +   # IN: from ETH(3) S1 output
                                   (T_state[Ulist[3]])*T_Yield[Ulist[3]*numS+0]))
    for O in Olist[0:5]:
        ind.append(4 * numO + O + FOCO_c)  # OUT: to blend
        val.append(hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[4]], names=[names])
    #                                  State Function of Volume Rd2  ================================================
    i = 0
    i += 1
    names = "Volume_Rd2 " + str(i)
    ind = []
    val = []
    ind.append(5 + VOC_c)  # OUT: inventory of T
    val.append(1.0)
    for M in Mlist[0:2]:
        ind.append(Ulist[6]* numM + M + FinM_c) # IN: from HTU2(6)   T0 output# IN: from HTU2(6) S2 output
        val.append(-1.0 * hours * ((1-T_state[Ulist[6]])*Yield[Ulist[6] * numM * numS + M * numS + 1]+  # IN: from HTU2(6) S2 output
                                   (T_state[Ulist[6]])*T_Yield[Ulist[6]*numS+1]))
    for O in Olist[5:8]:
        ind.append(5 * numO + O + FOCO_c)  # OUT: to blend
        val.append(hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[5]], names=[names])
    #                                  State Function of Volume Rd1  ================================================
    i = 0
    i += 1
    names = "Volume_Rd1 " + str(i)
    ind = []
    val = []
    ind.append(6 + VOC_c)  # OUT: inventory of T
    val.append(1.0)
    for M in Mlist[0:2]:
        ind.append(Ulist[5]* numM + M + FinM_c) # IN: from HTU1(5)   T0 output# IN: from HTU1(5) S1 output
        val.append(-1.0 * hours * ((1-T_state[Ulist[5]])*Yield[Ulist[5] * numM * numS + M * numS + 0]+  # IN: from HTU1(5) S1 output
                                   (T_state[Ulist[5]])*T_Yield[Ulist[5]*numS+0]))

    for O in Olist[5:8]:
        ind.append(6 * numO + O + FOCO_c)  # OUT: to blend
        val.append(hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[6]], names=[names])
    #                                  State Function of Volume Lsd  ================================================
    i = 0
    i += 1
    names = "Volume_Lsd " + str(i)
    ind = []
    val = []
    ind.append(7 + VOC_c)  # OUT: inventory of T
    val.append(1.0)
    ind.append(OClist[7] + FOCin_c)  # IN: from Fen1(9) S1 output
    val.append(-1.0*hours)
    for O in Olist[5:8]:
        ind.append(7 * numO + O + FOCO_c)  # OUT: to blend
        val.append(hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[7]], names=[names])

    # ================================= Volume State Function of production oil tank =============================
    #                                  Volume State Function of gasoline oil tank  ===============================
    for O in Olist[0:5]:
        i = 0
        i += 1
        names = "Volume_Otank" + str(O) + " " + str(i)
        ind = []
        val = []
        ind.append(O + VO_c)
        val.append(1.0)
        for OC in OClist[0:5]:
            ind.append(OC * numO + O + FOCO_c)
            val.append(-1.0 * hours)
        for L in Llist1:
            ind.append(O * numL1 + L + FOout_c)
            val.append(hours)
        prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[Otank_ini[O]], names=[names])
    #                                  Volume State Function of diesel oil tank  ===============================
    for O in Olist[5:8]:
        i = 0
        i += 1
        names = "Volume_Otank" + str(O) + " " + str(i)
        ind = []
        val = []
        ind.append(O + VO_c)
        val.append(1.0)
        for OC in OClist[5:8]:
            ind.append(OC * numO + O + FOCO_c)
            val.append(-1.0 * hours)
        for L in Llist1:
            ind.append(O * numL1 + L + FOout_c)
            val.append(hours)
        prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[Otank_ini[O]], names=[names])
    #                                  Order amount limit  ==========================================
    i = 0
    for O in Olist:
        for L in Llist1:
            i += 1
            names1 = "Order_amount " + str(i)
            ind = []
            val = []
            ind.append(O * numL1 + L + FOout_c)
            val.append(1.0)
            prob.linear_constraints.add(lin_expr=[[ind, val]],senses="L", rhs=[DV1_left[L][O]], names=[names1])
    i = 0
    for O in Olist:
        for L in Llist1:
            i += 1
            names1 = "Order_amount " + str(i)
            ind = []
            val = []
            ind.append(O * numL1 + L + FOout_c)
            val.append(1.0)
            prob.linear_constraints.add(lin_expr=[[ind, val]],senses="L", rhs=[DS1[L][now_T]*FOout_MAX], names=[names1])

    i = 0
    for OC in OClist:
        i += 1
        names = "Qout_abs_L " + str(i)
        prob.linear_constraints.add(lin_expr=[[[OC + Qout_c,OC + Pout_c],
                                               [1.0,-1.0]]], senses="L", rhs=[results[OC]], names=[names])
        names = "Qout_abs_G " + str(i)
        prob.linear_constraints.add(lin_expr=[[[OC + Qout_c,OC + Pout_c],
                                               [1.0,1.0]]], senses="G", rhs=[results[OC]], names=[names])

    prob.variables.set_lower_bounds(zip(range(FOout_c, FOoutcount + FOout_c), [0] * FOoutcount))
    #                                        Mode of transition limitation  ==========================================
    i = 0
    for U in [Ulist[0],Ulist[1],Ulist[5],Ulist[6]]:
        for M in Mlist[:2]:
            i += 1
            names1 = "ModeT_limit_AVHH " + str(i)
            ind = []
            val = []
            ind.append(U * numM + M + M_c)
            val.append(1.0)
            prob.linear_constraints.add(lin_expr=[[ind, val]],senses="G", rhs=[mode_T[U * numM + M]], names=[names1])
    i = 0
    for U in [Ulist[2],Ulist[3],Ulist[4]]:
        for M in Mlist:
            i += 1
            names1 = "ModeT_limit_FEH " + str(i)
            ind = []
            val = []
            ind.append(U * numM + M + M_c)
            val.append(1.0)
            prob.linear_constraints.add(lin_expr=[[ind, val]],senses="G", rhs=[mode_T[U * numM + M]], names=[names1])

    # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Objective Function @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    for L in Llist1:
        for O in Olist:
            prob.objective.set_linear(O * numL1 + L + FOout_c, -20 * (numT_total - DS_num[L][1]) - apo * 1.8)
    for OC in range(numOC):
        prob.objective.set_linear(OC + Pout_c, C_order*results_par[OC]*1.1)
    # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Solving @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    # prob.write('Env_PRO.lp')
    prob.solve()
    sol = prob.solution
    # print
    # solution.get_status() returns an integer code
    # print "Solution status = ", sol.get_status(), ":",sol.status[sol.get_status()]
    # the following line prints the corresponding string
    # print "Solution value  = ", sol.get_objective_value(), "\n"
    FinM = sol.get_values(FinM_c, FinM_c + FinMcount - 1)
    FOout = sol.get_values(FOout_c, FOout_c + FOoutcount - 1)
    OC_inventory = sol.get_values(VOC_c, VOC_c + VOCcount - 1)
    O_inventory = sol.get_values(VO_c, VO_c + VOcount - 1)
    Mode_act = np.rint(np.array(sol.get_values(M_c, M_c + Mcount - 1))).astype("int")
    FOout = np.array(FOout).reshape(numO,numL1).T

    if Pri == 1:
        numT = 1
        Tlist = range(numT)
        print "Banery number = ", prob.variables.get_num_binary()
        print "Variable number = ", prob.variables.get_num()
        print "Contraint number = ", prob.linear_constraints.get_num(), "\n"
        header = Tlist
        # FUin: numU*numT
        M = sol.get_values(M_c, M_c + Mcount - 1)
        FinM = sol.get_values(FinM_c, FinM_c + FinMcount - 1)
        FUin_header = header[:]
        FUin_header.insert(0, "FUin")
        FUin_table_ = [0] * (numT + 1)
        FUin_table = []
        for U in Ulist[0:9]:
            FUin_table.append(FUin_table_[:])
        print "Unit Input Flowrate:  "
        FUin_table[0][0] = "ATM"
        FUin_table[1][0] = "VDU"
        FUin_table[2][0] = "FCCU"
        FUin_table[3][0] = "ETH"
        FUin_table[4][0] = "HDS"
        FUin_table[5][0] = "HTU1"
        FUin_table[6][0] = "HTU2"
        FUin_table[7][0] = "RF"
        FUin_table[8][0] = "MTBE"
        for U in Ulist[0:9]:
            for Mode in Mlist:
                FUin_table[U][1] += FinM[U * numM + Mode]
        print tabulate(FUin_table, FUin_header, tablefmt="simple", numalign="center", floatfmt=".3f")

        # FUinM: numU*numM*numT
        FUinM3_header = header[:]
        FUinM3_header.insert(0, "FUin[3M]")
        FUinM3_table_ = [0] * (numT + 1)
        FUinM3_table = []
        for U in Ulist[0:9]:
            FUinM3_table.append(FUinM3_table_[:])
        print "Unit Input Flowrate of Three Modes:  "
        FUinM3_table[0][0] = "ATM"
        FUinM3_table[1][0] = "VDU"
        FUinM3_table[2][0] = "FCCU"
        FUinM3_table[3][0] = "ETH"
        FUinM3_table[4][0] = "HDS"
        FUinM3_table[5][0] = "HTU1"
        FUinM3_table[6][0] = "HTU2"
        FUinM3_table[7][0] = "RF"
        FUinM3_table[8][0] = "MTBE"
        for U in Ulist[0:9]:
            X = [0.0] * 3
            for Mode in Mlist:
                X[0] += round(FinM[U * numM + Mode], 3)
            FUinM3_table[U][1] = X
        print tabulate(FUinM3_table, FUinM3_header, tablefmt="simple", numalign="center", floatfmt=".3f")

        # Print Fout
        FOCin = sol.get_values(FOCin_c, FOCin_c + FOCincount - 1)
        Fout_header = header[:]
        Fout_header.insert(0, "Fout")
        Fout_table_ = [0] * (numT + 1)
        Fout_table = []
        for U in range(11):
            Fout_table.append(Fout_table_[:])
        print "Output flowrate of Units:  "
        Fout_table[0][0] = "ATM"
        Fout_table[1][0] = "VDU"
        Fout_table[2][0] = "FCCU"
        Fout_table[3][0] = "ETH"
        Fout_table[4][0] = "HDS"
        Fout_table[5][0] = "HTU1"
        Fout_table[6][0] = "HTU2"
        Fout_table[7][0] = "RF"
        Fout_table[8][0] = "MTBE"
        Fout_table[9][0] = "Fen1"
        Fout_table[10][0] = "Fen2"
        for U in [Ulist[2], Ulist[3], Ulist[4]]:
                S_all = []
                for S in Slist:
                    Y = 0
                    for Mode in Mlist:
                        if M[U * numM + Mode] >= 0.1 and Y == 0:
                            Y = Yield[U * numM * numS + Mode * numS + S]
                            break
                    S_all.append(round(FUin_table[U][1] * Y, 3))
                Fout_table[U][1] = S_all
        for U in [Ulist[0], Ulist[1], Ulist[5], Ulist[6]]:
                S_all = []
                for S in Slist:
                    Y = 0
                    for Mode in Mlist:
                        if M[U * numM + Mode] >= 0.1 and Y == 0:
                            Y = Yield[U * numM * numS + Mode * numS + S]
                            break
                    S_all.append(round(FUin_table[U][1] * Y, 3))
                Fout_table[U][1] = S_all
        for U in [Ulist[7], Ulist[8]]:
                S_all = []
                for S in Slist:
                    S_all.append(round(FUin_table[U][1] * Yield[U * numM * numS + 0 * numS + S], 3))
                Fout_table[U][1] = S_all
        for U in [9]:
                Fout_table[U][1] = [round(FOCin[OClist[7]], 3), round(FUin_table[5][1], 3)]
        for U in [10]:
                Fout_table[U][1] = [round(FOCin[OClist[3]], 3), round(FUin_table[3][1], 3)]
        print tabulate(Fout_table, Fout_header, tablefmt="simple", numalign="center", floatfmt=".1f")

        # FOCO: numOC*numO*numT
        FOCO = sol.get_values(FOCO_c, FOCO_c + FOCOcount - 1)
        FOCO_header = header[:]
        FOCO_header.insert(0, "FOCO")
        FOCO_table_ = [0] * (numT + 1)
        FOCO_table = []
        for OC in OClist:
            for O in Olist:
                FOCO_table.append(FOCO_table_[:])
        print "blending Flowrate of OC to O: "
        for OC in OClist:
            for O in Olist:
                FOCO_table[OC * numO + O][0] = "OC" + str(OC) + " O" + str(O)
                FOCO_table[OC * numO + O][1] = FOCO[OC * numO + O]
        print tabulate(FOCO_table, FOCO_header, tablefmt="simple", numalign="center", floatfmt=".3f")
        # Opro: numO*numP
        Opro = sol.get_values(Opro_c, Opro_c + Oprocount - 1)
        Opro_header = range(numO)
        Opro_header.insert(0, "Opro")
        Opro_table_ = [0] * (numO + 1)
        Opro_table = []
        for P in Plist:
            Opro_table.append(Opro_table_[:])
        print "blending Flowrate of OC to O: "
        for P in Plist:
            Opro_table[P][0] = " P" + str(P)
            for O in Olist:
                Opro_table[P][O+1] = Opro[O * numP + P]
        print tabulate(Opro_table, Opro_header, tablefmt="simple", numalign="center", floatfmt=".3f")

        # FOout: numO*numL*numT
        FOout = sol.get_values(FOout_c, FOout_c + FOoutcount - 1)
        FOout_header = range(numO)
        FOout_header.insert(0, "FOout")
        FOout_table_ = [0] * (numO + 1)
        FOout_table = []
        for L in range(numL1):
            FOout_table.append(FOout_table_[:])
        print "Flowrate of O to Order: "
        for L in range(numL1):
            FOout_table[L][0] = " L" + str(L)
            for O in Olist:
                FOout_table[L][O+1] = FOout[O * numL1 + L]
        print tabulate(FOout_table, FOout_header, tablefmt="simple", numalign="center", floatfmt=".3f")
        order_header = range(numO)
        order_header.insert(0, "order_left")
        order_table_ = [0] * (numO + 1)
        order_table = []
        for L in range(numL1):
            order_table.append(order_table_[:])
        print "Amount of O in Order: "
        for L in range(numL1):
            order_table[L][0] = " L" + str(L)
            for O in Olist:
                order_table[L][O+1] = DV1_left[L][O]
        print tabulate(order_table, order_header, tablefmt="simple", numalign="center", floatfmt=".3f")
        orderT_header = range(numT_total)
        orderT_header.insert(0, "orderT")
        orderT_table_ = [0] * (numT_total + 1)
        orderT_table = []
        for L in range(numL1):
            orderT_table.append(orderT_table_[:])
        print "Time range of Order: "
        for L in range(numL1):
            orderT_table[L][0] = " L" + str(L)
            for T in range(numT_total):
                orderT_table[L][T+1] = DS1[L][T]
        print tabulate(orderT_table, orderT_header, tablefmt="simple", numalign="center", floatfmt=".3f")

        # PRO:numO*numT
        PRO_header = header[:]
        PRO_header.insert(0, "PRO")
        PRO_table_ = [0] * (numT + 1)
        PRO_table = []
        for O in Olist:
            for i in range(3):
                PRO_table.append(PRO_table_[:])
        for O in Olist[0:5]:
            PRO_table[O * 3 + 0][0] = "max"
            PRO_table[O * 3 + 1][0] = "O" + str(O)
            PRO_table[O * 3 + 2][0] = "min"
            for T in Tlist:
                F_sum = sum([FOCO[OC * numO + O] for OC in OClist[0:5]])
                if F_sum >= 0.001:
                    PRO_table[O * 3 + 0][T + 1] = "[" + str(PROMAX[0 * numO + O]) + " " + str(
                        PROMAX[2 * numO + O]) + "]"
                    PRO_table[O * 3 + 1][T + 1] = "[" + str(round(sum(
                        [FOCO[OC * numO + O] * PRO[0 * numOC + OC] for OC in OClist[0:5]]) / F_sum,
                                                                  2)) + " " + \
                                                  str(round(sum(
                                                      [FOCO[OC * numO + O] * PRO[2 * numOC + OC] for
                                                       OC in OClist[0:5]]) / F_sum, 4)) + "]"
                    PRO_table[O * 3 + 2][T + 1] = "[" + str(PROMIN[0 * numO + O]) + " " + str(
                        PROMIN[2 * numO + O]) + "]"
                elif T != 0:
                    PRO_table[O * 3 + 0][T + 1] = "[" + str(PROMAX[0 * numO + O]) + " " + str(
                        PROMAX[2 * numO + O]) + "]"
                    PRO_table[O * 3 + 1][T + 1] = PRO_table[O * 3 + 1][T]
                    PRO_table[O * 3 + 2][T + 1] = "[" + str(PROMIN[0 * numO + O]) + " " + str(
                        PROMIN[2 * numO + O]) + "]"
                else:
                    PRO_table[O * 3 + 0][T + 1] = "[" + str(PROMAX[0 * numO + O]) + " " + str(
                        PROMAX[2 * numO + O]) + "]"
                    PRO_table[O * 3 + 1][T + 1] = "INI"
                    PRO_table[O * 3 + 2][T + 1] = "[" + str(PROMIN[0 * numO + O]) + " " + str(
                        PROMIN[2 * numO + O]) + "]"
        for O in Olist[5:8]:
            PRO_table[O * 3 + 0][0] = "max"
            PRO_table[O * 3 + 1][0] = "O" + str(O)
            PRO_table[O * 3 + 2][0] = "min"
            for T in Tlist:
                F_sum = sum([FOCO[OC * numO + O] for OC in OClist[5:8]])
                if F_sum >= 0.001:
                    PRO_table[O * 3 + 0][T + 1] = "[" + str(PROMAX[1 * numO + O]) + " " + str(
                        PROMAX[2 * numO + O]) + " " + str(PROMAX[3 * numO + O]) + "]"
                    PRO_table[O * 3 + 1][T + 1] = "[" + str(round(sum(
                        [FOCO[OC * numO + O] * PRO[1 * numOC + OC] for OC in OClist[5:8]]) / F_sum,
                                                                  2)) + " " + \
                                                  str(round(sum(
                                                      [FOCO[OC * numO + O] * PRO[2 * numOC + OC] for
                                                       OC in OClist[5:8]]) / F_sum, 4)) + " " + \
                                                  str(round(sum(
                                                      [FOCO[OC * numO + O] * PRO[3 * numOC + OC] for
                                                       OC in OClist[5:8]]) / F_sum, 4)) + "]"
                    PRO_table[O * 3 + 2][T + 1] = "[" + str(PROMIN[1 * numO + O]) + " " + str(
                        PROMIN[2 * numO + O]) + " " + str(PROMIN[3 * numO + O]) + "]"
                elif T != 0:
                    PRO_table[O * 3 + 0][T + 1] = "[" + str(PROMAX[1 * numO + O]) + " " + str(
                        PROMAX[2 * numO + O]) + " " + str(PROMAX[3 * numO + O]) + "]"
                    PRO_table[O * 3 + 1][T + 1] = PRO_table[O * 3 + 1][T]
                    PRO_table[O * 3 + 2][T + 1] = "[" + str(PROMIN[1 * numO + O]) + " " + str(
                        PROMIN[2 * numO + O]) + " " + str(PROMIN[3 * numO + O]) + "]"
                else:
                    PRO_table[O * 3 + 0][T + 1] = "[" + str(PROMAX[1 * numO + O]) + " " + str(
                        PROMAX[2 * numO + O]) + " " + str(PROMAX[3 * numO + O]) + "]"
                    PRO_table[O * 3 + 1][T + 1] = "INI"
                    PRO_table[O * 3 + 2][T + 1] = "[" + str(PROMIN[1 * numO + O]) + " " + str(
                        PROMIN[2 * numO + O]) + " " + str(PROMIN[3 * numO + O]) + "]"
        print tabulate(PRO_table, PRO_header, tablefmt="simple", numalign="center", floatfmt=".3f")

        # EU: numU*numT
        EU_header = header[:]
        EU_header.insert(0, "EU")
        EU_table_ = [0] * (numT + 1)
        EU_table = []
        for U in range(0, 9):
            EU_table.append(EU_table_[:])
        print "Unit Energy Cost:  "
        EU_table[0][0] = "ATM"
        EU_table[1][0] = "VDU"
        EU_table[2][0] = "FCCU"
        EU_table[3][0] = "ETH"
        EU_table[4][0] = "HDS"
        EU_table[5][0] = "HTU1"
        EU_table[6][0] = "HTU2"
        EU_table[7][0] = "RF"
        EU_table[8][0] = "MTBE"
        for U in [Ulist[2]]:
                Y = 0
                for Mode in Mlist:
                    if M[U * numM + Mode] >= 0.1 and Y == 0:
                        Y = OpCost[U * numM + Mode]
                        break
                EU_table[U][1] = round(FUin_table[U][1] * Y * hours, 3)
        for U in [Ulist[0], Ulist[1], Ulist[5], Ulist[6], Ulist[3], Ulist[4]]:
                Y = 0
                for Mode in Mlist:
                    if M[U * numM + Mode] >= 0.1 and Y == 0:
                        Y = OpCost[U * numM + Mode]
                        break
                EU_table[U][1] = round(FUin_table[U][1] * Y * hours, 3)
        for U in [Ulist[7], Ulist[8]]:
                EU_table[U][1] = round(FUin_table[U][1] * OpCost[U * numM + 0] * hours, 3)
        print tabulate(EU_table, EU_header, tablefmt="simple", numalign="center", floatfmt=".3f")
        # VOC: numOC*numT
        VOC = sol.get_values(VOC_c, VOC_c + VOCcount - 1)
        VOC_header = [now_T - 1, now_T]
        VOC_header.insert(0, "VOC")
        VOC_table_ = [0] * (numT + 2)
        VOC_table = []
        for OC in OClist:
            VOC_table.append(VOC_table_[:])
        print "Volume of OC: "
        for OC in OClist:
            VOC_table[OC][0] = "OC" + str(OC)
            VOC_table[OC][1] = OCtank_ini[OC]
            VOC_table[OC][2] = VOC[OC]
        print tabulate(VOC_table, VOC_header, tablefmt="simple", numalign="center", floatfmt=".3f")
        print "VOC:", np.round(VOC, 2).tolist()

        # VO: numO*numT
        VO = sol.get_values(VO_c, VO_c + VOcount - 1)
        VO_header = [now_T - 1, now_T]
        VO_header.insert(0, "VO")
        VO_table_ = [0] * (numT + 2)
        VO_table = []
        for O in Olist:
            VO_table.append(VO_table_[:])
        print "Volume of O: "
        for O in Olist:
            VO_table[O][0] = "O" + str(O)
            VO_table[O][1] = Otank_ini[O]
            VO_table[O][2] = VO[O]
        print tabulate(VO_table, VO_header, tablefmt="simple", numalign="center", floatfmt=".3f")
        print "VO:", np.round(VO, 2).tolist()
        # M: numU*numM
        M = sol.get_values(M_c, M_c + Mcount - 1)
        M_header = [now_T - 1, now_T]
        M_header.insert(0, "M")
        M_table_ = [0] * (numT + 2)
        M_table = []
        for U in Ulist[0:9]:
            M_table.append(M_table_[:])
        print "Unit Mode:  "
        M_table[0][0] = "ATM"
        M_table[1][0] = "VDU"
        M_table[2][0] = "FCCU"
        M_table[3][0] = "ETH"
        M_table[4][0] = "HDS"
        M_table[5][0] = "HTU1"
        M_table[6][0] = "HTU2"
        M_table[7][0] = "RF"
        M_table[8][0] = "MTBE"
        for U in Ulist[0:9]:
            for Mode in Mlist:
                if M[U * numM + Mode] >= 0.1:
                    M_table[U][1] = Mode
                    break
                elif Mode == 3:
                    M_table[U][1] = "N/A"
            for Mode in Mlist:
                if mode_T[U * numM + Mode] >= 0.1:
                    M_table[U][2] = Mode
                    break
                elif Mode == 3:
                    M_table[U][2] = "N/A"
        print tabulate(M_table, M_header, tablefmt="simple", numalign="center", floatfmt=".1f")
        print "NowT:",now_T,"results: ",results
        Qout = sol.get_values(Qout_c, Qout_c + Qoutcount - 1)
        PoutA_header = header[:]
        PoutA_header.insert(0, "Qout")
        PoutA_table_ = [0] * (numT + 1)
        PoutA_table = []
        for O in range(numOC+1):#numO+
            PoutA_table.append(PoutA_table_[:])
        print "Asistant variables of Raw materials and Products: "
        for O in range(numOC):#numO+1+
            # if O == 0:
            #     PoutA_table[O][0] = "Cru-Oil"
            #     PoutA_table[O][1] = PoutA[O]
            # else:
                PoutA_table[O][0] = "Pro"+str(O)
                PoutA_table[O][1] = Qout[O]
        print tabulate(PoutA_table, PoutA_header, tablefmt="simple", numalign="center", floatfmt=".3f")
        Pout = sol.get_values(Pout_c, Pout_c + Poutcount - 1)
        PoutA = sol.get_values(PoutA_c, PoutA_c + PoutAcount - 1)
        Pout_header = header[:]
        Pout_header.insert(0, "Pout")
        Pout_table_ = [0] * (numT + 1)
        Pout_table = []
        for O in range(numOC+1):#numO+
            Pout_table.append(Pout_table_[:])
        print "Amount of Raw materials and Products: "
        for O in range(numOC):#numO+1+
            # if O == 0:
            #     Pout_table[O][0] = "Cru-Oil"
            #     Pout_table[O][1] = Pout[O]
            # else:
                Pout_table[O][0] = "Pro"+str(O)
                Pout_table[O][1] = Pout[O]
        print tabulate(Pout_table, Pout_header, tablefmt="simple", numalign="center", floatfmt=".3f")
        # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Objective Value @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        partcost = 0
        for Modec in Mlist:
            partcost += FinM[0 * numM + Modec]
        partcost_cru = partcost
        ObjVal = 0

        partcost = 0
        for U in range(0, 9):
            partcost += EU_table[U][1]
        partcost_o = partcost
        ObjVal += partcost

        partcost = 0
        for OC in OClist:
            partcost += (VOC[OC]) * apoc
        partcost_VOC = partcost
        ObjVal += partcost

        partcost = 0
        for O in Olist:
            partcost += (VO[O]) * apo
        partcost_VO = partcost
        ObjVal += partcost

        partcost = 0
        for L in Llist1:
            for O in Olist:
                partcost += FOout[O * numL1 + L] *(-20*(numT_total-DS_num[L][1]))
        partcost_FOout = partcost
        ObjVal += partcost

        # partcost = 0
        # for O in range(numO + 1):
        #     partcost += Pout[O] * C_order*results_par[O]
        # partcost_Pout = partcost
        # ObjVal += partcost
        #
        # partcost = 0
        # for O in range(numO + 1):
        #     partcost += PoutA[O] * C_order*results_par[O] * (1+0.01)
        # partcost_PoutA = partcost
        # ObjVal += partcost

        print "crude oil output: ",partcost_cru,"operation cost: ", partcost_o, \
            "component oil inventory cost: ", partcost_VOC,\
            "Product inventory cost: ",partcost_VO,"FOout cost: ", partcost_FOout
            # "Pout cost: ", partcost_Pout,"PoutA cost: ", partcost_PoutA
        print "Pruduction Scheduling Objective: ", ObjVal

    return OC_inventory, O_inventory, FOout, Mode_act, FinM

if __name__ == '__main__':
    numT_total = 13
    now_T = 10
    numL1 = 4
    Llist1 = range(numL1)
    Pri = 1
    DV1_left = np.array([[ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
             0.        ,  0.        ,  0.        ],
           [21.65023479,  0.        ,  0.        ,  0.        ,  0.        ,
             0.        ,  0.        ,  0.        ],
           [ 0.        ,  0.        ,  0.        ,  0.        ,  0.        ,
             0.        ,  0.        ,  0.        ],
           [37.        ,  0.64494011, 12.91982798,  0.        ,  0.        ,
             0.        ,  0.        ,  0.        ]])
    DS1 = np.array([[1., 1., 1., 1., 1., 1., 0., 0., 0., 0., 0., 0., 0.],
           [0., 1., 1., 1., 1., 1., 1., 1., 0., 0., 0., 0., 0.],
           [1., 1., 1., 1., 1., 1., 1., 0., 0., 0., 0., 0., 0.],
           [0., 0., 0., 0., 1., 1., 1., 1., 1., 1., 1., 1., 0.]])
    DS_num = np.array([[ 0,  5],
           [ 1,  7],
           [ 0,  6],
           [ 4, 11],
           [ 2, 12]])
    OCtank_ini = [0.0, 0.0, 2.0121916499057284, 0.0, 0.0, 284.24711528039904, 35.08688684166658, 113.48691911782485]
    Otank_ini = [0, 0.0, 0, 0, 0, 0.0, 0.0, 0.0]
    results = np.array([ 1.68931031, 15.2038269 ,  2.34476662,  9.38295174,  4.50240183,
           40.84402466,  1.97197342, 28.91303444])
    results_par = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
    mode_T = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    T_state = [0, 0, 0, 0, 0, 0, 0, 0, 0]
    T_Yield = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    T_OpCost = [0, 0, 0, 0, 0, 0, 0, 0, 0]

    PRO_opt_TT(numT_total, now_T, numL1, Llist1, Pri, DV1_left, DS1, DS_num, OCtank_ini, Otank_ini, results, results_par,
               mode_T, T_state, T_Yield, T_OpCost)
