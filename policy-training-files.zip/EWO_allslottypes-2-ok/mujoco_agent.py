#coding:UTF-8

#   Copyright (c) 2018 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import numpy as np
# import parl
from paddle import fluid
from paddle.fluid import layers
# from parl.utils import logger
x = "3"
timeslots = "all"
policy_model_readdir_ini = "PRO_NN_n_num_allslot1215_O1_RL.model2-I"
value_model_readdir_ini = "PRO_NN_n_num_allslot1215_O1_RL.valuemodel2-t3"
policy_model_readdir = "PRO_Policy_model_best_"+timeslots+"-"+x
value_model_readdir = "PRO_Value_model_best_"+timeslots+"-"+x
policy_model_readdir1 = "1PRO_Policy_model_best_"+timeslots+"-"+x
value_model_readdir1 = "1PRO_Value_model_best_"+timeslots+"-"+x
policy_model_B_dir = "PRO_Policy_model_best_"+timeslots+"-"+x
value_model_B_dir = "PRO_Value_model_best_"+timeslots+"-"+x
policy_model_B_dir1 = "1PRO_Policy_model_best_"+timeslots+"-"+x
value_model_B_dir1 = "1PRO_Value_model_best_"+timeslots+"-"+x
policy_model_dir = "PRO_Policy_model_current_"+timeslots+"-"+x
value_model_dir = "PRO_Value_model_current_"+timeslots+"-"+x
policy_model_B_pre_dir = "PRO_RL_Policy_"+timeslots+"-"+x
model_file=timeslots+"_policy.model"
params_file=timeslots+"_policy.param"

class MujocoAgent():  #parl.Agent
    def __init__(self,
                 algorithm,
                 obs_dim,
                 act_dim,
                 kl_targ,
                 loss_type,
                 beta=1.0,
                 epsilon=0.2,
                 policy_learn_times=20,
                 value_learn_times=10,
                 value_batch_size=256,
                 exploration=0.8,
                 exploration_dacay=2e-7,
                 min_exploration=0.1,
                 ini_logvar = 0):
        self.alg = algorithm
        self.obs_dim = obs_dim
        self.act_dim = act_dim
        loss_type = 'CLIP'
        self.loss_type = loss_type
        # super(MujocoAgent, self).__init__(algorithm)

        self.policy_learn_times = policy_learn_times
        # Adaptive kl penalty coefficient
        self.beta = beta
        self.kl_targ = kl_targ
        self.init_logvar = ini_logvar

        self.value_learn_times = value_learn_times
        self.value_batch_size = value_batch_size
        self.value_learn_buffer = None
        #初始探索概率ε,超参数可微调
        self.exploration = exploration
        #每步探索的衰减程度,超参数可微调
        self.exploration_dacay=exploration_dacay
        #最小探索概率,超参数可微调
        self.min_exploration=min_exploration


        self.build_program()
        # self.place = fluid.CUDAPlace(0)
        self.place = fluid.CPUPlace()
        self.fluid_executor = fluid.Executor(self.place)
        self.fluid_executor.run(fluid.default_startup_program())
        # fluid.io.load_params(executor=self.fluid_executor, dirname=policy_model_dir,  #
        #                      main_program=self.policy_learn_program)
        # fluid.io.load_params(executor=self.fluid_executor, dirname=value_model_dir,  #_ini
        #                      main_program=self.value_learn_program)
        fluid.io.load_params(executor=self.fluid_executor, dirname=policy_model_readdir_ini,  #
                             main_program=self.policy_learn_program)
        # fluid.io.load_params(executor=self.fluid_executor, dirname=value_model_readdir,  #_ini
        #                      main_program=self.value_learn_program)
        self.clone_program()
    def build_program(self):
        self.policy_learn_program = fluid.Program()
        self.value_learn_program = fluid.Program()

        with fluid.program_guard(self.policy_learn_program):
            obs = layers.data(
                name='obs', shape=self.obs_dim, dtype='float32')
            actions = layers.data(
                name='actions', shape=[self.act_dim], dtype='float32')
            act_probs = layers.data(
                name='act_probs', shape=[1], dtype='float32')
            advantages = layers.data(
                name='advantages', shape=[1], dtype='float32')

            self.fc_policy = self.alg.model.policy(obs)
            w_param_attrs_fc = fluid.ParamAttr(name="fc_weight", trainable=True)
            B_param_attrs_fc = fluid.ParamAttr(name="fc_bais", trainable=True)
            self.means = fluid.layers.fc(input=self.fc_policy, size=self.act_dim, act='relu',
                                         param_attr=w_param_attrs_fc, bias_attr=B_param_attrs_fc)
            w_param_attrs_vars = fluid.ParamAttr(name="vars_weight", trainable=True)
            self.vars = fluid.layers.create_parameter(shape=[self.act_dim],dtype='float32',
                                                      attr = w_param_attrs_vars,
                                   default_initializer=fluid.initializer.ConstantInitializer(self.init_logvar))
            self.sampled_act = self.means + (fluid.layers.exp(self.vars / 2.0) *  # log(square(stddev))
                                             fluid.layers.gaussian_random(shape=(self.act_dim,), dtype='float32'))
            loss, kl,A,pg,clppg = self.alg.policy_learn(self.means, self.vars, actions,
                                                            act_probs, advantages)
            self.policy_learn_output = [loss, kl,A,pg,clppg]

        with fluid.program_guard(self.value_learn_program):
            obs = layers.data(
                name='obs', shape=self.obs_dim, dtype='float32')
            val = layers.data(name='val', shape=[], dtype='float32')

            self.predict_val = self.alg.model.value(obs)
            value_loss = self.alg.value_learn(self.predict_val, val)
            self.value_learn_output = [value_loss]
    def load_program(self):
        fluid.io.load_params(executor=self.fluid_executor, dirname=policy_model_readdir,
                             main_program=self.policy_learn_program)
        fluid.io.load_params(executor=self.fluid_executor, dirname=value_model_readdir,
                             main_program=self.value_learn_program)
    def load_program1(self):
        fluid.io.load_params(executor=self.fluid_executor, dirname=policy_model_readdir1,
                             main_program=self.policy_learn_program)
        fluid.io.load_params(executor=self.fluid_executor, dirname=value_model_readdir1,
                             main_program=self.value_learn_program)
    def clone_program(self):
        self.policy_predict_program = self.policy_learn_program.clone(for_test=True)
        self.value_predict_program = self.value_learn_program.clone(for_test=True)
    def save_program(self):
        fluid.io.save_params(executor=self.fluid_executor, dirname=policy_model_dir,
                                   main_program=self.policy_learn_program)
        fluid.io.save_params(executor=self.fluid_executor, dirname=value_model_dir,
                                   main_program=self.value_learn_program)
    def save_best_program(self):
        fluid.io.save_params(executor=self.fluid_executor, dirname=policy_model_B_dir,
                                   main_program=self.policy_learn_program)
        fluid.io.save_params(executor=self.fluid_executor, dirname=value_model_B_dir,
                                   main_program=self.value_learn_program)
        fluid.io.save_inference_model(dirname=policy_model_B_pre_dir, feeded_var_names=["obs"],
                                      target_vars=[self.means], executor=self.fluid_executor,
                                    model_filename=model_file, params_filename=params_file,
                                   main_program=self.policy_learn_program)
    def save_best_program1(self):
        fluid.io.save_params(executor=self.fluid_executor, dirname=policy_model_B_dir1,
                                   main_program=self.policy_learn_program)
        fluid.io.save_params(executor=self.fluid_executor, dirname=value_model_B_dir1,
                                   main_program=self.value_learn_program)
        fluid.io.save_inference_model(dirname=policy_model_B_pre_dir, feeded_var_names=["obs"],
                                      target_vars=[self.means], executor=self.fluid_executor,
                                    model_filename=model_file, params_filename=params_file,
                                   main_program=self.policy_learn_program)
    # ε-greedy
    def policy_sample(self, obs):
            sample = np.random.random()
            if sample < self.exploration:
                feed = {'obs': obs,
                        'actions': np.array([[2]*8], dtype='float32'),
                        'act_probs': np.array([[2]], dtype='float32'),
                        'advantages': np.array([[2]], dtype='float32'),
                        }
                act, mean, vars = self.fluid_executor.run(
                    self.policy_predict_program,
                    feed=feed,
                    fetch_list=[self.sampled_act, self.means, self.vars])
                act_prob = np.sum(-0.5*np.square(act - mean)/np.exp(vars)-0.5*vars)
            elif sample >= self.exploration:
                feed = {'obs': obs,
                        'actions': np.array([[2]*8], dtype='float32'),
                        'act_probs': np.array([[2]], dtype='float32'),
                        'advantages': np.array([[2]], dtype='float32'),
                        }
                mean, vars = self.fluid_executor.run(
                    self.policy_predict_program,
                    feed=feed,
                    fetch_list=[self.means, self.vars])
                act = mean
                act_prob = np.sum(-0.5*vars)   #  1/(vars*np.sqrt(2*np.pi))
                # print sampled_pro, sampled_act
            self.exploration = max(self.min_exploration, self.exploration - self.exploration_dacay)
            return act, act_prob#,sampled_pro[0]

    def policy_predict(self, obs):
        feed = {'obs': obs,
                'actions': np.array([[2]*8], dtype='float32'),
                'act_probs': np.array([[2]], dtype='float32'),
                'advantages': np.array([[2]], dtype='float32'),
                    }
        means = self.fluid_executor.run(
            self.policy_predict_program,
            feed=feed,
            fetch_list=self.means)[0]
        # act_prob = np.argmax(means[0])
        return means[0]

    def value_predict(self, obs):
        feed = {'obs': obs,
                'val': np.array([[2]], dtype='float32')}
        value = self.fluid_executor.run(
            self.value_predict_program,
            feed=feed,
            fetch_list=self.predict_val)[0]
        return value

    def _batch_policy_learn(self, obs, actions, act_probs, advantages): #
        feed = {'obs': obs,
                'actions': actions,
                'act_probs':act_probs,
                'advantages': advantages}
        [loss,kl,A,pg,clppg] = self.fluid_executor.run(
            self.policy_learn_program,
            feed=feed,
            fetch_list=self.policy_learn_output)
        return loss,kl,A,pg,clppg

    def _batch_value_learn(self, obs, val):
        feed = {'obs': obs,
                'val': val}
        value_loss = self.fluid_executor.run(
            self.value_learn_program,
            feed=feed,
            fetch_list=self.value_learn_output)[0]
        return value_loss

    def policy_learn(self, obs, actions, act_probs, advantages):  #
        """ Learn policy:

        1. Sync parameters of policy model to old policy model
        2. Fix old policy model, and learn policy model multi times
        3. if use KLPEN loss, Adjust kl loss coefficient: beta
        """
        # self.alg.sync_old_policy()

        all_loss, all_kl, all_A, all_pg, all_clppg = [], [], [], [], []
        G = 0
        for _ in range(self.policy_learn_times):
            loss, kl ,A,pg,clppg= self._batch_policy_learn(obs, actions,
                                                           act_probs,
                                                           advantages)
            all_loss.append(loss.tolist())
            all_kl.append(kl)
            if G == 0:
                all_A.append(np.mean(A))
                all_A.append(np.round(np.ravel(A).tolist(),6)[:10].tolist()) #,pp
                G = 1
            all_pg.append(np.round(np.ravel(pg).tolist(), 3)[:10].tolist())
            all_clppg.append(np.round(np.ravel(clppg).tolist(), 3)[:10].tolist())
            # all_A.append(np.round(np.ravel(A).tolist(),3)[:20].tolist()) #,pp
            # all_pg.append(np.round(np.ravel(pg).tolist(),3)[:20].tolist()) #,pp
            # all_clppg.append(np.round(np.ravel(clppg).tolist(),3)[:20].tolist()) #,pp

        return np.mean(all_loss) , np.mean(all_kl) , all_A, all_pg, \
               all_clppg, all_loss


    def value_learn(self, obs, value):
        """ Fit model to current data batch + previous data batch
        """
        data_size = obs.shape[0]

        if self.value_learn_buffer is None:
            obs_train, value_train = obs, value
        else:
            obs_train = np.concatenate([obs, self.value_learn_buffer[0]])
            value_train = np.concatenate([value, self.value_learn_buffer[1]])
            print "length of value dataset:", value_train.shape[0]
        self.value_learn_buffer = (obs, value)

        all_loss = []
        for _ in range(self.value_learn_times):
            random_ids = np.arange(obs_train.shape[0])
            np.random.shuffle(random_ids)
            shuffle_obs_train = obs_train[random_ids]
            shuffle_value_train = value_train[random_ids]
            start = 0
            while start < data_size:
                end = start + self.value_batch_size
                value_loss = self._batch_value_learn(
                    shuffle_obs_train[start:end, :],
                    shuffle_value_train[start:end])
                all_loss.append(value_loss)
                start += self.value_batch_size
        return np.mean(all_loss)
