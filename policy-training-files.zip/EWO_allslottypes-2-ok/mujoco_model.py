#   Copyright (c) 2018 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np
# import parl
# from parl import layers
import paddle.fluid as fluid
from paddle.fluid import layers
from paddle.fluid.param_attr import ParamAttr


class MujocoModel():#parl.Model
    def __init__(self):
        self.policy_model = PolicyModel()
        self.value_model = ValueModel()
        self.policy_lr = self.policy_model.lr
        self.value_lr = self.value_model.lr

    def policy(self, obs):
        return self.policy_model.policy(obs)

    def policy_sample(self, obs):
        return self.policy_model.policy(obs)

    def value(self, obs):
        return self.value_model.value(obs)


class PolicyModel():#parl.Model
    def __init__(self):
        self.lr = 0.000005


    def policy(self, img):
        w_param_attrs_conv1 = fluid.ParamAttr(name="conv1_weight", trainable=True)
        B_param_attrs_conv1 = fluid.ParamAttr(name="conv1_bais", trainable=True)
        conv_pool_1 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[8, 12],
            num_filters=100,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv1, bias_attr=B_param_attrs_conv1)
        w_param_attrs_fc1 = fluid.ParamAttr(name="fc1_weight", trainable=True)
        B_param_attrs_fc1 = fluid.ParamAttr(name="fc1_bais", trainable=True)
        fc_1 = fluid.layers.fc(input=conv_pool_1, size=10, act='tanh',
                               param_attr=w_param_attrs_fc1, bias_attr=B_param_attrs_fc1)
        w_param_attrs_conv21 = fluid.ParamAttr(name="conv21_weight", trainable=True)
        B_param_attrs_conv21 = fluid.ParamAttr(name="conv21_bais", trainable=True)
        conv_pool_2_1 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[8, 1],
            num_filters=50,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv21, bias_attr=B_param_attrs_conv21)
        w_param_attrs_conv22 = fluid.ParamAttr(name="conv22_weight", trainable=True)
        B_param_attrs_conv22 = fluid.ParamAttr(name="conv22_bais", trainable=True)
        conv_pool_2_2 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[8, 3],
            num_filters=50,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv22, bias_attr=B_param_attrs_conv22)
        w_param_attrs_conv23 = fluid.ParamAttr(name="conv23_weight", trainable=True)
        B_param_attrs_conv23 = fluid.ParamAttr(name="conv23_bais", trainable=True)
        conv_pool_2_3 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[8, 5],
            num_filters=50,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv23, bias_attr=B_param_attrs_conv23)
        conv_pool_2 = fluid.layers.concat(input=[conv_pool_2_1, conv_pool_2_2, conv_pool_2_3], axis=3)
        w_param_attrs_fc2 = fluid.ParamAttr(name="fc2_weight", trainable=True)
        B_param_attrs_fc2 = fluid.ParamAttr(name="fc2_bais", trainable=True)
        fc_2 = fluid.layers.fc(input=conv_pool_2, size=20, act='tanh',
                               param_attr=w_param_attrs_fc2, bias_attr=B_param_attrs_fc2)
        w_param_attrs_conv31 = fluid.ParamAttr(name="conv31_weight", trainable=True)
        B_param_attrs_conv31 = fluid.ParamAttr(name="conv31_bais", trainable=True)
        conv_pool_3_1 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[1, 3],
            num_filters=50,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv31, bias_attr=B_param_attrs_conv31)
        w_param_attrs_conv32 = fluid.ParamAttr(name="conv32_weight", trainable=True)
        B_param_attrs_conv32 = fluid.ParamAttr(name="conv32_bais", trainable=True)
        conv_pool_3_2 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[1, 4],
            num_filters=50,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv32, bias_attr=B_param_attrs_conv32)
        w_param_attrs_conv33 = fluid.ParamAttr(name="conv33_weight", trainable=True)
        B_param_attrs_conv33 = fluid.ParamAttr(name="conv33_bais", trainable=True)
        conv_pool_3_3 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[1, 5],
            num_filters=50,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv33, bias_attr=B_param_attrs_conv33)
        conv_pool_3 = fluid.layers.concat(input=[conv_pool_3_1, conv_pool_3_2, conv_pool_3_3], axis=3)
        w_param_attrs_fc3 = fluid.ParamAttr(name="fc3_weight", trainable=True)
        B_param_attrs_fc3 = fluid.ParamAttr(name="fc3_bais", trainable=True)
        fc_3 = fluid.layers.fc(input=conv_pool_3, size=20, act='tanh',
                               param_attr=w_param_attrs_fc3, bias_attr=B_param_attrs_fc3)
        fc = fluid.layers.concat(input=[fc_1, fc_2, fc_3], axis=1)
        w_param_attrs_fc1 = fluid.ParamAttr(name="fcall1_weight", trainable=True)
        B_param_attrs_fc1 = fluid.ParamAttr(name="fcall1_bais", trainable=True)
        fc_all1 = fluid.layers.fc(input=fc, size=80, act='tanh',
                                  param_attr=w_param_attrs_fc1, bias_attr=B_param_attrs_fc1)
        w_param_attrs_fc2 = fluid.ParamAttr(name="fcall2_weight", trainable=True)
        B_param_attrs_fc2 = fluid.ParamAttr(name="fcall2_bais", trainable=True)
        fc_all2 = fluid.layers.fc(input=fc_all1, size=30, act='tanh',
                                  param_attr=w_param_attrs_fc2, bias_attr=B_param_attrs_fc2)
        return fc_all2


class ValueModel():#parl.Model
    def __init__(self):
        # super(ValueModel, self).__init__()
        self.lr = 0.00012

    def value(self, img):
        w_param_attrs_conv1 = fluid.ParamAttr(name="conv1_weight_V", trainable=True)
        B_param_attrs_conv1 = fluid.ParamAttr(name="conv1_bais_V", trainable=True)
        conv_pool_1 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[8, 12],
            num_filters=100,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv1, bias_attr=B_param_attrs_conv1)
        w_param_attrs_fc1 = fluid.ParamAttr(name="fc1_weight_V", trainable=True)
        B_param_attrs_fc1 = fluid.ParamAttr(name="fc1_bais_V", trainable=True)
        fc_1 = fluid.layers.fc(input=conv_pool_1, size=10, act='tanh',
                               param_attr=w_param_attrs_fc1, bias_attr=B_param_attrs_fc1)
        w_param_attrs_conv21 = fluid.ParamAttr(name="conv21_weight_V", trainable=True)
        B_param_attrs_conv21 = fluid.ParamAttr(name="conv21_bais_V", trainable=True)
        conv_pool_2_1 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[8, 1],
            num_filters=50,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv21, bias_attr=B_param_attrs_conv21)
        w_param_attrs_conv22 = fluid.ParamAttr(name="conv22_weight_V", trainable=True)
        B_param_attrs_conv22 = fluid.ParamAttr(name="conv22_bais_V", trainable=True)
        conv_pool_2_2 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[8, 3],
            num_filters=50,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv22, bias_attr=B_param_attrs_conv22)
        w_param_attrs_conv23 = fluid.ParamAttr(name="conv23_weight_V", trainable=True)
        B_param_attrs_conv23 = fluid.ParamAttr(name="conv23_bais_V", trainable=True)
        conv_pool_2_3 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[8, 5],
            num_filters=50,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv23, bias_attr=B_param_attrs_conv23)
        conv_pool_2 = fluid.layers.concat(input=[conv_pool_2_1, conv_pool_2_2, conv_pool_2_3], axis=3)
        w_param_attrs_fc2 = fluid.ParamAttr(name="fc2_weight_V", trainable=True)
        B_param_attrs_fc2 = fluid.ParamAttr(name="fc2_bais_V", trainable=True)
        fc_2 = fluid.layers.fc(input=conv_pool_2, size=20, act='tanh',
                               param_attr=w_param_attrs_fc2, bias_attr=B_param_attrs_fc2)
        w_param_attrs_conv31 = fluid.ParamAttr(name="conv31_weight_V", trainable=True)
        B_param_attrs_conv31 = fluid.ParamAttr(name="conv31_bais_V", trainable=True)
        conv_pool_3_1 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[1, 3],
            num_filters=50,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv31, bias_attr=B_param_attrs_conv31)
        w_param_attrs_conv32 = fluid.ParamAttr(name="conv32_weight_V", trainable=True)
        B_param_attrs_conv32 = fluid.ParamAttr(name="conv32_bais_V", trainable=True)
        conv_pool_3_2 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[1, 4],
            num_filters=50,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv32, bias_attr=B_param_attrs_conv32)
        w_param_attrs_conv33 = fluid.ParamAttr(name="conv33_weight_V", trainable=True)
        B_param_attrs_conv33 = fluid.ParamAttr(name="conv33_bais_V", trainable=True)
        conv_pool_3_3 = fluid.nets.simple_img_conv_pool(
            input=img,
            filter_size=[1, 5],
            num_filters=50,
            pool_size=1,
            pool_stride=1,
            act="relu",
            param_attr=w_param_attrs_conv33, bias_attr=B_param_attrs_conv33)
        conv_pool_3 = fluid.layers.concat(input=[conv_pool_3_1, conv_pool_3_2, conv_pool_3_3], axis=3)
        w_param_attrs_fc3 = fluid.ParamAttr(name="fc3_weight_V", trainable=True)
        B_param_attrs_fc3 = fluid.ParamAttr(name="fc3_bais_V", trainable=True)
        fc_3 = fluid.layers.fc(input=conv_pool_3, size=20, act='tanh',
                               param_attr=w_param_attrs_fc3, bias_attr=B_param_attrs_fc3)
        fc = fluid.layers.concat(input=[fc_1, fc_2, fc_3], axis=1)
        w_param_attrs_fc1 = fluid.ParamAttr(name="fcall1_weight_V", trainable=True)
        B_param_attrs_fc1 = fluid.ParamAttr(name="fcall1_bais_V", trainable=True)
        fc_all1 = fluid.layers.fc(input=fc, size=10, act='tanh',
                                  param_attr=w_param_attrs_fc1, bias_attr=B_param_attrs_fc1)
        w_param_attrs_fc2 = fluid.ParamAttr(name="fcall2_weight_V", trainable=True)
        B_param_attrs_fc2 = fluid.ParamAttr(name="fcall2_bais_V", trainable=True)
        fc_all2 = fluid.layers.fc(input=fc_all1, size=1, act=None,
                                  param_attr=w_param_attrs_fc2, bias_attr=B_param_attrs_fc2)
        return fc_all2

    def value1(self, obs):
        conv_pool_1 = fluid.nets.simple_img_conv_pool(input=obs,
                                                    filter_size=[3, 3],
                                                    num_filters=30,
                                                    pool_size=2,
                                                    pool_stride=1,
                                                    act="relu")
        self.fc1 = layers.fc(input=conv_pool_1, size=20, act='tanh')
        V = layers.fc(input=self.fc1, size=1, act=None)
        return V
