#   Copyright (c) 2018 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# import numpy as np
# from copy import deepcopy
from paddle import fluid
from paddle.fluid import layers
# from parl.core.fluid.algorithm import Algorithm
# from parl.utils.deprecation import deprecated

__all__ = ['PPO']


class PPO(): #Algorithm
    def __init__(self,
                 model,
                 hyperparas=None,
                 act_dim=None,
                 policy_lr=None,
                 value_lr=None,
                 epsilon=0.1):
        """ PPO algorithm
        
        Args:
            model (parl.Model): model defining forward network of policy and value.
            hyperparas (dict): (deprecated) dict of hyper parameters.
            act_dim (float): dimension of the action space.
            policy_lr (float): learning rate of the policy model. 
            value_lr (float): learning rate of the value model.
            epsilon (float): epsilon used in the CLIP loss (default 0.2).
        """
        self.model = model
        # Used to calculate probability of action in old policy

        # self.old_policy_model = deepcopy(model.policy_model)

        self.act_dim = act_dim
        self.policy_lr = policy_lr
        self.value_lr = value_lr
        self.epsilon = epsilon


    def predict(self, obs):
        means = self.model.policy(obs)
        return means

    def sample(self, obs):
        sampled_act = self.model.policy(obs)
        return sampled_act


    def policy_learn(self, means, logvars, actions, old_logprob, advantages, beta=None):
        """ Learn policy model with:
                1. CLIP loss: Clipped Surrogate Objective
                2. KLPEN loss: Adaptive KL Penalty Objective
            See: https://arxiv.org/pdf/1707.02286.pdf

        Args:
            obs: Tensor, (batch_size, obs_dim)
            actions: Tensor, (batch_size, act_dim)
            advantages: Tensor (batch_size, )
            beta: Tensor (1) or None
                  if None, use CLIP Loss; else, use KLPEN loss.
        """

        # # means = self.model.policy(obs)
        # logprob = fluid.layers.elementwise_mul(obs,actions)
        # logprob = fluid.layers.reduce_sum(logprob, dim=1, keep_dim=True)
        # logprob = layers.log(logprob+1e-6)

        exp_item = layers.elementwise_div(
            layers.square(actions - means), layers.exp(logvars), axis=1)
        exp_item = -0.5 * layers.reduce_sum(exp_item, dim=1)
        vars_item = -0.5 * layers.reduce_sum(logvars)
        logprob = exp_item + vars_item

        pg_ratio = layers.exp(logprob - old_logprob)
        clipped_pg_ratio = layers.clip(pg_ratio, 1 - self.epsilon,
                                        1 + self.epsilon)
        surrogate_loss = layers.elementwise_min(
                advantages * pg_ratio, advantages * clipped_pg_ratio)
        loss = layers.reduce_mean(surrogate_loss)

        optimizer = fluid.optimizer.Adam(self.policy_lr)
        optimizer.minimize(loss)
        kl = layers.fill_constant(shape=[1],value=2,dtype="float32")
        return loss, kl, advantages, pg_ratio, clipped_pg_ratio


    def value_predict(self, obs):
        return self.model.value(obs)


    def value_learn(self, obs, val):
        # predict_val = self.model.value(obs)
        loss = layers.square_error_cost(obs, val)
        loss = layers.reduce_mean(loss)
        optimizer = fluid.optimizer.AdamOptimizer(self.value_lr)
        optimizer.minimize(loss)
        return loss
