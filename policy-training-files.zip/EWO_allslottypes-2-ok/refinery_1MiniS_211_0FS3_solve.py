import cplex
from cplex.callbacks import MIPInfoCallback
import numpy as np
from tabulate import tabulate
#U /ATM 0,VCD 1,FCCU 2,ETH 3,HDS 4,HTU1 5,HTU2 6,RF 7,MTBE 8/
#M /A 0,G 1,D 2,GG 3,GD 4,DG 5,DD 6,M 7,H 8/
#T /t1*tnumT/
#S /s1*s4/
#O /JIV93 0,JIV97 1,GII90 2,GII93 3,GII97 4,GII0 5,GIIM10 6,GIV0 7/
#OC /C5 0,Reformate 1,MTBE 2,HDS 3,Etherified 4,diesel1 5,diesel2 6,Lightdi 7/
#P /RON,CN,S,CPF/
#L /L1,L2/
#TL /TL1,TL2/
#LimitV /MIN,MAX/
#ObjectFunction..Object       =e= sum(T,QI('ATM',T)*OPC+sum(U,sum(M,sum(M1,xQI(U,M,M1,T)*tOpCost(U,M,M1))))
#                                 +sum(U,sum(M1,xyQI(U,M1,T)*OpCost(U,M1))))
#                                 +sum(T,ap*(sum(O,OINV(O,T))+sum(OC,OCINV(OC,T))))
#                                 +sum(L,sum(O,bp*(R(L,O)-sum(T,Otankout(O,L,T)))));
numU = 9
numM = 4
numS = 4
numO = 8
numOC = 8
numP = 4
hours = 1
numL = 2
MAXINPUT = 300
Mlist = range(numM)
Ulist = range(numU)
Slist = range(numS)
Plist = range(numP)
TTlist = [3,2,1]
OClist = range(numOC)
Olist = range(numO)
Llist = range(numL)
TLlist = range(2) # TL1 and TL2
OPC = 388.2   # crude oil cost per ton
apoc = 50.0    # inv cost
apo = 75.0    # inv cost
bp = 30000.  # penalty for stockout of order l per ton
invC_multi_flow = 4  # invOC uplimit , its value is invC_multi_flow times of flow*hours
invO_multi_L = 6   # invO uplimit , its value is invO_multi_flow times of flow*hours
MTBE120or110 = 120
FOCOmax = 100
FOout_MAX = 100
# PRO = [94.,99.,94.,98.,89.,0.,0.,0.,
#        0.,0.,0.,0.,0.,48.,49.,59.,
#        0.0001,0.0002,0.0004,0.02,0.03,0.001,0.001,0.038,
#        0.,0.,0.,0.,0.,1.68,1.1,1.6] #P /RON,CN,S,CPF/  # PRO(P,OC)
PRO = [#96.,98.,99.,93.,89.,0.,0.,0.,
       83.,100.,117.,93.,90.,0.,0.,0.,
       #0.,0.,0.,0.,0.,48.,49.,59.,
       0.,0.,0.,0.,0.,47.,55.,48.,
       #0.0001,0.0002,0.0004,0.02,0.03,0.038,0.002,0.001,
       0.0001,0.0002,0.04,0.01,0.02,0.001,0.001,0.038,
       #0.0001,0.0001,0.05,0.01,0.01,0.038,0.002,0.001,
       0.,0.,0.,0.,0.,1.68,1.1,1.6] #P /RON,S,CN,CPF/  # PRO(P,OC)

PROMAX = [0.]*numP*numO
PROMAX[16:24] = [0.0005,0.0006,0.015,0.015,0.015,0.035,0.035,0.01] # PROMAX(P,O) S content unit is %
PROMAX[24:32] = [0.,0.,0.,0.,0.,1.6184,1.1995,1.6184]  # CPF(P,O)
PROMIN = [93.,97.,90.,93.,97.,0.,0.,0.,
          0.,0.,0.,0.,0.,49.,49.,51.,
          0.,0.,0.,0.,0.,0.,0.,0.,
          0.,0.,0.,0.,0.,0.,0.,0.] # PROMIN(P,O)

rMIN = [0.]*numOC*numO  #  rMIN(OC,O)

rMAX = [1.]*numOC*numO
rMAX[16:21] = [0.1]*5  # rMAX(OC,O)


R = [[10.,40.,20.,10.,55.,100.,60.,70.],
     [20.,30.,10.,10.,70.,80.,70.,90.]] # numL*numO
RT = [[1.,6.],[3.,8.]] # numL*2
# R= np.array(R)
# RT= np.array(RT)
QIinputL = [200.,300.,0.,300.,0.,300.,0.,300.,0.,300.,0.,300.,0.,300.,0.,300.,0.,300.]  # numU*2
#OCtankL = [0.,1000.,0.,1000.,0.,1000.,0.,1000.,0.,1000.,0.,1000.,0.,1000.,0.,1000.] #numOC*2
#OtankL = [0.,1000.,0.,1000.,0.,1000.,0.,1000.,0.,1000.,0.,1000.,0.,1000.,0.,1000.] #numO*2
# Parameter tYield
Yield = [0]*numU*numM*numS
# Yieldlist = [7.008,15.349,8.109,64.534,4.576,19.403,9.267,61.754,
#              11.286,37.532,12.580,35.652,
#              22.216, 5.02, 45.664,  23.104, 5.01, 42.583,  23.418, 4.15, 42.261,  26.683, 4.13, 39.580,
#              93.2,90,98.1,94.1,
#              86.2,79.,97.,88.,
#              99.4,99.4,
#              4.,93.,9.,89.,
#              10.,90.,
#              120]
Yieldlist = [7.008,15.349,8.109,64.534,4.576,19.403,9.267,61.754,
             11.286,37.352, 12.580,35.652,
             22.216, 5.02, 45.664, 23.104, 5.01, 42.583, 23.418, 4.15, 42.261, 26.683, 4.13, 39.580,
             98.1, 94.1, 93.2, 90,
             97., 88., 86.2, 79.,
             99.4, 99.4,
             9., 89., 4., 93.,
             10., 90.,
             120]
for U in [Ulist[0]]: # ATM
    for M in Mlist[0:2]:
        for S in Slist:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)
for U in [Ulist[1]]: # VCD
    for M in Mlist[0:2]:
        for S in Slist[0:2]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)
for U in [Ulist[2]]: # FCCU
    for M in Mlist[0:4]:
        for S in Slist[0:3]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)
for U in [Ulist[3]]: # ETH
    for M in Mlist[0:4]:
        for S in [Slist[0]]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)
for U in [Ulist[4]]:  # HDS
    for M in Mlist[0:4]:
        for S in [Slist[0]]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)
for U in [Ulist[5]]:  # HTU1
    for M in Mlist[0:2]:
        for S in [Slist[0]]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)
for U in [Ulist[6]]:  # HTU2
    for M in Mlist[0:2]:
        for S in Slist[0:2]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)
for U in [Ulist[7]]:  # RF
    for M in [Mlist[0]]:
        for S in Slist[0:2]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)
for U in [Ulist[8]]:  # MTBE
    for M in [Mlist[0]]:
        for S in [Slist[0]]:
            Yield[U*numM*numS+M*numS+S] = Yieldlist.pop(0)

tYield = [0]*numU*numM*numM*numS
for U in [Ulist[0]]: # ATM
    for M in Mlist[0:2]:
        for M1 in Mlist[0:2]:
            if M1 != M:
                for S in Slist:
                    tYield[U*numM*numM*numS+M*numM*numS+M1*numS+S] = 0.5*(Yield[U*numM*numS+M*numS+S]+Yield[U*numM*numS+M1*numS+S])
for U in [Ulist[1]]: # VCD
    for M in Mlist[0:2]:
        for M1 in Mlist[0:2]:
            if M1 != M:
                for S in Slist[0:2]:
                    tYield[U*numM*numM*numS+M*numM*numS+M1*numS+S] = 0.5*(Yield[U*numM*numS+M*numS+S]+Yield[U*numM*numS+M1*numS+S])
for U in [Ulist[2]]: # FCCU
    for M in Mlist[0:4]:
        for M1 in Mlist[0:4]:
            if M1 != M:
                for S in Slist[0:3]:
                    tYield[U*numM*numM*numS+M*numM*numS+M1*numS+S] = 0.5*(Yield[U*numM*numS+M*numS+S]+Yield[U*numM*numS+M1*numS+S])
for U in [Ulist[3]]: # ETH
    for M in Mlist[0:4]:
        for M1 in Mlist[0:4]:
            if M1 != M:
                for S in [Slist[0]]:
                    tYield[U*numM*numM*numS+M*numM*numS+M1*numS+S] = 0.5*(Yield[U*numM*numS+M*numS+S]+Yield[U*numM*numS+M1*numS+S])
for U in [Ulist[4]]:  # HDS
    for M in Mlist[0:4]:
        for M1 in Mlist[0:4]:
            if M1 != M:
                for S in [Slist[0]]:
                    tYield[U*numM*numM*numS+M*numM*numS+M1*numS+S] = 0.5*(Yield[U*numM*numS+M*numS+S]+Yield[U*numM*numS+M1*numS+S])
for U in [Ulist[5]]:  # HTU1
    for M in Mlist[0:2]:
        for M1 in Mlist[0:2]:
            if M1 != M:
                for S in [Slist[0]]:
                    tYield[U*numM*numM*numS+M*numM*numS+M1*numS+S] = 0.5*(Yield[U*numM*numS+M*numS+S]+Yield[U*numM*numS+M1*numS+S])
for U in [Ulist[6]]:  # HTU2
    for M in Mlist[0:2]:
        for M1 in Mlist[0:2]:
            if M1 != M:
                for S in Slist[0:2]:
                    tYield[U*numM*numM*numS+M*numM*numS+M1*numS+S] = 0.5*(Yield[U*numM*numS+M*numS+S]+Yield[U*numM*numS+M1*numS+S])


# OpCost = [11.,11.5,0.,0.,
#           11.,11.5,0.,0.,
#           58.,57.,56.5,56.,
#           49.56,47.11,46.7,44.66,
#           28.98,27.18,26.73,24.48,
#           9.,8., 0., 0.,
#           11.,10., 0., 0.,
#           83.,0.,0.,0.,
#           13.84,0.,0.,0.]   # numU*numM
OpCost = [11.,11.5,0.,0.,
          11.,11.5,0.,0.,
          58.,57.,56.5,56.,
          49.56,47.11,46.7,44.66,
          28.98,27.18,26.73,24.48,
          9.,8., 0., 0.,
          11.,10., 0., 0.,
          83.,0.,0.,0.,
          13.84,0.,0.,0.] # numU*numM

tOpCost = [0]*numU*numM*numM
# For Parameter tOpCostlist
for U in Ulist[0:2]:
    for M in Mlist[0:4]:
        for M1 in Mlist[0:4]:
            tOpCost[U*numM*numM+M*numM+M1] = 0.5*(OpCost[U*numM+M]+OpCost[U*numM+M1])+0
for U in Ulist[0+2:3+2]:
    for M in Mlist[0:4]:
        for M1 in Mlist[0:4]:
            tOpCost[U*numM*numM+M*numM+M1] = 0.5*(OpCost[U*numM+M]+OpCost[U*numM+M1])+0
for U in Ulist[3+2:5+2]:
    for M in Mlist[0:2]:
        for M1 in Mlist[0:2]:
            tOpCost[U*numM*numM+M*numM+M1] = 0.5*(OpCost[U*numM+M]+OpCost[U*numM+M1])+0

def buildmodel(prob,numT, Tlist, numL, Llist, DS1, DV1, Pri, DS_num, OCtank_ini, Otank_ini,Mode,evaluate_is ):
    # prob.objective.set_sense(prob.objective.sense.minimize)
    out = prob.set_results_stream(None)  # don't display the solution process.
    out = prob.set_log_stream(None)  # don't display the solution process.
    # list number is address, inlet is value. Orgenize the list number to get the value.  #,QI_atm,QI_eth,QI_htu1
    # the yield value
    xcount = numU*numM*numM*numT
    x_c = 0
    ycount = numU*numM*numT
    y_c = x_c + xcount
    xQIcount = numU*numM*numM*numT
    xQI_c = y_c + ycount
    xyQIcount = numU*numM*numT
    xyQI_c = xQI_c + xQIcount
    QOcount = numU*numS*numT
    QO_c = xyQI_c + xyQIcount
    QIcount = numU * numT
    QI_c = QO_c + QOcount
    OCcount = numOC*numT
    OC_c = QI_c + QIcount
    OCINVcount = numOC*numT
    OCINV_c = OC_c + OCcount
    OCtankoutcount = numOC*numT
    OCtankout_c = OCINV_c + OCINVcount
    Qcount = numOC*numO*numT
    Q_c = OCtankout_c + OCtankoutcount
    OINVcount = numO*numT
    OINV_c = Q_c + Qcount
    xQI1count = numU*numM*numM*numT
    xQI1_c = OINV_c + OINVcount
    xycount = numU*numM*numT
    xy_c = xQI1_c + xQI1count
    xyQI1count = numU*numM*numT
    xyQI1_c = xy_c + xycount
    constacount = 1
    consta_c = xyQI1_c + xyQI1count
    #===========================Variable Otankout(O,L,T)
    obj = [0]*numO*numL*numT
    ct  = ['C']*numO*numL*numT
    Otankoutcount = numO*numL*numT
    Otankout_c = consta_c + constacount
    namey = []
    charlist = [str(i) for i in range(1, Otankoutcount + 1)]
    for i in charlist:
        namey.append('Otankout' + i)
    prob.variables.add(obj=obj, types=ct, names = namey)
    # ======================================unit mode sum y=1, unit no-mode y=0 ==========================
    # names = "Constant_V"
    # prob.linear_constraints.add(lin_expr=[[[consta_c], [1.0]]],senses="E", rhs=[1.0], names=[names])
    if evaluate_is == 1:
        prob.objective.set_linear(consta_c, bp*np.sum(DV1)+np.sum(OCtank_ini)*0.5*apoc+np.sum(Otank_ini)*0.5*apo)#
    else:
        prob.objective.set_linear(consta_c, bp*np.sum(DV1)+np.sum(OCtank_ini)*0.5*apoc+np.sum(Otank_ini)*0.5*apo)#

    # ================================= OINV ========================================
    #OINV(O1,T) =e= OINVint(O1,T)+ sum(OC1,Q1(OC1,O1,T)*hours)- sum(L,Otankout(O1,L,T)*hours)
    for O in Olist[0:5]:
        i = 0
        i += 1
        names = "Volume_Otank" + str(O) + " " + str(i)
        ind = []
        val = []
        ind.append(O * numT + 0 + OINV_c)
        val.append(1.0)
        for OC in OClist[0:5]:
            ind.append(OC * numO * numT + O * numT + 0 + Q_c)
            val.append(-1.0 * hours)
        for L in Llist:
            ind.append(O * numL * numT + L * numT + 0 + Otankout_c)
            val.append(hours)
        prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[Otank_ini[O]], names=[names])
        for T in Tlist[1:]:
            i += 1
            names = "Volume_Otank " + str(O) + " " + str(i)
            ind = []
            val = []
            ind.append(O * numT + T + OINV_c)
            val.append(1.0)
            ind.append(O * numT + T-1 + OINV_c)
            val.append(-1.0)
            for OC in OClist[0:5]:
                ind.append(OC * numO * numT + O * numT + T + Q_c)
                val.append(-1.0 * hours)
            for L in Llist:
                ind.append(O * numL * numT + L * numT + T + Otankout_c)
                val.append(hours)
            prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[0.0], names=[names])
    for O in Olist[5:8]:
        i = 0
        i += 1
        names = "Volume_Otank" + str(O) + " " + str(i)
        ind = []
        val = []
        ind.append(O * numT + 0 + OINV_c)
        val.append(1.0)
        for OC in OClist[5:8]:
            ind.append(OC * numO * numT + O * numT + 0 + Q_c)
            val.append(-1.0 * hours)
        for L in Llist:
            ind.append(O * numL * numT + L * numT + 0 + Otankout_c)
            val.append(hours)
        prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[Otank_ini[O]], names=[names])
        for T in Tlist[1:]:
            i += 1
            names = "Volume_Otank " + str(O) + " " + str(i)
            ind = []
            val = []
            ind.append(O * numT + T + OINV_c)
            val.append(1.0)
            ind.append(O * numT + T-1 + OINV_c)
            val.append(-1.0)
            for OC in OClist[5:8]:
                ind.append(OC * numO * numT + O * numT + T + Q_c)
                val.append(-1.0 * hours)
            for L in Llist:
                ind.append(O * numL * numT + L * numT + T + Otankout_c)
                val.append(hours)
            prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[0.0], names=[names])

    # ======================================== Otankout in L limit =============================
    i = 0
    for L in Llist:
        for O in Olist:
            i += 1
            names = "OinL_" + str(i)
            ind = []
            val = []
            for T in Tlist:
                if T >= DS_num[L,0] and T <= DS_num[L,1]:
                    ind.append(O*numL*numT+L*numT+T+Otankout_c)
                    val.append(hours)
                else:
                    prob.linear_constraints.add(lin_expr=[[[O*numL*numT+L*numT+T+Otankout_c], [1]]],
                                                senses="E", rhs=[0],names=[names])
            prob.linear_constraints.add(lin_expr=[[ind, val]],
                                        senses="L", rhs=[float(DV1[L,O])],names=[names])

    #================================== OCINV ================================
    #                                  Volume State Function of gasoline oil tank  ===============================
    i = 0
    i += 1
    names = "Volume_OCtank" + str(0) + " " + str(i)
    ind = []
    val = []
    ind.append(OClist[0] * numT + 0 + OCINV_c)
    val.append(1.0)
    ind.append(Ulist[7] * numS * numT + Slist[0] * numT + 0 + QO_c)
    val.append(-1.0 * hours)
    ind.append(OClist[0] * numT + 0 + OCtankout_c)
    val.append(1.0 * hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[0]], names=[names])
    i = 0
    i += 1
    names = "Volume_OCtank" + str(1) + " " + str(i)
    ind = []
    val = []
    ind.append(OClist[1] * numT + 0 + OCINV_c)
    val.append(1.0)
    ind.append(Ulist[7] * numS * numT + Slist[1] * numT + 0 + QO_c)
    val.append(-1.0 * hours)
    ind.append(OClist[1] * numT + 0 + OCtankout_c)
    val.append(1.0 * hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[1]], names=[names])
    i = 0
    i += 1
    names = "Volume_OCtank" + str(2) + " " + str(i)
    ind = []
    val = []
    ind.append(OClist[2] * numT + 0 + OCINV_c)
    val.append(1.0)
    ind.append(Ulist[8] * numS * numT + Slist[0] * numT + 0 + QO_c)
    val.append(-1.0 * hours)
    ind.append(OClist[2] * numT + 0 + OCtankout_c)
    val.append(1.0 * hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[2]], names=[names])
    i = 0
    i += 1
    names = "Volume_OCtank" + str(3) + " " + str(i)
    ind = []
    val = []
    ind.append(OClist[3] * numT + 0 + OCINV_c)
    val.append(1.0)
    ind.append(OClist[3] * numT + 0 + OC_c)
    val.append(-1.0 * hours)
    ind.append(OClist[3] * numT + 0 + OCtankout_c)
    val.append(1.0 * hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[3]], names=[names])
    i = 0
    i += 1
    names = "Volume_OCtank" + str(4) + " " + str(i)
    ind = []
    val = []
    ind.append(OClist[4] * numT + 0 + OCINV_c)
    val.append(1.0)
    ind.append(Ulist[3] * numS * numT + Slist[0] * numT + 0 + QO_c)
    val.append(-1.0 * hours)
    ind.append(OClist[4] * numT + 0 + OCtankout_c)
    val.append(1.0 * hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[4]], names=[names])
    i = 0
    i += 1
    names = "Volume_OCtank" + str(5) + " " + str(i)
    ind = []
    val = []
    ind.append(OClist[5] * numT + 0 + OCINV_c)
    val.append(1.0)
    # ind.append(Ulist[5] * numS * numT + Slist[0] * numT + 0 + QO_c)
    # val.append(-1.0 * hours)
    ind.append(Ulist[6] * numS * numT + Slist[1] * numT + 0 + QO_c)
    val.append(-1.0 * hours)
    ind.append(OClist[5] * numT + 0 + OCtankout_c)
    val.append(1.0 * hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[5]], names=[names])
    i = 0
    i += 1
    names = "Volume_OCtank" + str(6) + " " + str(i)
    ind = []
    val = []
    ind.append(OClist[6] * numT + 0 + OCINV_c)
    val.append(1.0)
    ind.append(Ulist[5] * numS * numT + Slist[0] * numT + 0 + QO_c)
    val.append(-1.0 * hours)
    ind.append(OClist[6] * numT + 0 + OCtankout_c)
    val.append(1.0 * hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[6]], names=[names])
    i = 0
    i += 1
    names = "Volume_OCtank" + str(7) + " " + str(i)
    ind = []
    val = []
    ind.append(OClist[7] * numT + 0 + OCINV_c)
    val.append(1.0)
    ind.append(OClist[7] * numT + 0 + OC_c)
    val.append(-1.0 * hours)
    ind.append(OClist[7] * numT + 0 + OCtankout_c)
    val.append(1.0 * hours)
    prob.linear_constraints.add(lin_expr=[[ind, val]], senses="E", rhs=[OCtank_ini[7]], names=[names])

    prob.variables.set_lower_bounds(zip(range(Otankout_c, Otankoutcount + Otankout_c), [0] * Otankoutcount))
    prob.variables.set_upper_bounds(zip(range(Otankout_c, Otankoutcount + Otankout_c), [FOout_MAX] * Otankoutcount))
    prob.variables.set_lower_bounds(zip(range(y_c, y_c + ycount), Mode))
    prob.variables.set_upper_bounds(zip(range(y_c, y_c + ycount), Mode))



    for L in Llist:
        for O in Olist:
            for T in Tlist:
                prob.objective.set_linear(O * numL * numT + L * numT + T + Otankout_c, -bp*hours)#+T*10



    return [y_c,ycount,x_c,xcount,xycount,xy_c,QI_c,QIcount,QO_c,QOcount,Otankout_c,Otankoutcount,Q_c,Qcount,OINV_c,OINVcount,
            xQI_c,xQIcount,xQI1_c,xQI1count,xyQI_c,xyQIcount,xyQI1_c,xyQI1count,OCcount,OC_c,OCINVcount,OCINV_c,
            OCtankoutcount,OCtankout_c]

def refinery(numT, Tlist, numL, Llist, DS1, DV1, Pri, DS_num, OCtank_ini, Otank_ini,Mode,evaluate_is):
    #,QI_atm,QI_eth,QI_htu1
    prob = cplex.Cplex("Env_PRO_whole200.sav")
    # prob = cplex.Cplex()
    # prob.parameters.barrier.qcpconvergetol.set(1e-10)
    # prob.parameters.mip.tolerances.mipgap.set(0.0)
    # prob.parameters.timelimit.set(50)
    [y_c,ycount,x_c,xcount,xycount,xy_c,QI_c,QIcount,QO_c,QOcount,Otankout_c,Otankoutcount,Q_c,Qcount,OINV_c,OINVcount,
            xQI_c,xQIcount,xQI1_c,xQI1count,xyQI_c,xyQIcount,xyQI1_c,xyQI1count,OCcount,OC_c,OCINVcount,OCINV_c,
            OCtankoutcount,OCtankout_c] = buildmodel(prob,
                                    numT, Tlist, numL, Llist, DS1, DV1, Pri, DS_num, OCtank_ini, Otank_ini,Mode,evaluate_is)
    # prob.write("Env_PRO_whole.sav")
    # global nn
    # class TimeLimitCallback(MIPInfoCallback):
    #     def __call__(self):
    #         # if not self.aborted and self.has_incumbent():
    #         nn = 100.0 * self.get_MIP_relative_gap()
    #             # timeused = self.get_time() - self.starttime
    #             # if timeused > self.timelimit and gap < self.acceptablegap:
    #         print "sec., gap =", nn

    # timelim_cb = prob.register_callback(TimeLimitCallback)
    prob.solve()
    sol = prob.solution
    OCinv = sol.get_values(OCINV_c, OCINV_c + OCINVcount - 1)
    Oinv = sol.get_values(OINV_c, OINV_c + OINVcount - 1)
    Mode = sol.get_values(y_c, y_c + ycount - 1)
    FUin = sol.get_values(QI_c, QI_c + QIcount - 1)
    FOout = sol.get_values(Otankout_c, Otankout_c + Otankoutcount - 1)
    # solution.get_status() returns an integer code
    # print "Solution status = ", sol.get_status(), ":",
    # # the following line prints the corresponding string
    # print sol.status[sol.get_status()]
    # # a = 0
    # # for L in Llist:
    # #    for O in Olist:
    # #        a += DV1[L * numO + O]
    # print "Solution value  = ", sol.get_objective_value()
    # # print sum(sum(DV1)) * bp, "\n"  + sum(sum(DV1[:numL])) * bp
    # print "Banery number = ", prob.variables.get_num_binary()
    # # the following line prints the corresponding string
    # print "Variable number = ", prob.variables.get_num()
    # print "Contraint number = ", prob.linear_constraints.get_num(), "\n"
    # QI = sol.get_values(QI_c, QI_c + QIcount - 1)
    # # print "nn:",nn
    # # prob.register_callback(MIPInfoCallback)
    # # M: numU*numM*numT
    # M = sol.get_values(y_c, y_c + ycount - 1)
    # # print "Mode = ",M
    # header = Tlist[:]
    # M_header = header[:]
    # M_header.insert(0, "M")
    # M_table_ = [0] * (numT + 1)
    # M_table = []
    # for U in Ulist[0:9]:
    #     M_table.append(M_table_[:])
    # print "Unit Mode:  "
    # M_table[0][0] = "ATM"
    # M_table[1][0] = "VDU"
    # M_table[2][0] = "FCCU"
    # M_table[3][0] = "ETH"
    # M_table[4][0] = "HDS"
    # M_table[5][0] = "HTU1"
    # M_table[6][0] = "HTU2"
    # M_table[7][0] = "RF"
    # M_table[8][0] = "MTBE"
    # for U in Ulist[0:9]:
    #     for T in Tlist:
    #         for Mode in Mlist:
    #             if M[U * numM * numT + Mode * numT + T] >= 0.1:
    #                 M_table[U][T + 1] = Mode
    #                 break
    #             elif Mode == 3:
    #                 M_table[U][T + 1] = "N/A"
    # print tabulate(M_table, M_header, tablefmt="simple", numalign="center", floatfmt=".1f")
    #
    # # MT: numU*numM*numM*numT
    # MT = sol.get_values(x_c, x_c + xcount - 1)
    # MT_header = header[:]
    # MT_header.insert(0, "MT")
    # MT_table_ = [0] * (numT + 1)
    # MT_table = []
    # for U in Ulist:
    #     MT_table.append(MT_table_[:])
    # print "Unit Mode:  "
    # MT_table[0][0] = "ATM"
    # MT_table[1][0] = "VDU"
    # MT_table[2][0] = "FCCU"
    # MT_table[3][0] = "ETH"
    # MT_table[4][0] = "HDS"
    # MT_table[5][0] = "HTU1"
    # MT_table[6][0] = "HTU2"
    # MT_table[7][0] = "RF"
    # MT_table[8][0] = "MTBE"
    # for U in Ulist:
    #     for T in Tlist:
    #         AS = None
    #         for Mode in Mlist:
    #             for Mode_ in Mlist:
    #                 if MT[U * numM * numM * numT + Mode_ * numM * numT + Mode * numT + T] >= 0.1:
    #                     AS = str(Mode_) + "-" + str(Mode)
    #                     break
    #             if AS != None:
    #                 MT_table[U][T + 1] = AS
    #                 break
    #             elif Mode == 3:
    #                 MT_table[U][T + 1] = "N/A"
    # print tabulate(MT_table, MT_header, tablefmt="simple", numalign="center", floatfmt=".1f")
    # # M: numU*numM*numT
    # M = sol.get_values(xy_c, xy_c + xycount - 1)
    # header = Tlist[:]
    # M_header = header[:]
    # M_header.insert(0, "xy")
    # M_table_ = [0] * (numT + 1)
    # M_table = []
    # for U in Ulist[0:9]:
    #     M_table.append(M_table_[:])
    # print "Unit Mode:  "
    # M_table[0][0] = "ATM"
    # M_table[1][0] = "VDU"
    # M_table[2][0] = "FCCU"
    # M_table[3][0] = "ETH"
    # M_table[4][0] = "HDS"
    # M_table[5][0] = "HTU1"
    # M_table[6][0] = "HTU2"
    # M_table[7][0] = "RF"
    # M_table[8][0] = "MTBE"
    # for U in Ulist[0:9]:
    #     for T in Tlist:
    #         for Mode in Mlist:
    #             if M[U * numM * numT + Mode * numT + T] >= 0.1:
    #                 M_table[U][T + 1] = Mode
    #                 break
    #             elif Mode == 3:
    #                 M_table[U][T + 1] = "N/A"
    # print tabulate(M_table, M_header, tablefmt="simple", numalign="center", floatfmt=".1f")
    #
    # M = sol.get_values(y_c, y_c + ycount - 1)
    # header = Tlist[:]
    # M_header = header[:]
    # M_header.insert(0, "M")
    # M_table_ = [0] * (numT + 1)
    # M_table = []
    # for U in Ulist[0:9]:
    #     M_table.append(M_table_[:])
    # print "Unit Mode:  "
    # M_table[0][0] = "ATM"
    # M_table[1][0] = "VDU"
    # M_table[2][0] = "FCCU"
    # M_table[3][0] = "ETH"
    # M_table[4][0] = "HDS"
    # M_table[5][0] = "HTU1"
    # M_table[6][0] = "HTU2"
    # M_table[7][0] = "RF"
    # M_table[8][0] = "MTBE"
    # for U in Ulist[0:9]:
    #     for T in Tlist:
    #         b = []
    #         for Mode in Mlist:
    #             b.append(round(M[U * numM * numT + Mode * numT + T],1))
    #         M_table[U][T + 1] = b
    # print tabulate(M_table, M_header, tablefmt="simple", numalign="center", floatfmt=".1f")
    # M = sol.get_values(xy_c, xy_c + xycount - 1)
    # header = Tlist[:]
    # M_header = header[:]
    # M_header.insert(0, "xy")
    # M_table_ = [0] * (numT + 1)
    # M_table = []
    # for U in Ulist[0:9]:
    #     M_table.append(M_table_[:])
    # print "Unit Mode:  "
    # M_table[0][0] = "ATM"
    # M_table[1][0] = "VDU"
    # M_table[2][0] = "FCCU"
    # M_table[3][0] = "ETH"
    # M_table[4][0] = "HDS"
    # M_table[5][0] = "HTU1"
    # M_table[6][0] = "HTU2"
    # M_table[7][0] = "RF"
    # M_table[8][0] = "MTBE"
    # for U in Ulist[0:9]:
    #     for T in Tlist:
    #         b = []
    #         for Mode in Mlist:
    #             b.append(round(M[U * numM * numT + Mode * numT + T],1))
    #         M_table[U][T + 1] = b
    # print tabulate(M_table, M_header, tablefmt="simple", numalign="center", floatfmt=".1f")
    # # FUin: numU*numT
    # FinM = sol.get_values(QI_c, QI_c + QIcount - 1)
    # FUin_header = header[:]
    # FUin_header.insert(0, "FUin")
    # FUin_table_ = [0] * (numT + 1)
    # FUin_table = []
    # for U in Ulist[0:9]:
    #     FUin_table.append(FUin_table_[:])
    # print "Unit Input Flowrate:  "
    # FUin_table[0][0] = "ATM"
    # FUin_table[1][0] = "VDU"
    # FUin_table[2][0] = "FCCU"
    # FUin_table[3][0] = "ETH"
    # FUin_table[4][0] = "HDS"
    # FUin_table[5][0] = "HTU1"
    # FUin_table[6][0] = "HTU2"
    # FUin_table[7][0] = "RF"
    # FUin_table[8][0] = "MTBE"
    # for U in Ulist[0:9]:
    #     for T in Tlist:
    #         FUin_table[U][T + 1] = FinM[U * numT + T]
    # print tabulate(FUin_table, FUin_header, tablefmt="simple", numalign="center", floatfmt=".6f")
    # # QO: numU*numS*numT
    # QO = sol.get_values(QO_c, QO_c + QOcount - 1)
    # QO_header = header[:]
    # QO_header.insert(0, "QO")
    # QO_table_ = [0] * (numT + 1)
    # QO_table = []
    # for U in Ulist[0:9]:
    #     QO_table.append(QO_table_[:])
    # print "Unit Input Flowrate:  "
    # QO_table[0][0] = "ATM"
    # QO_table[1][0] = "VDU"
    # QO_table[2][0] = "FCCU"
    # QO_table[3][0] = "ETH"
    # QO_table[4][0] = "HDS"
    # QO_table[5][0] = "HTU1"
    # QO_table[6][0] = "HTU2"
    # QO_table[7][0] = "RF"
    # QO_table[8][0] = "MTBE"
    # for U in Ulist[0:9]:
    #     for T in Tlist:
    #         sa =[]
    #         for S in Slist:
    #             sa.append(round(QO[U * numS * numT + S * numT + T],6))
    #         QO_table[U][T + 1] = sa
    # print tabulate(QO_table, QO_header, tablefmt="simple", numalign="center", floatfmt=".6f")
    # # Print Fout
    # M = sol.get_values(y_c, y_c + ycount - 1)
    # MT = sol.get_values(x_c, x_c + xcount - 1)
    # OC = sol.get_values(OC_c, OC_c + OCcount - 1)
    # Fout_header = header[:]
    # Fout_header.insert(0, "Fout")
    # Fout_table_ = [0] * (numT + 1)
    # Fout_table = []
    # for U in range(11):
    #     Fout_table.append(Fout_table_[:])
    # print "Output flowrate of Units:  "
    # Fout_table[0][0] = "ATM"
    # Fout_table[1][0] = "VDU"
    # Fout_table[2][0] = "FCCU"
    # Fout_table[3][0] = "ETH"
    # Fout_table[4][0] = "HDS"
    # Fout_table[5][0] = "HTU1"
    # Fout_table[6][0] = "HTU2"
    # Fout_table[7][0] = "RF"
    # Fout_table[8][0] = "MTBE"
    # Fout_table[9][0] = "Fen1"
    # Fout_table[10][0] = "Fen2"
    # for U in [Ulist[0], Ulist[1], ]:
    #     for T in Tlist:
    #         S_all = []
    #         for S in Slist:
    #             Y = 0
    #             for Mode in Mlist[:2]:
    #                 for Mode_ in Mlist[:2]:
    #                     if MT[U * numM * numM * numT + Mode_ * numM * numT + Mode * numT + T] >= 0.1:
    #                         Y = tYield[U * numM * numM * numS + Mode_ * numM * numS + Mode * numS + S]
    #                         break
    #                 if Y == 0 and M[U * numM * numT + Mode * numT + T] >= 0.1:
    #                     Y = Yield[U * numM * numS + Mode * numS + S]
    #                     break
    #             S_all.append(round(FUin_table[U][T + 1] * Y * 0.01, 6))
    #         Fout_table[U][T + 1] = S_all
    # for U in [Ulist[2], Ulist[3], Ulist[4]]:
    #     for T in Tlist:
    #         S_all = []
    #         for S in Slist:
    #             Y = 0
    #             for Mode in Mlist:
    #                 for Mode_ in Mlist:
    #                     if MT[U * numM * numM * numT + Mode_ * numM * numT + Mode * numT + T] >= 0.1:
    #                         Y = tYield[U * numM * numM * numS + Mode_ * numM * numS + Mode * numS + S]
    #                         break
    #                 if Y == 0 and M[U * numM * numT + Mode * numT + T] >= 0.1:
    #                     Y = Yield[U * numM * numS + Mode * numS + S]
    #                     break
    #             S_all.append(round(FUin_table[U][T + 1] * Y * 0.01, 6))
    #         Fout_table[U][T + 1] = S_all
    # for U in [Ulist[5], Ulist[6]]:
    #     for T in Tlist:
    #         S_all = []
    #         for S in Slist:
    #             Y = 0
    #             for Mode in Mlist[:2]:
    #                 for Mode_ in Mlist[:2]:
    #                     if MT[U * numM * numM * numT + Mode_ * numM * numT + Mode * numT + T] >= 0.1:
    #                         Y = tYield[U * numM * numM * numS + Mode_ * numM * numS + Mode * numS + S]
    #                         break
    #                 if Y == 0 and M[U * numM * numT + Mode * numT + T] >= 0.1:
    #                     Y = Yield[U * numM * numS + Mode * numS + S]
    #                     break
    #             S_all.append(round(FUin_table[U][T + 1] * Y * 0.01, 6))
    #         Fout_table[U][T + 1] = S_all
    # for U in [Ulist[7], Ulist[8]]:
    #     for T in Tlist:
    #         S_all = []
    #         for S in Slist:
    #             S_all.append(round(FUin_table[U][T + 1] * Yield[U * numM * numS + 0 * numS + S] * 0.01, 6))
    #         Fout_table[U][T + 1] = S_all
    # for U in [9]:
    #     for T in Tlist:
    #         Fout_table[U][T + 1] = [round(OC[7 * numT + T], 6), round(FUin_table[5][T + 1], 3)]
    # for U in [10]:
    #     for T in Tlist:
    #         Fout_table[U][T + 1] = [round(OC[3 * numT + T], 6), round(FUin_table[3][T + 1], 3)]
    # print tabulate(Fout_table, Fout_header, tablefmt="simple", numalign="center", floatfmt=".1f")
    #
    # # FOout: numO*numL*numT
    # Otankout = sol.get_values(Otankout_c, Otankout_c + Otankoutcount - 1)
    # # print "Otankout = ", Otankout
    # FOout_header = header[:]
    # FOout_header.insert(0, "Otankout")
    # FOout_table_ = [0] * (numT + 1)
    # FOout_table = []
    # for O in Olist:
    #     for L in range(numL):
    #         FOout_table.append(FOout_table_[:])
    # print "Flowrate of O to Order: "
    # for O in Olist:
    #     for L in range(numL):
    #         FOout_table[O * numL + L][0] = "O" + str(O) + " L" + str(L)
    #         for T in Tlist:
    #             FOout_table[O * numL + L][T + 1] = Otankout[O * numL * numT + L * numT + T]
    # print tabulate(FOout_table, FOout_header, tablefmt="simple", numalign="center", floatfmt=".3f")
    # FOout = sol.get_values(Otankout_c, Otankout_c + Otankoutcount - 1)
    # FOout_header = header[:]
    # FOout_header.insert(0, "FOout")
    # FOout_table_ = [0] * (numT + 1)
    # FOout_table = []
    # for L in Llist:
    #     FOout_table.append(FOout_table_[:])
    # print "Flowrate of O to Order: "
    # for L in range(numL):
    #     FOout_table[L][0] = " L" + str(L)
    #     for T in Tlist:
    #         g = []
    #         for O in Olist:
    #             g.append(round(FOout[O * numL * numT + L * numT + T], 1))
    #         FOout_table[L][T + 1] = g
    # print tabulate(FOout_table, FOout_header, tablefmt="simple", numalign="center", floatfmt=".3f")
    # FOout_header = header[:]
    # FOout_header.insert(0, "order left")
    # FOout_table_ = [0] * (numT + 1)
    # FOout_table = []
    # for L in Llist:
    #     FOout_table.append(FOout_table_[:])
    # print "Flowrate of O to Order: "
    # FOout_sum = np.zeros((numO, numL))
    # for L in range(numL):
    #     FOout_table[L][0] = " L" + str(L)
    #     for T in Tlist:
    #         g = []
    #         for O in Olist:
    #             g.append(round(DV1[L][O] - FOout_sum[O, L], 1))
    #             FOout_sum[O, L] += FOout[O * numL * numT + L * numT + T]
    #         FOout_table[L][T + 1] = g
    # print tabulate(FOout_table, FOout_header, tablefmt="simple", numalign="center", floatfmt=".3f")
    #
    # # VO: numO*numT
    # OCtankout = sol.get_values(OCtankout_c, OCtankout_c + OCtankoutcount - 1)
    # VO_header = header[:]
    # VO_header.insert(0, "OCtankout")
    # VO_table_ = [0] * (numT + 1)
    # VO_table = []
    # for O in Olist:
    #     VO_table.append(VO_table_[:])
    # print "Output flowrate of OC: "
    # for O in Olist:
    #     VO_table[O][0] = "O" + str(O)
    #     for T in Tlist:
    #         VO_table[O][T + 1] = OCtankout[O * numT + T]
    # print tabulate(VO_table, VO_header, tablefmt="simple", numalign="center", floatfmt=".3f")
    #
    # # VOC: numOC*numT
    # VOC = sol.get_values(OCINV_c, OCINV_c + OCINVcount - 1)
    # # print "VOC = ",VOC
    # VOC_header = header[:]
    # VOC_header.insert(0, "VOC")
    # VOC_table_ = [0] * (numT + 1)
    # VOC_table = []
    # for OC in OClist:
    #     VOC_table.append(VOC_table_[:])
    # print "Volume of OC: "
    # for OC in OClist:
    #     VOC_table[OC][0] = "OC" + str(OC)
    #     for T in Tlist:
    #         VOC_table[OC][T + 1] = VOC[OC * numT + T]
    # print tabulate(VOC_table, VOC_header, tablefmt="simple", numalign="center", floatfmt=".6f")
    # # print "VOC:", np.swapaxes(np.round(VOC, 2).reshape(numOC, numT), 0, 1).reshape((numOC*numT,)).tolist()
    #
    # # VO: numO*numT
    # VO = sol.get_values(OINV_c, OINV_c + OINVcount - 1)
    # # print "VO = ",VO
    # VO_header = header[:]
    # VO_header.insert(0, "VO")
    # VO_table_ = [0] * (numT + 1)
    # VO_table = []
    # for O in Olist:
    #     VO_table.append(VO_table_[:])
    # print "Volume of O: "
    # for O in Olist:
    #     VO_table[O][0] = "O" + str(O)
    #     for T in Tlist:
    #         VO_table[O][T + 1] = VO[O * numT + T]
    # print tabulate(VO_table, VO_header, tablefmt="simple", numalign="center", floatfmt=".3f")
    # # print "VO:", np.swapaxes(np.round(VO, 2).reshape(numO, numT), 0, 1).reshape((numO*numT,)).tolist()
    # # FOCO: numOC*numO*numT
    # FOCO = sol.get_values(Q_c, Q_c + Qcount - 1)
    # FOCO_header = header[:]
    # FOCO_header.insert(0, "FOCO")
    # FOCO_table_ = [0] * (numT + 1)
    # FOCO_table = []
    # for OC in OClist:
    #     for O in Olist:
    #         FOCO_table.append(FOCO_table_[:])
    # print "blending Flowrate of OC to O: "
    # for OC in OClist:
    #     for O in Olist:
    #         FOCO_table[OC * numO + O][0] = "OC" + str(OC) + " O" + str(O)
    #         for T in Tlist:
    #             FOCO_table[OC * numO + O][T + 1] = round(FOCO[OC * numO * numT + O * numT + T], 6)
    # print tabulate(FOCO_table, FOCO_header, tablefmt="simple", numalign="center", floatfmt=".6f")
    #
    # M = sol.get_values(xyQI_c, xyQI_c + xyQIcount - 1)
    # header = Tlist[:]
    # M_header = header[:]
    # M_header.insert(0, "xyQI")
    # M_table_ = [0] * (numT + 1)
    # M_table = []
    # for U in Ulist[0:9]:
    #     M_table.append(M_table_[:])
    # print "Unit Mode:  "
    # M_table[0][0] = "ATM"
    # M_table[1][0] = "VDU"
    # M_table[2][0] = "FCCU"
    # M_table[3][0] = "ETH"
    # M_table[4][0] = "HDS"
    # M_table[5][0] = "HTU1"
    # M_table[6][0] = "HTU2"
    # M_table[7][0] = "RF"
    # M_table[8][0] = "MTBE"
    # for U in Ulist[0:9]:
    #     for T in Tlist:
    #         b = []
    #         for Mode in Mlist:
    #             b.append(round(M[U * numM * numT + Mode * numT + T],6))
    #         M_table[U][T + 1] = b
    # print tabulate(M_table, M_header, tablefmt="simple", numalign="center", floatfmt=".6f")
    # M = sol.get_values(xyQI1_c, xyQI1_c + xyQI1count - 1)
    # header = Tlist[:]
    # M_header = header[:]
    # M_header.insert(0, "xyQI1")
    # M_table_ = [0] * (numT + 1)
    # M_table = []
    # for U in Ulist[0:9]:
    #     M_table.append(M_table_[:])
    # print "Unit Mode:  "
    # M_table[0][0] = "ATM"
    # M_table[1][0] = "VDU"
    # M_table[2][0] = "FCCU"
    # M_table[3][0] = "ETH"
    # M_table[4][0] = "HDS"
    # M_table[5][0] = "HTU1"
    # M_table[6][0] = "HTU2"
    # M_table[7][0] = "RF"
    # M_table[8][0] = "MTBE"
    # for U in Ulist[0:9]:
    #     for T in Tlist:
    #         b = []
    #         for Mode in Mlist:
    #             b.append(round(M[U * numM * numT + Mode * numT + T],6))
    #         M_table[U][T + 1] = b
    # print tabulate(M_table, M_header, tablefmt="simple", numalign="center", floatfmt=".6f")
    #
    # M = sol.get_values(xQI_c,xQI_c+xQIcount-1)
    # print "sum xQI:",sum(M)
    # header = Tlist[:]
    # M_header = header[:]
    # M_header.insert(0, "xQI")
    # M_table_ = [0] * (numT + 1)
    # M_table = []
    # for U in Ulist[0:9]:
    #     M_table.append(M_table_[:])
    # print "Unit Mode:  "
    # M_table[0][0] = "ATM"
    # M_table[1][0] = "VDU"
    # M_table[2][0] = "FCCU"
    # M_table[3][0] = "ETH"
    # M_table[4][0] = "HDS"
    # M_table[5][0] = "HTU1"
    # M_table[6][0] = "HTU2"
    # M_table[7][0] = "RF"
    # M_table[8][0] = "MTBE"
    # for U in Ulist[0:9]:
    #     for T in Tlist:
    #         for Mode in Mlist:
    #             for Mode1 in Mlist:
    #                 if M[U * numM * numM * numT + Mode1 * numM * numT + Mode * numT + T] > 0.001:
    #                     M_table[U][T + 1] = [Mode1,Mode,round(M[U * numM * numM * numT + Mode1 * numM * numT + Mode * numT + T],6)]
    # print tabulate(M_table, M_header, tablefmt="simple", numalign="center", floatfmt=".6f")
    # M = sol.get_values(xQI1_c,xQI1_c+xQI1count-1)
    # # print "sum xQI1:",sum(M)
    # header = Tlist[:]
    # M_header = header[:]
    # M_header.insert(0, "xQI1")
    # M_table_ = [0] * (numT + 1)
    # M_table = []
    # for U in Ulist[0:9]:
    #     M_table.append(M_table_[:])
    # print "Unit Mode:  "
    # M_table[0][0] = "ATM"
    # M_table[1][0] = "VDU"
    # M_table[2][0] = "FCCU"
    # M_table[3][0] = "ETH"
    # M_table[4][0] = "HDS"
    # M_table[5][0] = "HTU1"
    # M_table[6][0] = "HTU2"
    # M_table[7][0] = "RF"
    # M_table[8][0] = "MTBE"
    # for U in Ulist[0:9]:
    #     for T in Tlist:
    #         for Mode in Mlist:
    #             for Mode1 in Mlist:
    #                 if M[U * numM * numM * numT + Mode1 * numM * numT + Mode * numT + T] > 0.001:
    #                     M_table[U][T + 1] = [Mode1,Mode,round(M[U * numM * numM * numT + Mode1 * numM * numT + Mode * numT + T],6)]
    # print tabulate(M_table, M_header, tablefmt="simple", numalign="center", floatfmt=".6f")
    # # PRO:numO*numT
    # FOCO = sol.get_values(Q_c, Q_c + Qcount - 1)
    # PRO_header = header[:]
    # PRO_header.insert(0, "PRO")
    # PRO_table_ = [0] * (numT + 1)
    # PRO_table = []
    # for O in Olist:
    #     for i in range(3):
    #         PRO_table.append(PRO_table_[:])
    # for O in Olist[0:5]:
    #     PRO_table[O * 3 + 0][0] = "max"
    #     PRO_table[O * 3 + 1][0] = "O" + str(O)
    #     PRO_table[O * 3 + 2][0] = "min"
    #     for T in Tlist:
    #         F_sum = sum([FOCO[OC * numO * numT + O * numT + T] for OC in OClist[0:5]])
    #         if F_sum >= 0.00001:
    #             PRO_table[O * 3 + 0][T + 1] = "[" + str(PROMAX[0 * numO + O]) + " " + str(PROMAX[2 * numO + O]) + "]"
    #             PRO_table[O * 3 + 1][T + 1] = "[" + str(round(
    #                 sum([FOCO[OC * numO * numT + O * numT + T] * PRO[0 * numOC + OC] for OC in OClist[0:5]]) / F_sum,
    #                 2)) + " " + \
    #                                           str(round(sum(
    #                                               [FOCO[OC * numO * numT + O * numT + T] * PRO[2 * numOC + OC] for OC in
    #                                                OClist[0:5]]) / F_sum, 4)) + "]"
    #             PRO_table[O * 3 + 2][T + 1] = "[" + str(PROMIN[0 * numO + O]) + " " + str(PROMIN[2 * numO + O]) + "]"
    #         # elif T != 0:
    #         #     PRO_table[O * 3 + 0][T + 1] = "[" + str(PROMAX[0 * numO + O]) + " " + str(PROMAX[2 * numO + O]) + "]"
    #         #     PRO_table[O * 3 + 1][T + 1] = PRO_table[O * 3 + 1][T]
    #         #     PRO_table[O * 3 + 2][T + 1] = "[" + str(PROMIN[0 * numO + O]) + " " + str(PROMIN[2 * numO + O]) + "]"
    #         else:
    #             PRO_table[O * 3 + 0][T + 1] = "[" + str(PROMAX[0 * numO + O]) + " " + str(PROMAX[2 * numO + O]) + "]"
    #             PRO_table[O * 3 + 1][T + 1] = "INI"
    #             PRO_table[O * 3 + 2][T + 1] = "[" + str(PROMIN[0 * numO + O]) + " " + str(PROMIN[2 * numO + O]) + "]"
    # for O in Olist[5:8]:
    #     PRO_table[O * 3 + 0][0] = "max"
    #     PRO_table[O * 3 + 1][0] = "O" + str(O)
    #     PRO_table[O * 3 + 2][0] = "min"
    #     for T in Tlist:
    #         F_sum = sum([FOCO[OC * numO * numT + O * numT + T] for OC in OClist[5:8]])
    #         if F_sum >= 0.001:
    #             PRO_table[O * 3 + 0][T + 1] = "[" + str(PROMAX[1 * numO + O]) + " " + str(
    #                 PROMAX[2 * numO + O]) + " " + str(PROMAX[3 * numO + O]) + "]"
    #             PRO_table[O * 3 + 1][T + 1] = "[" + str(round(
    #                 sum([FOCO[OC * numO * numT + O * numT + T] * PRO[1 * numOC + OC] for OC in OClist[5:8]]) / F_sum,
    #                 2)) + " " + \
    #                                           str(round(sum(
    #                                               [FOCO[OC * numO * numT + O * numT + T] * PRO[2 * numOC + OC] for OC in
    #                                                OClist[5:8]]) / F_sum, 4)) + " " + \
    #                                           str(round(sum(
    #                                               [FOCO[OC * numO * numT + O * numT + T] * PRO[3 * numOC + OC] for OC in
    #                                                OClist[5:8]]) / F_sum, 4)) + "]"
    #             PRO_table[O * 3 + 2][T + 1] = "[" + str(PROMIN[1 * numO + O]) + " " + str(
    #                 PROMIN[2 * numO + O]) + " " + str(PROMIN[3 * numO + O]) + "]"
    #         # elif T != 0:
    #         #     PRO_table[O * 3 + 0][T + 1] = "[" + str(PROMAX[1 * numO + O]) + " " + str(
    #         #         PROMAX[2 * numO + O]) + " " + str(PROMAX[3 * numO + O]) + "]"
    #         #     PRO_table[O * 3 + 1][T + 1] = PRO_table[O * 3 + 1][T]
    #         #     PRO_table[O * 3 + 2][T + 1] = "[" + str(PROMIN[1 * numO + O]) + " " + str(
    #         #         PROMIN[2 * numO + O]) + " " + str(PROMIN[3 * numO + O]) + "]"
    #         else:
    #             PRO_table[O * 3 + 0][T + 1] = "[" + str(PROMAX[1 * numO + O]) + " " + str(
    #                 PROMAX[2 * numO + O]) + " " + str(PROMAX[3 * numO + O]) + "]"
    #             PRO_table[O * 3 + 1][T + 1] = "INI"
    #             PRO_table[O * 3 + 2][T + 1] = "[" + str(PROMIN[1 * numO + O]) + " " + str(
    #                 PROMIN[2 * numO + O]) + " " + str(PROMIN[3 * numO + O]) + "]"
    # print tabulate(PRO_table, PRO_header, tablefmt="simple", numalign="center", floatfmt=".3f")
    #
    # xQI = sol.get_values(xQI_c, xQI_c + xQIcount - 1)
    # xyQI = sol.get_values(xyQI_c, xyQI_c + xyQIcount - 1)
    # QI = sol.get_values(QI_c, QI_c+QIcount-1)
    # ObjVal = 0
    # for T in Tlist:
    #     ObjVal += QI[Ulist[0]*numT+T]*OPC*hours
    # print "crude oil cost:",ObjVal
    # a = 0
    # for U in Ulist[0:2]:
    #     for M in Mlist[0:2]:
    #         for M1 in Mlist[0:2]:
    #             for T in Tlist:
    #                 if M1 != M:
    #                     a += xQI[U*numM*numM*numT+M*numM*numT+M1*numT+T]*hours*tOpCost[U*numM*numM+M*numM+M1]
    # for U in Ulist[0:2]:
    #     for M in Mlist[0:2]:
    #         for T in Tlist:
    #             a += xyQI[U * numM * numT + M * numT + T]*hours * OpCost[U * numM + M]
    # for U in Ulist[2:5]:
    #     for M in Mlist[0:4]:
    #         for M1 in Mlist[0:4]:
    #             for T in Tlist:
    #                 if M1 != M:
    #                     a += xQI[U*numM*numM*numT+M*numM*numT+M1*numT+T]*hours*tOpCost[U*numM*numM+M*numM+M1]
    # for U in Ulist[2:5]:
    #     for M in Mlist[0:4]:
    #         for T in Tlist:
    #             a += xyQI[U * numM * numT + M * numT + T]*hours * OpCost[U * numM + M]
    # for U in Ulist[5:7]:
    #     for M in Mlist[0:2]:
    #         for M1 in Mlist[0:2]:
    #             for T in Tlist:
    #                 if M1 != M:
    #                     a += xQI[U*numM*numM*numT+M*numM*numT+M1*numT+T]*hours*tOpCost[U*numM*numM+M*numM+M1]
    # for U in Ulist[5:7]:
    #     for M in Mlist[0:2]:
    #         for T in Tlist:
    #             a += xyQI[U * numM * numT + M * numT + T]*hours * OpCost[U * numM + M]
    # for U in Ulist[7:9]:
    #     for T in Tlist:
    #             a += QI[U*numT+T]*hours*OpCost[U*numM+Mlist[0]]
    # ObjVal += a
    # print "Unit operation cost:",a
    # a = 0
    # for O in Olist:
    #     for T in Tlist:
    #         if T == 0:
    #             a += (Otank_ini[O] + VO[O * numT + T]) * 0.5 * apo
    #         if T != 0:
    #             a += (VO[O * numT + T - 1] + VO[O * numT + T]) * 0.5 * apo
    #     # for T in Tlist:
    #     #     a += VO[O*numT+T]*apo
    # ObjVal += a
    # print "O inventory cost:",a
    # a = 0
    # for OC in OClist:
    #     for T in Tlist[:]:
    #         if T == 0:
    #             a += (OCtank_ini[OC] + VOC[OC * numT + T]) * 0.5 * apoc
    #         if T != 0:
    #             a += (VOC[OC * numT + T - 1] + VOC[OC * numT + T]) * 0.5 * apoc
    #     # for T in Tlist:
    #     #     a += VOC[OC*numT+T]*apoc
    # ObjVal += a
    # print "OC inventory cost:",a
    # a = 0
    # for L in Llist:
    #     for O in Olist:
    #         a += DV1[L,O]*bp
    #         for T in Tlist:
    #             a -= Otankout[O*numL*numT+L*numT+T]*(hours*bp-T*10)
    # ObjVal += a
    # print "Order delay cost:",a
    # Obj_1 = np.zeros((numL, numO))
    # print "Order amount delay (DV1): "
    # for L in range(numL):
    #     for O in Olist:
    #         for T in Tlist:
    #             Obj_1[L,O] += Otankout[O * numL * numT + L * numT + T] * hours
    #         Obj_1[L,O] = round(DV1[L,O] - Obj_1[L,O], 6)
    # print Obj_1
    # print "original order:"
    # print DV1[:numL]
    # print "object value : ",ObjVal
    return  OCinv,Oinv,Mode,FUin,FOout,sol.get_objective_value()   # + sum(sum(DV1[:numL])) * bp

def printYield():
    # yield:numU*numM*numS
    Y_header = Slist[:]
    Y_header.insert(0,"Yield")
    Y_table_ = [0] * (numM + 1)
    Y_table = []
    for U in Ulist[0:9]:
        Y_table.append(Y_table_[:])
    for U in Ulist[0:9]:
        for M in Mlist:
            Y_table[U][0] = "U"+str(U)
            S_all = []
            for S in Slist:
                S_all.append(round(Yield[U*numM*numS+M*numS+S],4))
            Y_table[U][M+1] = S_all
    print tabulate(Y_table, Y_header, tablefmt="simple", numalign="center", floatfmt=".3f")
    # tyield:numU*numM*numS
    tY_header = ['00','01','02','03',10,11,12,13,20,21,22,23,30,31,32,33]
    tY_header.insert(0, "tYield")
    tY_table_ = [0] * (numM*numM + 1)
    tY_table = []
    for U in Ulist[0:9]:
        tY_table.append(tY_table_[:])
    for U in Ulist[0:9]:
        for M in Mlist:
            for M_ in Mlist:
                tY_table[U ][0] = "U" + str(U)
                S_all = []
                for S in Slist:
                    S_all.append(round(tYield[U * numM * numM * numS + M * numM * numS + M_ * numS + S],4))
                tY_table[U][M*numM + M_ + 1] = S_all
    print tabulate(tY_table, tY_header, tablefmt="simple", numalign="center", floatfmt=".3f")

    # Cost:numU*numM
    Cost_header = Mlist[:]
    Cost_header.insert(0,"Cost")
    Cost_table_ = [0] * (numM + 1)
    Cost_table = []
    for U in Ulist[0:9]:
        Cost_table.append(Cost_table_[:])
    for U in Ulist[0:9]:
        Cost_table[U][0] = "U" + str(U)
        for M in Mlist:
            Cost_table[U][M + 1] = OpCost[U * numM + M]
    print tabulate(Cost_table, Cost_header, tablefmt="simple", numalign="center", floatfmt=".3f")
    # tCost:numU*numM*numM
    tCost_header = ['00','01','02','03',10,11,12,13,20,21,22,23,30,31,32,33]
    tCost_header.insert(0,"tCost")
    tCost_table_ = [0] * (numM*numM + 1)
    tCost_table = []
    for U in Ulist[0:9]:
        tCost_table.append(tCost_table_[:])
    for U in Ulist[0:9]:
        tCost_table[U][0] = "U" + str(U)
        for M in Mlist:
            for M_ in Mlist:
                tCost_table[U][M * numM + M_ + 1] = tOpCost[U * numM * numM + M * numM + M_]
    print tabulate(tCost_table, tCost_header, tablefmt="simple", numalign="center", floatfmt=".3f")

def run(CASE):
    # printYield()
    for i in range(len(CASE)):
        if CASE[i] == 'ShiL-case1':
            numT = 8
            Tlist = range(numT)
            numL1 = 2
            Llist1 = range(numL1)
            OCtank_ini = [0,0,0,0,0,0,0,0]
            Otank_ini = [0]*numO
            DS_num = [[0,6],[2,8]]
            DS1 = [[1, 1, 1, 1, 1, 1, 0, 0], [0, 0, 1, 1, 1, 1, 1, 1]]
            DV1 = [[100.,400.,200.,100.,550.,1000.,600.,700.],
                   [100.,300.,100.,100.,700.,800.,700.,900.]]
            DV1 = np.array(DV1)
            DS1 = np.array(DS1)
            DS_num = np.array(DS_num)
            Pri = 1
            Mode = 0
            sample = 0
            Mode = [0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -0.0, -0.0, -0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0,
                 -0.0, 0.0, 0.0, -0.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, -0.0, -0.0,
                 0.0, 0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, -0.0, -0.0, 1.0, 1.0, 1.0, 1.0,
                 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, -0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, -0.0, -0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
                 -0.0, 0.0, 0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

            for u in Ulist[7:9]:
                for M in [Mlist[0]]:
                    for t in Tlist:
                        Mode[u*numM*numT+M*numT+t]=1
            QI_atm = [234.64,222.675,200.,200.,285.653,200.,200.,219.327]
            QI_eth = [5.,5.,5.,5.,5.,5.,5.,5.]
            # QI_htu1 = [38.806, 34.752, 34.752, 34.752, 46.047, 38.97, 30.698, 33.852]
            # QI_htu1 = [45.527,38.692,34.752,34.752,43.845,30.698,30.698,33.664]
            QI_htu1 = [45.527,38.692,34.752,34.752,43.8445,30.698,30.698,33.664]
            refinery(numT, Tlist, numL1, Llist1, DS1, DV1, Pri, DS_num, OCtank_ini, Otank_ini,Mode)#,QI_atm,QI_eth,QI_htu1
        elif CASE[i] == '12s3o':
            NCmax = 15
            numT = 12
            Tlist = range(numT)
            numL1 = 3
            Llist1 = range(numL1)
            DS_num = [[0,12],[2,6],[4,8]]
            DS1 = [[1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1], [0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0]]
            DV1 = [[400.,200.,300.,100.,250.,500.,400.,600.],
                   [50.,50.,100.,100.,200.,300.,300.,300.],
                   [100.,100.,100.,100.,200.,300.,200.,400.]]
            OCtank_ini = [0,0,0,0,0,0,0,0]
            Otank_ini = [0]*numO
            DV1 = np.array(DV1)
            DS1 = np.array(DS1)
            DS_num = np.array(DS_num)
            Pri = 1
            Mode = 0
            sample = 0
            Mode = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, -0.0, -0.0,
                 -0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, 0.0, 0.0, -0.0, -0.0, -0.0, -0.0,
                 -0.0, 1.0, 1.0, 1.0, -0.0, 0.0, -0.0, -0.0, -0.0, -0.0, -0.0, -0.0, -0.0, 0.0, -0.0, 0.0, 1.0, 1.0,
                 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -0.0, -0.0, 0.0, -0.0, -0.0, 0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, -0.0, -0.0, 0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, -0.0, -0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -0.0, -0.0, 0.0,
                 -0.0, -0.0, 0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, -0.0, 0.0, -0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, -0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, 1.0, 1.0, 1.0,
                 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0,
                 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
                 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, -0.0, -0.0, -0.0, -0.0, 0.0, -0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

            for u in Ulist[7:9]:
                for M in [Mlist[0]]:
                    for t in Tlist:
                        Mode[u*numM*numT+M*numT+t]=1
            QI_atm = [200.000,200.000,200.000 , 200.000  ,200.000 , 200.000 , 200.000  ,200.000  ,200.000,  200.000 , 200.000,  200.000]
            QI_eth = [ 6.936  ,  7.045 ,   7.137   , 8.472 ,   9.360 ,  14.237 ,  11.515   ,15.074 ,  15.074 ,  15.074 ,  15.074 ,   5.000]
            # QI_htu1 = [38.806, 34.752, 34.752, 34.752, 46.047, 38.97, 30.698, 33.852]
            # QI_htu1 = [45.527,38.692,34.752,34.752,43.845,30.698,30.698,33.664]
            QI_htu1 = [30.698  , 30.698,   30.698  , 30.698   ,30.698  , 30.698 ,  30.698  , 30.698 ,  30.698  ,  5.000   , 5.000  ,  5.000]

            refinery(numT, Tlist, numL1, Llist1, DS1, DV1, Pri, DS_num,  OCtank_ini, Otank_ini,Mode) #,QI_atm,QI_eth,QI_htu1
        elif CASE[i] == '12s3o_none':
            NCmax = 15
            numT = 12
            Tlist = range(numT)
            numL1 = 0
            Llist1 = range(numL1)
            DS_num = [[0,0],[0,0],[0,0]]
            DS1 = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
            DV1 = [[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                   [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                   [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]
            OCtank_ini = [0,0,0,0,0,0,0,0]
            Otank_ini = [0]*numO
            DV1 = np.array(DV1)
            DS1 = np.array(DS1)
            DS_num = np.array(DS_num)
            Pri = 0
            sample = 0
            Mode = [0]*numU*numM*numT
            # QI_atm = [200.000,200.000,200.000 , 200.000  ,200.000 , 200.000 , 200.000  ,200.000  ,200.000,  200.000 , 200.000,  200.000]
            # QI_eth = [ 6.936  ,  7.045 ,   7.137   , 8.472 ,   9.360 ,  14.237 ,  11.515   ,15.074 ,  15.074 ,  15.074 ,  15.074 ,   5.000]
            # # QI_htu1 = [38.806, 34.752, 34.752, 34.752, 46.047, 38.97, 30.698, 33.852]
            # # QI_htu1 = [45.527,38.692,34.752,34.752,43.845,30.698,30.698,33.664]
            # QI_htu1 = [30.698  , 30.698,   30.698  , 30.698   ,30.698  , 30.698 ,  30.698  , 30.698 ,  30.698  ,  5.000   , 5.000  ,  5.000]

            refinery(numT, Tlist, numL1, Llist1, DS1, DV1, Pri, DS_num, OCtank_ini, Otank_ini,Mode) #,QI_atm,QI_eth,QI_htu1
        elif CASE[i] == '18s3o':
            NCmax = 30
            numT = 18
            Tlist = range(numT)
            numL1 = 3
            Llist1 = range(numL1)
            DS1 = [[1, 1, 1, 1, 1, 1, 0, 0, 0, 0,  0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 1, 1, 1, 1, 1, 1,  1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  0, 0, 1, 1, 1, 1, 1, 1, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  0, 0, 1, 1, 1, 1, 1, 1, 0, 0]]
            DV1 = [[90.,80.,70.,80.,70.,120.,150.,130.],
                  [20.,50.,40.,30.,20.,120.,130.,205.],
                  [40.,50.,45.,52.,60.,120.,130.,130.],
                  [380.,70.,0.,150.,1125.,650.,1500.,2250.]] # numL*numO
            DS_num = [[0,5],[4,14],[12,17]]
            OCtank_ini = [0,0,0,0,0,0,0,0]
            Otank_ini = [0]*numO
            DV1 = np.array(DV1)
            DS1 = np.array(DS1)
            DS_num = np.array(DS_num)
            Pri = 1
            sample = 0
            Mode = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -0.0,
                    -0.0, -0.0, -0.0, -0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0,
                    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -0.0, 0.0, 0.0, -0.0, -0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, 0.0, 0.0, 0.0, -0.0, 0.0, 0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    -0.0, -0.0, -0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, 0.0, -0.0, 0.0, 0.0, 0.0, 0.0, -0.0, -0.0, 1.0,
                    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, 0.0, -0.0, -0.0, -0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
                    1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, -0.0, 0.0, -0.0, -0.0, -0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0,
                    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0,
                    1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, -0.0,
                    -0.0, -0.0, -0.0, -0.0, -0.0, -0.0, -0.0, -0.0, -0.0, -0.0, -0.0, -0.0, -0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
            for u in Ulist[7:9]:
                for M in [Mlist[0]]:
                    for t in Tlist:
                        Mode[u*numM*numT+M*numT+t]=1
            VOC = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                   0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 9.011932009398848, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                   0.5715354292839647, 1.1320696830866557, 1.6999295128679717, 2.3000839593084863, 2.888687200200794,
                   3.59625431204425, 3.553878812312249, 3.949933489094862, 4.158103968443012, 4.378415553531016,
                   6.135470483328418, 8.398931149101832, 3.6253383532680257, 3.8335088326161753, 4.07356927984634,
                   4.436060470327375, 5.5370235736254285, 7.926285370707028, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                   0.0, 0.0, 8.739951172538424, 20.545627124257358, 0.0, 0.0, 0.0, 0.0, 0.0, 1.7325680923623175, 0.0,
                   0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 3.7840786345198554, 8.444078634519855, 0.0, 0.0, 0.0,
                   0.0, 0.0, 0.0, 0.0, 0.0, 5.582746019410969, 52.28977486085253, 11.91465813436701, 40.23099766910362,
                   43.416293676568706, 46.60158968403379, 71.0417988770403, 101.5702825380136, 132.09876619898688,
                   169.7731818110169, 88.70204452327414, 88.95540918881287, 119.78338063263567, 151.61128743729927,
                   183.43919424196287, 222.2862256152525, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                   34.50874675862072, 0.0, 0.0, 0.0, 0.0, 0.0, 0.7072823309053486, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                   0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 25.698000000000004]
            VO = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                  0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                  0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                  0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                  0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                  0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                  0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
                  0.0, 0.0, 0.0, 0.0]
            QI_atm = [300.000,300.000,300.000,300.000,300.000,300.000,200.000,200.000,200.000,200.000,200.000,200.000,200.000,200.000,200.000,200.000,200.000,200.000]
            QI_eth = [5.000,5.000,5.000,5.000,5.000,5.000,5.000,5.000,5.000,5.000,5.000,5.000,5.000,5.000,5.000,5.000,5.000,5.000]
            QI_htu1 = [46.0470000,46.0470000,46.0470000,46.0470000,46.0470000,46.0470000,34.7520000,34.7520000,34.7520000,38.8060000,38.8060000,38.8060000,34.7520000,34.7520000,34.7520000,30.6980000,30.6980000, 5.0000000]
            refinery(numT, Tlist, numL1, Llist1, DS1, DV1, Pri, DS_num, sample, OCtank_ini, Otank_ini,Mode,QI_atm,QI_eth,QI_htu1) #

CASE = [
        # 'ShiL-case1',
        "12s3o",
        # "12s3o_none",
        # "18s3o",
        ]
# run(CASE)
