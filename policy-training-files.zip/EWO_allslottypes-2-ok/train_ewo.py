#   Copyright (c) 2018 PaddlePaddle Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import argparse
# import gym
import numpy as np
# import parl
from mujoco_agent import MujocoAgent
from mujoco_model import MujocoModel
from EightPuzzleEnv import EightPuzzleEnv
from mujoco_ppo import PPO
# from parl.utils import logger, action_mapping
# from parl.utils.rl_utils import calc_gae, calc_discount_sum_rewards
from scaler import Scaler
import scipy.signal
import logger
import xlwt, xlrd
import time

mean_l= [23.367035, 16.994191, 14.711604, 13.433808, 12.446063, 11.526283, 10.563673, 9.513687, 8.370137, 7.121449, 22.153565, 16.769212, 14.687206, 13.462022, 12.501687, 11.590227, 10.62679, 9.573292, 8.418157, 7.15492, 14.809299, 13.058894, 12.486369, 12.089494, 11.616373, 11.020006, 10.258665, 9.341686, 8.277545, 7.074462, 15.055228, 13.085518, 12.476556, 12.082446, 11.613205, 11.009558, 10.249164, 9.329648, 8.264611, 7.062698, 15.09487, 13.069458, 12.425843, 12.018936, 11.550624, 10.950811, 10.196025, 9.280492, 8.219078, 7.022412, 12.903355, 16.912589, 19.435173, 20.898371, 21.312345, 20.976275, 20.037687, 18.590169, 16.723389, 14.492913, 36.344453, 29.612545, 27.208713, 25.772285, 24.477982, 23.058242, 21.387535, 19.455707, 17.263655, 14.81638, 22.18736, 22.025317, 22.549987, 22.857237, 22.592115, 21.811884, 20.577207, 18.93826, 16.945666, 14.628512, 32.859126, 25.316886, 21.898634, 19.526772, 17.490856, 15.568672, 13.666746, 11.752975, 9.831434, 7.919798, 31.647247, 25.092806, 21.874867, 19.556479, 17.546702, 15.632601, 13.72914, 11.810133, 9.878128, 7.952362, 24.318518, 21.395513, 19.685529, 18.195649, 16.67174, 15.069261, 13.365306, 11.580981, 9.738575, 7.872778, 24.567702, 21.423741, 19.675036, 18.184624, 16.664763, 15.058021, 13.356673, 11.572105, 9.729461, 7.863004, 24.585273, 21.387272, 19.605973, 18.10388, 16.585867, 14.983209, 13.289137, 11.511415, 9.676325, 7.82053, 32.218455, 33.849674, 34.065775, 33.318006, 31.615326, 29.255952, 26.418621, 23.21416, 19.756519, 16.154386, 55.658862, 46.55083, 41.841789, 38.194805, 34.782682, 31.334961, 27.762047, 24.07252, 20.292355, 16.478024, 41.503501, 38.966524, 37.190155, 35.284872, 32.901721, 30.094577, 26.961587, 23.562876, 19.979355, 16.292474, 2.199378, 11.408053, 6.666477, 10.120172, 6.553411, 95.001664, 26.323009, 18.001698, 0.680383, 0.685545, 0.679583, 0.652857, 0.684581, 1.695244, 1.573464, 1.438533]
min_l= [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
max_l= [319.266205, 179.846252, 147.133331, 140.509521, 137.176193, 134.729767, 133.816666, 133.816666, 133.816666, 133.816666, 290.325073, 175.715988, 153.812744, 146.204239, 144.480209, 141.878967, 140.180557, 138.844437, 138.844437, 138.844437, 284.878113, 143.913391, 135.54834, 140.494476, 137.78624, 137.321304, 138.271271, 140.191666, 139.809845, 139.809845, 253.557022, 146.149994, 133.665619, 141.683334, 141.683334, 141.683334, 141.683334, 141.683334, 141.683334, 141.683334, 247.830643, 141.497177, 121.414543, 114.618652, 117.334923, 119.78437, 119.194443, 120.245239, 120.245239, 121.89286, 259.0, 205.216797, 232.55098, 255.266663, 255.266663, 255.266663, 255.266663, 259.277771, 259.277771, 259.277771, 654.913025, 342.173187, 286.899994, 279.350006, 279.350006, 279.350006, 279.350006, 279.350006, 279.350006, 279.350006, 353.083405, 215.199997, 213.680954, 226.583328, 226.583328, 226.583328, 226.583328, 226.583328, 226.583328, 226.583328, 319.266205, 179.846252, 147.133331, 140.509521, 137.176193, 134.729767, 133.816666, 133.816666, 133.816666, 133.816666, 290.325073, 175.715988, 153.812744, 146.204239, 144.480209, 141.878967, 140.180557, 138.844437, 138.844437, 138.844437, 284.878113, 143.913391, 135.54834, 140.494476, 137.78624, 137.321304, 138.271271, 140.191666, 139.809845, 139.809845, 253.557022, 146.149994, 133.665619, 141.683334, 141.683334, 141.683334, 141.683334, 141.683334, 141.683334, 141.683334, 247.830643, 147.097168, 127.014549, 126.185715, 126.185715, 126.185715, 126.185715, 126.185715, 126.185715, 121.89286, 259.0, 217.05098, 235.583328, 255.266663, 255.266663, 255.266663, 255.266663, 259.277771, 259.277771, 259.277771, 654.913025, 342.173187, 286.899994, 279.350006, 279.350006, 279.350006, 279.350006, 279.350006, 279.350006, 279.350006, 353.083405, 242.611984, 232.300003, 244.300003, 244.300003, 244.300003, 244.300003, 244.300003, 244.300003, 232.709518, 31.00746, 200.70578, 47.380035, 262.501801, 126.400879, 769.281067, 414.393158, 378.988007, 9.0, 9.0, 9.0, 9.0, 9.0, 162.666672, 120.707596, 200.0]
MeanMinMax = np.array([mean_l,min_l,max_l],dtype='float32')
# numT = 200
n_num = 10
numO = 8
numOC = 8
Olist = range(numO)
OClist = range(numOC)
numU = 9
numM = 4
hours = 1
numO_g = 5
numO_d = 3
numOC_g = 5
numOC_d = 3
train_case_num = 8
test_case_num = 6

def initOrder_train():
    all_numL1 = []
    all_DV1 = []
    all_DS_num = []
    all_OCtank_ini = []
    all_Otank_ini = []
    all_DS1 = []
    all_FOout = []
    # print "epoch:",epoch
    for epoch in range(train_case_num):
        OCtank_ini_1 = np.random.randint(0, 10, (numOC_g))
        OCtank_ini_2 = np.random.randint(0, 20, (numOC_d))
        OCtank_ini = np.hstack((OCtank_ini_1, OCtank_ini_2))
        Otank_ini_1 = np.random.randint(0, 10, (numO_g))
        Otank_ini_2 = np.random.randint(0, 20, (numO_d))
        Otank_ini = np.hstack((Otank_ini_1, Otank_ini_2))
        if epoch % 8 == 0:
            numL1_1 = np.random.randint(11, 20)  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = np.random.randint(5, 10)  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = np.random.randint(5, 10)  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)

            DV1_1_g = np.random.randint(20, 250, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(50, 450, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(20, 250, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(50, 450, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(20, 250, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(50, 450, (numL1_3, numO_d))
            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
        elif epoch % 8 == 1:
            numL1_1 = np.random.randint(5, 10)  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = np.random.randint(11, 20)  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = np.random.randint(5, 10)  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)

            DV1_1_g = np.random.randint(20, 250, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(50, 450, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(20, 250, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(50, 450, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(20, 250, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(50, 450, (numL1_3, numO_d))
            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
        elif epoch % 8 == 2:
            numL1_1 = np.random.randint(5, 10)  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = np.random.randint(5, 10)  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = np.random.randint(11, 20)  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)

            DV1_1_g = np.random.randint(20, 250, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(50, 450, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(20, 250, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(50, 450, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(20, 250, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(50, 450, (numL1_3, numO_d))
            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
        elif epoch % 8 == 3:
            numL1_1 = np.random.randint(8, 16)  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = np.random.randint(8, 16)  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = np.random.randint(5, 10)  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)

            DV1_1_g = np.random.randint(20, 250, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(50, 450, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(20, 250, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(50, 450, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(20, 250, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(50, 450, (numL1_3, numO_d))
            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
        elif epoch % 8 == 4:
            numL1_1 = np.random.randint(8, 16)  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = np.random.randint(5, 10)  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = np.random.randint(8, 16)  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)

            DV1_1_g = np.random.randint(20, 250, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(50, 450, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(20, 250, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(50, 450, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(20, 250, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(50, 450, (numL1_3, numO_d))
            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
        elif epoch % 8 == 5:
            numL1_1 = np.random.randint(5, 10)  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = np.random.randint(8, 16)  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = np.random.randint(8, 16)  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)

            DV1_1_g = np.random.randint(20, 250, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(50, 450, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(20, 250, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(50, 450, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(20, 250, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(50, 450, (numL1_3, numO_d))
            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
        elif epoch % 8 == 6:
            numL1_1 = np.random.randint(8, 16)  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = np.random.randint(8, 16)  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = np.random.randint(8, 16)  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)

            DV1_1_g = np.random.randint(20, 250, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(50, 450, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(20, 250, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(50, 450, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(20, 250, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(50, 450, (numL1_3, numO_d))
            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
        elif epoch % 8 == 7:
            numL1_1 = np.random.randint(5, 10)  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = np.random.randint(5, 10)  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = np.random.randint(5, 10)  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)

            DV1_1_g = np.random.randint(20, 250, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(50, 450, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(20, 250, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(50, 450, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(20, 250, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(50, 450, (numL1_3, numO_d))
            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
        # numL1 = np.random.randint(3, 40)  # for 1-6
        # Llist1 = range(numL1)
        #
        # DV1_g = np.random.randint(10, 100, (numL1, numO_g))
        # DV1_d = np.random.randint(50, 400, (numL1, numO_d))
        # DV1 = np.hstack((DV1_g, DV1_d))
        #
        # DS_num = np.zeros((numL1, 2))
        # DS_num[0, 0] = 0
        # DS_num[0, 1] = np.random.randint(15, numT)
        # for L1 in Llist1[1:]:  # start from 0-70; end randomly
        #     DS_num[L1, 0] = np.random.randint(0, numT - 25)
        #     DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 15, numT)
        DS_num = np.zeros((numL1, 2))
        DS_num[0, 0] = 0
        DS_num[0, 1] = np.random.randint(5, numT)
        if numL1_1 == 0:
            Llist1_1A = []
        else:
            Llist1_1A = Llist1_1[1:]
        for L1 in Llist1_1A:  # start from 0-70; end randomly
            DS_num[L1, 0] = np.random.randint(0, 70 - 25)  # 70 - 5
            DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 15, numT)

        if numL1_1 == 0 and numL1_2 != 0:
            Llist1_2A = Llist1_2[1:]
        else:
            Llist1_2A = Llist1_2
        for L2 in Llist1_2A:  # start from 70-140; end randomly
            DS_num[L2 + numL1_1, 0] = np.random.randint(70, 140 - 25)  #
            DS_num[L2 + numL1_1, 1] = np.random.randint(DS_num[L2 + numL1_1, 0] + 15, numT)

        if numL1_1 == 0 and numL1_2 == 0 and numL1_3 != 0:
            Llist1_3A = Llist1_3[1:]
        else:
            Llist1_3A = Llist1_3
        for L3 in Llist1_3A:  # start from 140-200; end randomly
            DS_num[L3 + numL1_1 + numL1_2, 0] = np.random.randint(140, 200 - 25)  #
            DS_num[L3 + numL1_1 + numL1_2, 1] = np.random.randint(DS_num[L3 + numL1_1 + numL1_2, 0] + 15, numT)
        DS1 = np.zeros((numL1, numT))
        for L1 in Llist1:
            DS1[L1, DS_num[L1, 0].astype(int):DS_num[L1, 1].astype(int) + 1] = 1
        FOout = np.zeros((numL1, numO_g + numO_d))
        all_numL1.append(numL1)
        all_DV1.append(DV1)
        all_DS_num.append(DS_num)
        all_OCtank_ini.append(OCtank_ini)
        all_Otank_ini.append(Otank_ini)
        all_DS1.append(DS1)
        all_FOout.append(FOout)
    write_train_order(all_numL1, all_DV1, all_DS_num, all_OCtank_ini, all_Otank_ini)
    return all_numL1, all_DV1, all_DS_num, all_OCtank_ini, all_Otank_ini, all_DS1, all_FOout

def initOrder_test():
    all_numT = []
    all_numL1 = []
    all_DV1 = []
    all_DS_num = []
    all_OCtank_ini = []
    all_Otank_ini = []
    all_DS1 = []
    all_FOout = []
    # print "epoch:",epoch
    for epoch in range(test_case_num):
        if epoch % 6 == 0:
            numT = 100
            OCtank_ini_1 = np.random.randint(0, 10, (numOC_g))
            OCtank_ini_2 = np.random.randint(0, 20, (numOC_d))
            OCtank_ini = np.hstack((OCtank_ini_1, OCtank_ini_2))
            Otank_ini_1 = np.random.randint(0, 10, (numO_g))
            Otank_ini_2 = np.random.randint(0, 20, (numO_d))
            Otank_ini = np.hstack((Otank_ini_1, Otank_ini_2))
            gaso_lo = 20
            dies_lo = 80
            gaso_up = 90
            dies_up = 180
            numL1_1 = 7  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = 6  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = 6  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)

            DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
            DS_num = np.zeros((numL1, 2))
            DS_num[0, 0] = 0
            DS_num[0, 1] = np.random.randint(5, numT)
            if numL1_1 == 0:
                Llist1_1A = []
            else:
                Llist1_1A = Llist1_1[1:]
            for L1 in Llist1_1A:  # start from 0-30; end randomly
                DS_num[L1, 0] = np.random.randint(0, 30)#70 - 5
                DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 10, numT-40)

            if numL1_1 == 0 and numL1_2 != 0:
                Llist1_2A = Llist1_2[1:]
            else:
                Llist1_2A = Llist1_2
            for L2 in Llist1_2A:  # start from 30-70; end randomly
                DS_num[L2+numL1_1, 0] = np.random.randint(30, 70)#
                DS_num[L2+numL1_1, 1] = np.random.randint(DS_num[L2+numL1_1, 0] + 10, numT-5)

            if numL1_1 == 0 and numL1_2 == 0 and numL1_3 != 0:
                Llist1_3A = Llist1_3[1:]
            else:
                Llist1_3A = Llist1_3
            for L3 in Llist1_3A:  # start from 50-80; end randomly
                DS_num[L3+numL1_1+numL1_2, 0] = np.random.randint(50, 82)#
                DS_num[L3+numL1_1+numL1_2, 1] = np.random.randint(DS_num[L3+numL1_1+numL1_2, 0] + 10, numT)
        elif epoch % 6 == 1:
            numT = 120
            OCtank_ini_1 = np.random.randint(0, 10, (numOC_g))
            OCtank_ini_2 = np.random.randint(0, 20, (numOC_d))
            OCtank_ini = np.hstack((OCtank_ini_1, OCtank_ini_2))
            Otank_ini_1 = np.random.randint(0, 10, (numO_g))
            Otank_ini_2 = np.random.randint(0, 20, (numO_d))
            Otank_ini = np.hstack((Otank_ini_1, Otank_ini_2))
            gaso_lo = 20
            dies_lo = 80
            gaso_up = 90
            dies_up = 180
            numL1_1 = 8  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = 7  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = 5  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)
            DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))

            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
            DS_num = np.zeros((numL1, 2))
            DS_num[0, 0] = 0
            DS_num[0, 1] = np.random.randint(5, numT)
            if numL1_1 == 0:
                Llist1_1A = []
            else:
                Llist1_1A = Llist1_1[1:]
            for L1 in Llist1_1A:  # start from 0-40; end randomly
                DS_num[L1, 0] = np.random.randint(0, 40)
                DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 15, numT-50)

            if numL1_1 == 0 and numL1_2 != 0:
                Llist1_2A = Llist1_2[1:]
            else:
                Llist1_2A = Llist1_2
            for L2 in Llist1_2A:  # start from 40-80; end randomly
                DS_num[L2+numL1_1, 0] = np.random.randint(40, 79)#
                DS_num[L2+numL1_1, 1] = np.random.randint(DS_num[L2+numL1_1, 0] + 15, numT-10)

            if numL1_1 == 0 and numL1_2 == 0 and numL1_3 != 0:
                Llist1_3A = Llist1_3[1:]
            else:
                Llist1_3A = Llist1_3
            for L3 in Llist1_3A:  # start from 60-100; end randomly
                DS_num[L3+numL1_1+numL1_2, 0] = np.random.randint(60, 105)#
                DS_num[L3+numL1_1+numL1_2, 1] = np.random.randint(DS_num[L3+numL1_1+numL1_2, 0] + 10, numT)
        elif epoch % 6 == 2:
            numT = 140
            OCtank_ini_1 = np.random.randint(0, 10, (numOC_g))
            OCtank_ini_2 = np.random.randint(0, 20, (numOC_d))
            OCtank_ini = np.hstack((OCtank_ini_1, OCtank_ini_2))
            Otank_ini_1 = np.random.randint(0, 10, (numO_g))
            Otank_ini_2 = np.random.randint(0, 20, (numO_d))
            Otank_ini = np.hstack((Otank_ini_1, Otank_ini_2))
            gaso_lo = 20
            dies_lo = 80
            gaso_up = 90
            dies_up = 200
            numL1_1 = 9  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = 7  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = 5  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)
            DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
            DS_num = np.zeros((numL1, 2))
            DS_num[0, 0] = 0
            DS_num[0, 1] = np.random.randint(5, numT)
            if numL1_1 == 0:
                Llist1_1A = []
            else:
                Llist1_1A = Llist1_1[1:]
            for L1 in Llist1_1A:  # start from 0-50; end randomly
                DS_num[L1, 0] = np.random.randint(0, 50)#70 - 5
                DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 15, numT-50)

            if numL1_1 == 0 and numL1_2 != 0:
                Llist1_2A = Llist1_2[1:]
            else:
                Llist1_2A = Llist1_2
            for L2 in Llist1_2A:  # start from 50-90; end randomly
                DS_num[L2+numL1_1, 0] = np.random.randint(50, 90)#
                DS_num[L2+numL1_1, 1] = np.random.randint(DS_num[L2+numL1_1, 0] + 15, numT-20)

            if numL1_1 == 0 and numL1_2 == 0 and numL1_3 != 0:
                Llist1_3A = Llist1_3[1:]
            else:
                Llist1_3A = Llist1_3
            for L3 in Llist1_3A:  # start from 70-120; end randomly
                DS_num[L3+numL1_1+numL1_2, 0] = np.random.randint(70, 120)#
                DS_num[L3+numL1_1+numL1_2, 1] = np.random.randint(DS_num[L3+numL1_1+numL1_2, 0] + 15, numT)
        elif epoch % 6 == 3:
            numT = 160
            OCtank_ini_1 = np.random.randint(0, 10, (numOC_g))
            OCtank_ini_2 = np.random.randint(0, 20, (numOC_d))
            OCtank_ini = np.hstack((OCtank_ini_1, OCtank_ini_2))
            Otank_ini_1 = np.random.randint(0, 10, (numO_g))
            Otank_ini_2 = np.random.randint(0, 20, (numO_d))
            Otank_ini = np.hstack((Otank_ini_1, Otank_ini_2))
            gaso_lo = 20
            dies_lo = 80
            gaso_up = 90
            dies_up = 220
            numL1_1 = 9  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = 8  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = 6  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)
            DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
            DS_num = np.zeros((numL1, 2))
            DS_num[0, 0] = 0
            DS_num[0, 1] = np.random.randint(5, numT)
            if numL1_1 == 0:
                Llist1_1A = []
            else:
                Llist1_1A = Llist1_1[1:]
            for L1 in Llist1_1A:  # start from 0-60; end randomly
                DS_num[L1, 0] = np.random.randint(0, 60)#70 - 5
                DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 15, numT-70)

            if numL1_1 == 0 and numL1_2 != 0:
                Llist1_2A = Llist1_2[1:]
            else:
                Llist1_2A = Llist1_2
            for L2 in Llist1_2A:  # start from 60-110; end randomly
                DS_num[L2+numL1_1, 0] = np.random.randint(60, 110)#
                DS_num[L2+numL1_1, 1] = np.random.randint(DS_num[L2+numL1_1, 0] + 15, numT-30)

            if numL1_1 == 0 and numL1_2 == 0 and numL1_3 != 0:
                Llist1_3A = Llist1_3[1:]
            else:
                Llist1_3A = Llist1_3
            for L3 in Llist1_3A:  # start from 80-150; end randomly
                DS_num[L3+numL1_1+numL1_2, 0] = np.random.randint(80, 145)#
                DS_num[L3+numL1_1+numL1_2, 1] = np.random.randint(DS_num[L3+numL1_1+numL1_2, 0] + 10, numT)
        elif epoch % 6 == 4:
            numT = 180
            OCtank_ini_1 = np.random.randint(0, 10, (numOC_g))
            OCtank_ini_2 = np.random.randint(0, 20, (numOC_d))
            OCtank_ini = np.hstack((OCtank_ini_1, OCtank_ini_2))
            Otank_ini_1 = np.random.randint(0, 10, (numO_g))
            Otank_ini_2 = np.random.randint(0, 20, (numO_d))
            Otank_ini = np.hstack((Otank_ini_1, Otank_ini_2))
            gaso_lo = 20
            dies_lo = 100
            gaso_up = 100
            dies_up = 250
            numL1_1 = 10  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = 8  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = 7  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)
            DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))
            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
            DS_num = np.zeros((numL1, 2))
            DS_num[0, 0] = 0
            DS_num[0, 1] = np.random.randint(5, numT)
            if numL1_1 == 0:
                Llist1_1A = []
            else:
                Llist1_1A = Llist1_1[1:]
            for L1 in Llist1_1A:  # start from 0-60; end randomly
                DS_num[L1, 0] = np.random.randint(0, 60)#70 - 5
                DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 15, numT-45)

            if numL1_1 == 0 and numL1_2 != 0:
                Llist1_2A = Llist1_2[1:]
            else:
                Llist1_2A = Llist1_2
            for L2 in Llist1_2A:  # start from 60-120; end randomly
                DS_num[L2+numL1_1, 0] = np.random.randint(60, 120)#
                DS_num[L2+numL1_1, 1] = np.random.randint(DS_num[L2+numL1_1, 0] + 15, numT-25)

            if numL1_1 == 0 and numL1_2 == 0 and numL1_3 != 0:
                Llist1_3A = Llist1_3[1:]
            else:
                Llist1_3A = Llist1_3
            for L3 in Llist1_3A:  # start from 90-150; end randomly
                DS_num[L3+numL1_1+numL1_2, 0] = np.random.randint(90, 160)#
                DS_num[L3+numL1_1+numL1_2, 1] = np.random.randint(DS_num[L3+numL1_1+numL1_2, 0] + 15, numT)
        elif epoch % 6 == 5:
            numT = 200
            OCtank_ini_1 = np.random.randint(0, 10, (numOC_g))
            OCtank_ini_2 = np.random.randint(0, 20, (numOC_d))
            OCtank_ini = np.hstack((OCtank_ini_1, OCtank_ini_2))
            Otank_ini_1 = np.random.randint(0, 10, (numO_g))
            Otank_ini_2 = np.random.randint(0, 20, (numO_d))
            Otank_ini = np.hstack((Otank_ini_1, Otank_ini_2))
            gaso_lo = 20
            dies_lo = 100
            gaso_up = 100
            dies_up = 250
            numL1_1 = 12  # for 1-6
            Llist1_1 = range(numL1_1)
            numL1_2 = 8  # for 1-6
            Llist1_2 = range(numL1_2)
            numL1_3 = 8  # for 1-6
            Llist1_3 = range(numL1_3)
            numL1 = numL1_1 + numL1_2 + numL1_3
            Llist1 = range(numL1)
            DV1_1_g = np.random.randint(gaso_lo, gaso_up, (numL1_1, numO_g))
            DV1_1_d = np.random.randint(dies_lo, dies_up, (numL1_1, numO_d))
            DV1_2_g = np.random.randint(gaso_lo, gaso_up, (numL1_2, numO_g))
            DV1_2_d = np.random.randint(dies_lo, dies_up, (numL1_2, numO_d))
            DV1_3_g = np.random.randint(gaso_lo, gaso_up, (numL1_3, numO_g))
            DV1_3_d = np.random.randint(dies_lo, dies_up, (numL1_3, numO_d))

            DV1_g = np.vstack((DV1_1_g, DV1_2_g, DV1_3_g))
            DV1_d = np.vstack((DV1_1_d, DV1_2_d, DV1_3_d))
            DV1 = np.hstack((DV1_g, DV1_d))
            DS_num = np.zeros((numL1, 2))
            DS_num[0, 0] = 0
            DS_num[0, 1] = np.random.randint(5, numT)
            if numL1_1 == 0:
                Llist1_1A = []
            else:
                Llist1_1A = Llist1_1[1:]
            for L1 in Llist1_1A:  # start from 0-70; end randomly
                DS_num[L1, 0] = np.random.randint(0, 70)#70 - 5
                DS_num[L1, 1] = np.random.randint(DS_num[L1, 0] + 15, numT-65)

            if numL1_1 == 0 and numL1_2 != 0:
                Llist1_2A = Llist1_2[1:]
            else:
                Llist1_2A = Llist1_2
            for L2 in Llist1_2A:  # start from 70-140; end randomly
                DS_num[L2+numL1_1, 0] = np.random.randint(70, 140)#
                DS_num[L2+numL1_1, 1] = np.random.randint(DS_num[L2+numL1_1, 0] + 15, numT-35)

            if numL1_1 == 0 and numL1_2 == 0 and numL1_3 != 0:
                Llist1_3A = Llist1_3[1:]
            else:
                Llist1_3A = Llist1_3
            for L3 in Llist1_3A:  # start from 140-200; end randomly
                DS_num[L3+numL1_1+numL1_2, 0] = np.random.randint(100, 160)#
                DS_num[L3+numL1_1+numL1_2, 1] = np.random.randint(DS_num[L3+numL1_1+numL1_2, 0] + 15, numT)
        DS1 = np.zeros((numL1, numT))
        for L1 in Llist1:
            DS1[L1, DS_num[L1, 0].astype(int):DS_num[L1, 1].astype(int) + 1] = 1
        FOout = np.zeros((numL1, numO_g + numO_d))
        all_numT.append(numT)
        all_numL1.append(numL1)
        all_DV1.append(DV1)
        all_DS_num.append(DS_num)
        all_OCtank_ini.append(OCtank_ini)
        all_Otank_ini.append(Otank_ini)
        all_DS1.append(DS1)
        all_FOout.append(FOout)
    write_train_order(all_numT, all_numL1, all_DV1, all_DS_num, all_OCtank_ini, all_Otank_ini)
    return all_numT, all_numL1, all_DV1, all_DS_num, all_OCtank_ini, all_Otank_ini, all_DS1, all_FOout

def write_train_order(all_numT, all_numL1, all_DV1, all_DS_num, all_OCtank_ini, all_Otank_ini):
    book = xlwt.Workbook(encoding='utf-8', style_compression=0)
    sheet = book.add_sheet('test_case', cell_overwrite_ok=True)
    # numT
    sheet.write(0, 0, "numT")
    n0 = 1
    for T in range(len(all_numT)):
        sheet.write(0, T + 1, all_numT[T])
    # numL1
    sheet.write(n0+1, 0, "numL1")
    n1 = 1
    for L in range(len(all_numL1)):
        sheet.write(n0+1, L + 1, all_numL1[L])
    # numDV1
    n2 = np.sum(all_numL1)
    for L in range(len(all_DV1)):
        for l in range(all_numL1[L]):
            sheet.write(int(n0+1+n1+1 + np.sum(all_numL1[:L])), 0, "case"+str(L))
            for c in range(numO):
                sheet.write(int(n0+1+n1+1 + np.sum(all_numL1[:L])+l), c + 1, all_DV1[L][l,c])
    # DS_num
    n3 = np.sum(all_numL1)
    for L in range(len(all_DS_num)):
        for l in range(all_numL1[L]):
            sheet.write(int(n0+1+ n1+1 + n2+1 + np.sum(all_numL1[:L])), 0, "case"+str(L))
            for c in range(2):
                sheet.write(int(n0+1+ n1+1 + n2+1 + np.sum(all_numL1[:L])+l), c + 1, all_DS_num[L][l,c])
    # OCtank_ini
    n4 = len(all_numL1)
    for L in range(n4):
            sheet.write(int(n0+1+ n1+1 + n2+1 + n3+1 + L), 0, "case"+str(L))
            for c in range(numO):
                sheet.write(int(n0+1+ n1+1 + n2+1 + n3+1 + L), c + 1, all_OCtank_ini[L][c])
    # Otank_ini
    n5 = len(all_numL1)
    for L in range(n5):
            sheet.write(int(n0+1+ n1+1 + n2+1 + n3+1 + n4+1 + L), 0, "case"+str(L))
            for c in range(numO):
                sheet.write(int(n0+1+ n1+1 + n2+1 + n3+1 + n4+1 + L), c + 1, all_Otank_ini[L][c])
    book.save('test_case' + '.xls')#Order_test_case

def read_train_order():
    book = xlrd.open_workbook("train_case.xls")#Order_test_case
    sheet = book.sheet_by_name('train_case')
    all_numL1, all_DV1, all_DS_num, all_OCtank_ini, all_Otank_ini, all_DS1, all_FOout = [], [], [], [], [], [], []
    # numL1
    n1 = 1
    all_numL1 = sheet.row_values(0, 0+1, train_case_num+1)
    all_numL1_1 = sheet.row_values(0, 0+1, 8+1)
    # numDV1
    n2 = np.sum(all_numL1_1)
    for L in range(train_case_num):
        all_DV1_ = []
        for l in range(int(all_numL1[L])):
            all_DV1_.append(sheet.row_values(int(n1+1 + np.sum(all_numL1[:L])+l), 1, numO+1))
        all_DV1.append(np.array(all_DV1_))
    # DS_num
    n3 = np.sum(all_numL1_1)
    for L in range(train_case_num):
        all_DS_num_ = []
        for l in range(int(all_numL1[L])):
            all_DS_num_.append(sheet.row_values(int(n1+1 + n2+1 + np.sum(all_numL1[:L])+l), 1, 2+1))
        all_DS_num.append(np.array(all_DS_num_))
    # OCtank_ini
    n4 = len(all_numL1_1)
    all_OCtank_ini = []
    for L in range(n4):
        all_OCtank_ini.append(np.array(sheet.row_values(int(n1+1 + n2+1 + n3+1 + L), 1, numO+1)))
    # Otank_ini
    n5 = len(all_numL1_1)
    all_Otank_ini = []
    for L in range(train_case_num):
        all_Otank_ini.append(np.array(sheet.row_values(int(n1+1 + n2+1 + n3+1 + n4+1 + L), 1, numO+1)))
    # all_DS1
    all_DS1 = []
    for L in range(train_case_num):
        DS1 = np.zeros((int(all_numL1[L]), numT))
        for L1 in range(int(all_numL1[L])):
            DS1[L1, all_DS_num[L][L1, 0].astype(int):all_DS_num[L][L1, 1].astype(int) + 1] = 1
        all_DS1.append(DS1)
    # all_FOout
    all_FOout = []
    for L in range(train_case_num):
        all_FOout.append(np.zeros((int(all_numL1[L]), numO_g+numO_d)))
    print all_numL1#, all_DS_num , all_OCtank_ini, all_Otank_ini, all_DS1, all_FOout, all_DV1
    return np.array(all_numL1,dtype="int"), all_DV1, all_DS_num, all_OCtank_ini, all_Otank_ini, all_DS1, all_FOout

def read_test_order():
    book = xlrd.open_workbook("test_case.xls")#Order_test_case
    sheet = book.sheet_by_name('test_case')
    all_numT, all_numL1, all_DV1, all_DS_num, all_OCtank_ini, all_Otank_ini, all_DS1, all_FOout = \
        [], [], [], [], [], [], [], []
    # numT
    n0 = 1
    all_numT = sheet.row_values(0, 0+1, test_case_num+1)
    # numL1
    n1 = 1
    all_numL1 = sheet.row_values(n0+1, 0+1, test_case_num+1)
    # all_numL1_1 = sheet.row_values(0, 0+1, 8+1)
    # numDV1
    n2 = np.sum(all_numL1)
    for L in range(test_case_num):
        all_DV1_ = []
        for l in range(int(all_numL1[L])):
            all_DV1_.append(sheet.row_values(int(n0+1 + n1+1 + np.sum(all_numL1[:L])+l), 1, numO+1))
        all_DV1.append(np.array(all_DV1_))
    # DS_num
    n3 = np.sum(all_numL1)
    for L in range(test_case_num):
        all_DS_num_ = []
        for l in range(int(all_numL1[L])):
            all_DS_num_.append(sheet.row_values(int(n0+1 + n1+1 + n2+1 + np.sum(all_numL1[:L])+l), 1, 2+1))
        all_DS_num.append(np.array(all_DS_num_))
    # OCtank_ini
    n4 = len(all_numL1)
    all_OCtank_ini = []
    for L in range(n4):
        all_OCtank_ini.append(np.array(sheet.row_values(int(n0+1 + n1+1 + n2+1 + n3+1 + L), 1, numO+1)))
    # Otank_ini
    n5 = len(all_numL1)
    all_Otank_ini = []
    for L in range(test_case_num):
        all_Otank_ini.append(np.array(sheet.row_values(int(n0+1 + n1+1 + n2+1 + n3+1 + n4+1 + L), 1, numO+1)))
    # all_DS1
    all_DS1 = []
    for L in range(test_case_num):
        DS1 = np.zeros((int(all_numL1[L]), int(all_numT[L])))
        for L1 in range(int(all_numL1[L])):
            DS1[L1, all_DS_num[L][L1, 0].astype(int):all_DS_num[L][L1, 1].astype(int) + 1] = 1
        all_DS1.append(DS1)
    # all_FOout
    all_FOout = []
    for L in range(test_case_num):
        all_FOout.append(np.zeros((int(all_numL1[L]), numO_g+numO_d)))
    print all_numL1#, all_DS_num , all_OCtank_ini, all_Otank_ini, all_DS1, all_FOout, all_DV1
    return np.array(all_numT,dtype="int"), np.array(all_numL1,dtype="int"), \
           all_DV1, all_DS_num, all_OCtank_ini, all_Otank_ini, all_DS1, all_FOout

def exist_test_order():
    numT = 200
    Tlist = range(numT)
    OCtank_ini = [7, 6, 0, 5, 6, 7, 2, 4]
    Otank_ini = [5, 0, 1, 0, 6, 5, 5, 2]
    DV1 = [[74, 152, 59, 65, 66, 328, 225, 304],
           [58, 54, 155, 68, 56, 184, 30, 214],
           [72, 66, 69, 62, 66, 247, 104, 205],
           [48, 57, 46, 59, 45, 210, 190, 360],
           [52, 52, 66, 170, 72, 200, 126, 209],
           [65, 61, 172, 154, 73, 332, 161, 344],
           [66, 147, 64, 46, 49, 173, 129, 266],
           [47, 68, 71, 52, 52, 194, 180, 365],
           [45, 56, 46, 50, 70, 390, 181, 268],
           [46, 149, 65, 62, 159, 181, 100, 238],
           [71, 54, 71, 56, 51, 301, 235, 332],
           [45, 54, 65, 155, 171, 382, 257, 261],
           [53, 147, 57, 55, 149, 162, 159, 320],
           [59, 48, 145, 52, 63, 226, 96, 216],
           [61, 58, 145, 164, 54, 277, 207, 221],
           [51, 153, 54, 64, 55, 381, 292, 165],
           [65, 65, 68, 71, 56, 199, 213, 205],
           [70, 65, 57, 58, 63, 300, 143, 389],
           [63, 63, 60, 48, 53, 232, 199, 399],
           [73, 147, 164, 167, 51, 150, 132, 254],
           [61, 70, 154, 57, 71, 368, 254, 317],
           [46, 55, 72, 45, 56, 262, 198, 263],
           [56, 58, 62, 68, 154, 386, 43, 248],
           [48, 63, 73, 57, 156, 273, 65, 347],
           [64, 154, 51, 73, 59, 285, 196, 340],
           [54, 57, 53, 58, 157, 369, 266, 251],
           [63, 66, 67, 71, 67, 378, 226, 161],
           [57, 67, 156, 55, 62, 310, 42, 194],
           [52, 64, 68, 50, 69, 296, 255, 268],
           [63, 146, 46, 64, 45, 182, 148, 225]]
    DS_num = [[0, 54],
              [74, 118],
              [53, 86],
              [123, 199],
              [28, 61],
              [103, 159],
              [12, 87],
              [92, 153],
              [153, 190],
              [45, 93],
              [1, 45],
              [97, 126],
              [16, 93],
              [105, 173],
              [162, 190],
              [31, 73],
              [127, 181],
              [21, 80],
              [16, 82],
              [41, 108],
              [107, 165],
              [145, 183],
              [84, 128],
              [103, 157],
              [28, 69],
              [65, 109],
              [166, 199],
              [100, 158],
              [4, 75],
              [96, 129]]
    DS_num = np.array(DS_num)
    numL1 = 27
    DV1 = np.array(DV1[:numL1])
    Llist1 = range(numL1)
    DS1 = np.zeros((numL1, numT))
    for L1 in Llist1:
        DS1[L1, DS_num[L1, 0].astype(int):DS_num[L1, 1].astype(int) + 1] = 1
    all_FOout = []
    for L in range(test_case_num):
        all_FOout.append(np.zeros((numL1, numO_g+numO_d)))
    return [numL1], [DV1], [DS_num], [np.array(OCtank_ini)], [np.array(Otank_ini)], [DS1], all_FOout

def run_evaluate_episode(env, agent, AnumT, AnumL1, ADV1_left, ADS_num, AOCtank_ini, AOtank_ini, ADS1, AFOout):
    rewards = []
    solution_num = 0
    solutions = []
    for i in range(test_case_num):
        numT, numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, FOout =  AnumT[i], AnumL1[i], ADV1_left[i], ADS_num[i], \
                                                                 AOCtank_ini[i], AOtank_ini[i], AFOout[i]
        env.reset_eval(numT)
        t = 0
        eval_is = 0
        while True:
            # OBS information: t, numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, FOout
            data_l, raw_l = infer_data_P(t, numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, FOout)
            obs = Matrixdata(data_l)

            action = agent.policy_predict(obs)
            if t in range(0,200,20)+[199]:
                print t,np.round(action.tolist(), 3).tolist()
            if t == numT-1:
                eval_is = 1
            t, numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, FOout, reward, Solu_exsit, solution = \
                env.step(t, numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, FOout, action,eval_is)
            if t == numT and Solu_exsit == 1:
                solution_num += 1
                rewards.append(reward)
                solutions.append(solution)
                break
            elif t == numT and Solu_exsit == 0:
                rewards.append(0)
                solutions.append(0)
                break
    return np.sum(rewards)/solution_num, rewards, np.sum(solutions)/solution_num, solutions

def infer_data_P(t, numL1, order_left, DS_num, OC_inventory, O_inventory, FOout):
    # t is the number of present slot.
    # order_left represents the left amount of order at the last slot beginning.
    # FOout represents the product output flowrate in the last slot.
    # (order_left[L][O] - FOout[L,O] * hours) represents the left amount of order at the present slot beginning.
    Llist1 = range(numL1)
    Prod_flow = np.zeros((n_num, numO, numL1))
    Prod_fl_T = np.zeros((n_num, numO, numL1))
    Prod_fl_S = np.zeros((n_num, numO, numL1))
    INV_OC = np.zeros((numOC))
    INV_O = np.zeros((numO))
    # print "infer data order left:",order_left
    # print "infer data FOout:",FOout
    # print "DS_num:",DS_num
    for O in Olist:
        for L in Llist1:
            for n in range(0, n_num):
                if t + n <= DS_num[L][0]:
                    Prod_fl_T[n, O, L] = (order_left[L][O] - FOout[L][O] * hours) / (DS_num[L][1] - t-n + 1)
                elif DS_num[L][0] < t + n <= DS_num[L][1]:
                    if n == 0:
                        Prod_fl_T[n, O, L] = (order_left[L][O] - FOout[L][O] * hours) / (DS_num[L][1] - t-n + 1)
                    else:
                        Prod_fl_T[n, O, L] = Prod_fl_T[n-1, O, L]
                elif DS_num[L][1] < t + n:
                    Prod_fl_T[n, O, L] = 0
                if t + n < DS_num[L][0]:
                    Prod_fl_S[n, O, L] = 0
                elif DS_num[L][0] <= t + n <= DS_num[L][1]:
                    if n == 0:
                        Prod_fl_S[n, O, L] = (order_left[L][O] - FOout[L, O] * hours) / (DS_num[L][1] - t-n + 1)
                    elif t+n == DS_num[L][0]:
                        Prod_fl_S[n, O, L] = (order_left[L][O] - FOout[L, O] * hours) / (DS_num[L][1] - DS_num[L][0] + 1)
                    else:
                        Prod_fl_S[n, O, L] = Prod_fl_S[n-1, O, L]
                elif DS_num[L][1] < t + n:
                    Prod_fl_S[n, O, L] = 0

    for o in OClist:
        INV_OC[o] = OC_inventory[o]
    for o in Olist:
        INV_O[o] = O_inventory[o]
    inputdata = [0]*(8*2*n_num+16)
    raw_data = [0]*(8*2*n_num+16)
    for O in Olist:
        for n in range(n_num):
            Prod_sum_S = 0
            Prod_sum_T = 0
            for L in Llist1:
                Prod_sum_S += Prod_fl_S[n, O, L]
                Prod_sum_T += Prod_fl_T[n, O, L]
            raw_data[O * (n_num) + n] = Prod_sum_S
            raw_data[numO*n_num + (O * (n_num) + n)] = Prod_sum_T
            if Prod_sum_S > MeanMinMax[2,O*(n_num)+n]:
                Prod_sum_S = (MeanMinMax[2,O*(n_num)+n] - MeanMinMax[0,O*(n_num)+n])/(MeanMinMax[2,O*(n_num)+n] -
                                                                                    MeanMinMax[1,O*(n_num)+n])
            elif Prod_sum_S < MeanMinMax[1,O*(n_num)+n]:
                Prod_sum_S = (MeanMinMax[1,O*(n_num)+n] - MeanMinMax[0,O*(n_num)+n])/(MeanMinMax[2,O*(n_num)+n] -
                                                                                    MeanMinMax[1,O*(n_num)+n])
            elif MeanMinMax[2,O*(n_num)+n] - MeanMinMax[1,O*(n_num)+n] != 0:
                Prod_sum_S = (Prod_sum_S - MeanMinMax[0,O*(n_num)+n])/(MeanMinMax[2,O*(n_num)+n] -
                                                                       MeanMinMax[1,O*(n_num)+n])
            inputdata[O * (n_num) + n] = Prod_sum_S
            if Prod_sum_T > MeanMinMax[2,numO*n_num+O*(n_num)+n]:
                Prod_sum_T = (MeanMinMax[2,numO*n_num+O*(n_num)+n] - MeanMinMax[0,numO*n_num+O*(n_num)+n])/\
                             (MeanMinMax[2,numO*n_num+O*(n_num)+n] - MeanMinMax[1,numO*n_num+O*(n_num)+n])
            elif Prod_sum_T < MeanMinMax[1,numO*n_num+O*(n_num)+n]:
                Prod_sum_T = (MeanMinMax[1,numO*n_num+O*(n_num)+n] - MeanMinMax[0,numO*n_num+O*(n_num)+n])/\
                             (MeanMinMax[2,numO*n_num+O*(n_num)+n] - MeanMinMax[1,numO*n_num+O*(n_num)+n])
            elif MeanMinMax[2,numO*n_num+O*(n_num)+n] - MeanMinMax[1,numO*n_num+O*(n_num)+n] != 0:
                Prod_sum_T = (Prod_sum_T - MeanMinMax[0,numO*n_num+O*(n_num)+n])/\
                             (MeanMinMax[2,numO*n_num+O*(n_num)+n] - MeanMinMax[1,numO*n_num+O*(n_num)+n])
            inputdata[numO*n_num+(O * (n_num) + n)] = Prod_sum_T
    # print "\n"
    for OC in OClist:
        raw_data[OC + 2*numO * (n_num)] = round(INV_OC[OC], 6)
        if INV_OC[OC] > MeanMinMax[2,2*numO*(n_num)+OC]:
            v = (MeanMinMax[2,2*numO*(n_num)+OC] - MeanMinMax[0,2*numO*(n_num)+OC])/(MeanMinMax[2,2*numO*(n_num)+OC] -
                                                                                   MeanMinMax[1,2*numO*(n_num)+OC])
            inputdata[OC + 2*numO * (n_num)] = round(v, 6)
        elif MeanMinMax[2,2*numO*(n_num)+OC] - MeanMinMax[1,2*numO*(n_num)+OC] != 0:
            v = (INV_OC[OC] - MeanMinMax[0,2*numO*(n_num)+OC])/(MeanMinMax[2,2*numO*(n_num)+OC] -
                                                                                   MeanMinMax[1,2*numO*(n_num)+OC])
            inputdata[OC + 2*numO * (n_num)] = round(v, 6)
        else:
            inputdata[OC + 2*numO * (n_num)] = round(INV_OC[OC], 6)
    for O in Olist:
        raw_data[O + numOC + 2*numO * (n_num)] = round(INV_O[O], 6)
        if INV_O[O] > MeanMinMax[2,2*numO*(n_num) + numOC+O] and \
            MeanMinMax[2,2*numO*(n_num) + numOC+O] - MeanMinMax[1,2*numO*(n_num) + numOC+O] == 0:
            v = 0
            inputdata[O + numOC + 2*numO * (n_num)] = round(v, 6)
        elif INV_O[O] > MeanMinMax[2,2*numO*(n_num) + numOC+O]:
            v = (MeanMinMax[2,2*numO*(n_num) + numOC+O] - MeanMinMax[0,2*numO*(n_num) + numOC+O])/\
                (MeanMinMax[2,2*numO*(n_num) + numOC+O] - MeanMinMax[1,2*numO*(n_num) + numOC+O])
            inputdata[O + numOC + 2*numO * (n_num)] = round(v, 6)
        elif MeanMinMax[2,2*numO*(n_num) + numOC+O] - MeanMinMax[1,2*numO*(n_num) + numOC+O] != 0:
            v = (INV_O[O] - MeanMinMax[0,2*numO*(n_num) + numOC+O])/\
                (MeanMinMax[2,2*numO*(n_num) + numOC+O] - MeanMinMax[1,2*numO*(n_num) + numOC+O])
            inputdata[O + numOC + 2*numO * (n_num)] = round(v, 6)
        else:
            inputdata[O + numOC + 2*numO * (n_num)] = round(INV_O[O], 6)
    return inputdata, raw_data

def Matrixdata(inputdata):
    inputdata = np.array(inputdata, dtype='float32')
    # l = inputdata.reshape((1,input_num))
    insert_data = np.hstack((inputdata[8 * 2 * n_num:8 * 2 * n_num + 8],
                             inputdata[8 * 2 * n_num:8 * 2 * n_num + 8],
                             inputdata[8 * 2 * n_num + 8:],
                             inputdata[8 * 2 * n_num + 8:]))
    n = 0
    for ii in range(0, 8 * 2 * n_num, 10):
        inputdata = np.insert(inputdata, ii + 2 * n, insert_data[n])
        inputdata = np.insert(inputdata, ii + 2 * n + 1, insert_data[16 + n])
        n += 1
    l = inputdata[:8 * 2 * n_num + 32].reshape((1, 2, 8, 12))
    return l

def run_train_episode(env, agent, numT):   # , scaler
    step = 0   #  , numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, DS1, FOout
    t = 0
    observes, actions, act_probs, rewards, unscaled_obs = [], [], [], [], []
    # Mode_Unit = np.zeros((numU, numM, numT))
    # Environment Initialization
    numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, DS1, FOout = env.reset(numT)
    # numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, DS1, FOout = initOrder_test(numT)
    # numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, DS1, FOout = read_train_order(numT)
    # numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, DS1, FOout = exist_test_order(numT)
    eval_is = 0
    while step < steps_one_episode:
        # print "step:",step
        # OBS information: t, numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, FOout
        data_l, raw_l = infer_data_P(t, numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, FOout)
        # unscaled_obs.append(raw_l)
        obs = Matrixdata(data_l)
        observes.append(obs)#.tolist()

        action, action_prob = agent.policy_sample(obs)
        # if t==0 or t==99 or t==199:
        #     print action
        t, numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, FOout, reward, enable,_ = \
            env.step(t, numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, FOout, action[0], eval_is)
        # print "reward:",reward
        actions.append(action[0])
        act_probs.append([action_prob])
        rewards.append([reward])
        step += 1
        if t == numT:
            # print "reward:",reward
            break
    return np.concatenate(observes), np.array(actions), \
           np.array(act_probs), np.array(rewards),  unscaled_obs, enable

def collect_trajectories(env, agent, episodes): # scaler,
    trajectories, all_unscaled_obs = [], [] #, numL1, DV1_left, DS_num, OCtank_ini, Otank_ini, DS1, FOout
    for e in range(episodes):
        if e%6 == 0:
            numT = 100
        elif e%6 == 1:
            numT = 120
        elif e%6 == 2:
            numT = 140
        elif e%6 == 3:
            numT = 160
        elif e%6 == 4:
            numT = 180
        elif e%6 == 5:
            numT = 200
        while True:
            try:
                obs, actions, act_probs, rewards, unscaled_obs, enable = run_train_episode(env, agent, numT)
                           # ,numL1[e], DV1_left[e], DS_num[e], OCtank_ini[e], Otank_ini[e], DS1[e], FOout[e]) #, scaler
            except:
                pass
            else:
                if enable == 1:
                    trajectories.append({
                        'obs': obs,
                        'actions': actions,
                        'rewards': rewards,
                        'actprobs': act_probs,
                    })
                    break
    #     all_unscaled_obs.append(unscaled_obs)
    # scaler.update(np.concatenate(all_unscaled_obs))
    return trajectories

def calc_discount_sum_rewards(rewards, gamma):
    return scipy.signal.lfilter([1.0], [1.0, -gamma], rewards[::-1])[::-1]
def calc_gae(rewards, values, next_value, gamma, lam):
    tds = rewards + gamma * np.append(values[1:], next_value) - values
    advantages = calc_discount_sum_rewards(tds, gamma * lam)
    return advantages

def build_train_data(trajectories, agent):
    train_obs, train_actions, train_actprobs, train_advantages, train_discount_sum_rewards = [], [], [], [], []
    flag = 2
    for trajectory in trajectories:
        numT = trajectory['obs'].shape[0]
        pred_values = agent.value_predict(trajectory['obs'])
        pred_values = pred_values.reshape((-1))

        scale_rewards = trajectory['rewards'].reshape((-1))
        # scale_rewards = scale_rewards * (1 - args.gamma)
        if flag != 0:
            print("traj_reward: ",np.round(scale_rewards.tolist(),3).tolist())
            # print("traj_re_add: ",np.round((scale_rewards[-1]).tolist(),3).tolist())
        scale_rewards = -1.0 / ( scale_rewards[-1]*np.ones((numT)))
        # scale_rewards = scale_rewards[-1]*np.ones((numT)).astype("float32")
        # if flag != 0:
        #     print("trajectory:",trajectory['rewards'])
        #     print("scale_rewards:",scale_rewards)

        # discount_sum_rewards = calc_discount_sum_rewards(
        #     scale_rewards, args.gamma).astype('float32')
        discount_sum_rewards = scale_rewards.astype('float32')
        if flag != 0:
            print("dis_rewards: ",np.round(discount_sum_rewards.tolist(),3).tolist())
            print("pred_values:",np.round(pred_values.tolist(),3).tolist())
        advantages = calc_gae(scale_rewards, pred_values, 0, args.gamma,
                              args.lam)
        # advantages = scale_rewards - pred_values
        if flag != 0:
            print("advantageB: ",np.round(advantages.tolist(),3).tolist())
        advantages = (advantages - advantages.mean()) / (
            advantages.std() + 1e-8)
        advantages = advantages.astype('float32')
        if flag != 0:
            print("advantages: ",np.round(advantages.tolist(),3).tolist())
            flag -= 1
        discount_sum_rewards = discount_sum_rewards.reshape(-1,1)
        advantages = advantages.reshape(-1,1)

        train_obs.append(trajectory['obs'])
        train_actions.append(trajectory['actions'])
        train_actprobs.append(trajectory['actprobs'])
        train_advantages.append(advantages)
        train_discount_sum_rewards.append(discount_sum_rewards)

    train_advantages = np.array(train_advantages)
    train_discount_sum_rewards = np.array(train_discount_sum_rewards)
    # print("discount_rewards:",train_discount_sum_rewards[1])

    return np.concatenate(train_obs), np.concatenate(train_actions), np.concatenate(train_actprobs), \
           np.concatenate(train_advantages), np.concatenate(train_discount_sum_rewards)

def main():
    reward_save_name = "train_reward_record-all-1.xls"
    book_main = xlwt.Workbook(encoding='utf-8', style_compression=0)
    sheet = book_main.add_sheet("rewards", cell_overwrite_ok=True)
    k_last = 0
    try:
        book_read = xlrd.open_workbook(reward_save_name)#Order_test_case
    except:
        pass
    else:
        sheet1 = book_read.sheet_by_name('rewards')
        print "k_last:",sheet1.row_values(1, 0, 1)[0]
        k_last = int(sheet1.row_values(1, 0, 1)[0])
        mean_R = sheet1.col_values(1, 0, k_last)
        mean_S = sheet1.col_values(5, 0, k_last)
        train_Re = sheet1.col_values(11, 0, k_last)
        train_reward_last = train_Re[-1]
        for i in range(k_last):
            sheet.write(i, 1, mean_R[i])
            sheet.write(i, 5, mean_S[i])
            sheet.write(i, 11, train_Re[i])
    global MeanMaxMin
    env = EightPuzzleEnv()

    obs_dim = env.MageDim
    act_dim = env.ActionDim
    obs_length = env.Statelength

    # scaler = Scaler(obs_dim=obs_length, MeanMaxMin=MeanMaxMin)
    model = MujocoModel()
    alg = PPO(
        model,
        act_dim=act_dim,
        policy_lr=model.policy_lr,
        value_lr=model.value_lr)
    total_steps = 0
    eval_reward_0 = 0
    solutions_0_eval = 0
    agent = MujocoAgent(alg, obs_dim, act_dim, args.kl_targ, loss_type=args.loss_type, ini_logvar=0)
    # TnumL1, TDV1_left, TDS_num, TOCtank_ini, TOtank_ini, TDS1, TFOout = initOrder_train()
    # TnumL1, TDV1_left, TDS_num, TOCtank_ini, TOtank_ini, TDS1, TFOout = read_train_order()
    # AnumL1, ADV1_left, ADS_num, AOCtank_ini, AOtank_ini, ADS1, AFOout,_ = initOrder_test()
    AnumT, AnumL1, ADV1_left, ADS_num, AOCtank_ini, AOtank_ini, ADS1, AFOout = read_test_order()
    # AnumL1, ADV1_left, ADS_num, AOCtank_ini, AOtank_ini, ADS1, AFOout = exist_test_order()
    eval_reward_0, rewards_list, solutions_0_eval, solution_list = run_evaluate_episode(env, agent, AnumT, AnumL1, ADV1_left,
                                                             ADS_num, AOCtank_ini, AOtank_ini, ADS1, AFOout)#, scaler
    logger.info('Steps {},E_Mean reward: {}, Rewards list: {}, Mean solutions: {}, Solutions list: {}'.format(total_steps,
                                                                           eval_reward_0, rewards_list, solutions_0_eval, solution_list))
    sheet.write(0, 0, "epochs")
    sheet.write(0, 1, "m_Reward")
    sheet.write(0, 2, "Re_list")
    sheet.write(0, 8, "m_Solu")
    sheet.write(0, 9, "Solu_list")
    sheet.write(0, 15, "Best_Re")
    sheet.write(0, 16, "Best_So")
    sheet.write(0, 17, "train_Re")
    sheet.write(1, 15, eval_reward_0)
    sheet.write(1, 16, solutions_0_eval)
    test_flag = 0
    k_length = 3
    k = k_last
    k_best = k
    k_persistance = 0
    pp = 0
    k_persistance_freq = 4
    load_freq = 3
    load_flag = load_freq
    time_freq = 4
    time_flag = time_freq
    train_reward_0 = 1e10
    per = 0.05
    # train_reward_0 = 4.717
    # agent.save_best_program()
    # k_best = 38
    while total_steps < args.train_total_steps:
        T0 = time.time()
        trajectories = collect_trajectories(env, agent, args.episodes_per_batch)
                                            # ,TnumL1, TDV1_left, TDS_num, TOCtank_ini, TOtank_ini, TDS1, TFOout)   # scaler,
        total_steps += sum([t['obs'].shape[0] for t in trajectories])
        total_train_rewards = sum([np.sum(t['rewards']) for t in trajectories])

        train_obs, train_actions, train_actprobs, train_advantages, train_discount_sum_rewards = build_train_data(
            trajectories, agent)
        T1 = time.time()
        print "Time of build data:",T1-T0
        if pp >= 0:
            policy_loss, kl, all_A, all_pg, all_clppg, all_loss = agent.policy_learn(train_obs, train_actions, train_actprobs,
                                                 train_advantages)
        else:
            policy_loss = 1
            kl = 1
            all_A = 1
            all_pg = 1
            all_clppg = 1
            all_loss = 1
            pp += 1
        T2 = time.time()
        print "Time of train policy:",T2-T1
        if total_steps > 0 and total_steps // args.test_every_steps >= test_flag:
            print("all_A:",all_A)
            print("all_loss:",all_loss)
            print("all_pg:",all_pg)
            print("all_clppg:",all_clppg)
        value_loss = agent.value_learn(train_obs, train_discount_sum_rewards)
        T3 = time.time()
        print "Time of train value:",T3-T2
        train_reward = total_train_rewards / args.episodes_per_batch
        logger.info(
            'Steps {}, Epochs {},  Train reward: {}, Policy loss: {},  Value loss: {}'
            .format(total_steps, k, train_reward,
                    policy_loss,  value_loss))
        sheet.write(k+1, 17, train_reward)
        if total_steps // args.test_every_steps >= test_flag:
            # while total_steps // args.test_every_steps >= test_flag:
            # test_flag += 1
            eval_reward, rewards_list, solutions_eval, solution_list = run_evaluate_episode(env, agent, AnumT, AnumL1, ADV1_left,
                                                                     ADS_num, AOCtank_ini, AOtank_ini, ADS1, AFOout)#, scaler
            logger.info('Steps {}, Epochs {}, E_Mean reward: {}, Rewards list: {}, Mean solutions: {}, Solutions list: {}'.format(total_steps, k,
                                                                    eval_reward, rewards_list, solutions_eval, solution_list))
            sheet.write(k+1, 1, eval_reward)
            sheet.write(k+1, 2, rewards_list[0])
            sheet.write(k+1, 3, rewards_list[1])
            sheet.write(k+1, 4, rewards_list[2])
            sheet.write(k+1, 5, rewards_list[3])
            sheet.write(k+1, 6, rewards_list[4])
            sheet.write(k+1, 7, rewards_list[5])
            sheet.write(k+1, 8, solutions_eval)
            sheet.write(k+1, 9, solution_list[0])
            sheet.write(k+1, 10, solution_list[1])
            sheet.write(k+1, 11, solution_list[2])
            sheet.write(k+1, 12, solution_list[3])
            sheet.write(k+1, 13, solution_list[4])
            sheet.write(k+1, 14, solution_list[5])
        if k == 0:
            pass
        elif train_reward < train_reward_last:
            print "********* REWARD DECREASE ", k_persistance + 1, " TIMES CONTINUOUSLY! *********", \
                k_persistance_freq, "best,last,now:", np.round(train_reward_0, 3), np.round(train_reward_last, 3), \
                np.round(train_reward, 3), " best k:", k_best, " load_flag:", load_flag, [load_freq],\
                " time_flag:", time_flag, [time_freq]
            k_persistance += 1
            if k_persistance >= k_persistance_freq:
                load_flag = min(load_flag + 1, load_freq)
                k_persistance = 0
                print "********* REWARD CONTINUOUSLY DECREASE! load_flag +1! *********", \
                    "best,last,now:", np.round(train_reward_0, 3), np.round(train_reward_last, 3), \
                    np.round(train_reward, 3), " best k:", k_best, " load_flag:", load_flag, [load_freq],\
                    " time_flag:", time_flag, [time_freq]
        else:
            print "********* REWARD INCREASE! *********", "best,last,now:", np.round(train_reward_0, 3), \
                np.round(train_reward_last, 3), np.round(train_reward, 3), " best k:", k_best, " load_flag:", \
                load_flag, [load_freq], " time_flag:", time_flag, [time_freq]
            k_persistance = 0

        if train_reward < train_reward_0:
            agent.save_best_program()
            train_reward_0 = train_reward
            solutions_0_eval = solutions_eval
            eval_reward_0 = eval_reward
            load_flag = load_freq
            k_persistance = 0
            k_best = k
            time_flag = time_freq
            print "********* FOUND A CURRENT BEST POLICY! *********", k, train_reward_0
        else:
            time_flag -= 1
            if train_reward - train_reward_0 < train_reward_0 * per:
                load_flag = min(load_flag + 1, load_freq)
                print "********* Near best reward. load_flag +1. time_flag -1! *********", " best,last,now:", \
                    np.round(train_reward_0, 3), np.round(train_reward_last, 3), np.round(train_reward,3), " best k:", k_best, \
                    " load_flag:", load_flag, [load_freq], " time_flag:", time_flag, [time_freq]
            else:
                print "********* time_flag -1! *********", "reward_now - reward_best = :", \
                    train_reward - train_reward_0, " best,last,now:", np.round(train_reward_0, 3), \
                    np.round(train_reward_last, 3), np.round(train_reward, 3), " best k:", k_best, \
                    " load_flag:", load_flag, [load_freq], " time_flag:", time_flag, [time_freq]

        if time_flag <= 0:
            load_flag -= 1
            time_flag = time_freq
            print "********* load_flag -= 1 and time_flag = time_freq! *********"

        if load_flag <= 0:
            agent.load_program()
            load_flag = load_freq
            print "*** LOAD MODEL! ***", k, " best k:", k_best, "load_flag:", load_flag, "time_flag:", time_flag, \
                "best t_R:", train_reward_0
        T4 = time.time()
        print "Time of evaluation:", T4 - T3
        k += 1
        train_reward_last = train_reward
        if train_reward_0 < 5:
            per = 0.05
        if k % k_length == 0:
            agent.save_program()
            sheet.write(1, 0, k)
            sheet.write(1, 15, eval_reward_0)
            sheet.write(1, 16, solutions_0_eval)
            book_main.save(reward_save_name)
            print "FINISH SAVING THE RESULT!"

def main1():
    reward_save_name = "train_reward_record2.xls"
    book_main = xlwt.Workbook(encoding='utf-8', style_compression=0)
    sheet = book_main.add_sheet("rewards", cell_overwrite_ok=True)
    k_last = 0
    try:
        book_read = xlrd.open_workbook(reward_save_name)#Order_test_case
    except:
        pass
    else:
        sheet1 = book_read.sheet_by_name('rewards')
        print "k_last:",sheet1.row_values(1, 0, 1)[0]
        k_last = int(sheet1.row_values(1, 0, 1)[0])
        mean_R = sheet1.col_values(1, 0, k_last)
        mean_S = sheet1.col_values(5, 0, k_last)
        train_Re = sheet1.col_values(11, 0, k_last)
        for i in range(k_last):
            sheet.write(i, 1, mean_R[i])
            sheet.write(i, 5, mean_S[i])
            sheet.write(i, 11, train_Re[i])
    global MeanMaxMin
    env = EightPuzzleEnv()

    obs_dim = env.MageDim
    act_dim = env.ActionDim
    obs_length = env.Statelength

    # scaler = Scaler(obs_dim=obs_length, MeanMaxMin=MeanMaxMin)
    model = MujocoModel()
    alg = PPO(
        model,
        act_dim=act_dim,
        policy_lr=model.policy_lr,
        value_lr=model.value_lr)
    agent = MujocoAgent(alg, obs_dim, act_dim, args.kl_targ, loss_type=args.loss_type, ini_logvar=0)
    # TnumL1, TDV1_left, TDS_num, TOCtank_ini, TOtank_ini, TDS1, TFOout = initOrder_train()
    # TnumL1, TDV1_left, TDS_num, TOCtank_ini, TOtank_ini, TDS1, TFOout = read_train_order()
    # AnumT, AnumL1, ADV1_left, ADS_num, AOCtank_ini, AOtank_ini, ADS1, AFOout = initOrder_test()
    AnumT, AnumL1, ADV1_left, ADS_num, AOCtank_ini, AOtank_ini, ADS1, AFOout = read_test_order()
    # AnumL1, ADV1_left, ADS_num, AOCtank_ini, AOtank_ini, ADS1, AFOout = exist_test_order()
    test_flag = 0
    total_steps = 0
    eval_reward_0 = 0
    solutions_0 = 0
    # eval_reward_0, rewards_list, solutions_0, solution_list = run_evaluate_episode(env, agent, AnumT, AnumL1, ADV1_left,
    #                                                          ADS_num, AOCtank_ini, AOtank_ini, ADS1, AFOout)#, scaler
    # logger.info('Steps {}, E_Mean reward: {}, Rewards list: {}, Mean solutions: {}, Solutions list: {}'.format(total_steps,
    #                                                                        eval_reward_0, rewards_list, solutions_0, solution_list))
    sheet.write(0, 0, "epochs")
    sheet.write(0, 1, "m_Reward")
    sheet.write(0, 2, "Re_list")
    sheet.write(0, 8, "m_Solu")
    sheet.write(0, 9, "Solu_list")
    sheet.write(0, 15, "Best_Re")
    sheet.write(0, 16, "Best_So")
    sheet.write(0, 17, "train_Re")
    sheet.write(1, 15, eval_reward_0)
    sheet.write(1, 16, solutions_0)
    k_length = 3
    k = k_last
    pp = 0
    while total_steps < args.train_total_steps:
        T0 = time.time()
        trajectories = collect_trajectories(env, agent, args.episodes_per_batch)
                                            # ,TnumL1, TDV1_left, TDS_num, TOCtank_ini, TOtank_ini, TDS1, TFOout)   # scaler,
        total_steps += sum([t['obs'].shape[0] for t in trajectories])
        total_train_rewards = sum([np.sum(t['rewards']) for t in trajectories])

        train_obs, train_actions, train_actprobs, train_advantages, train_discount_sum_rewards = build_train_data(
            trajectories, agent)
        T1 = time.time()
        print "Time of build data:",T1-T0
        if pp >= 0:
            policy_loss, kl, all_A, all_pg, all_clppg, all_loss = agent.policy_learn(train_obs, train_actions, train_actprobs,
                                                 train_advantages)
        else:
            policy_loss = 1
            kl = 1
            all_A = 1
            all_pg = 1
            all_clppg = 1
            all_loss = 1
            pp += 1
        T2 = time.time()
        print "Time of train policy:",T2-T1
        if total_steps > 0 and total_steps // args.test_every_steps >= test_flag:
            print("all_A:",all_A)
            print("all_loss:",all_loss)
            print("all_pg:",all_pg)
            print("all_clppg:",all_clppg)
        value_loss = agent.value_learn(train_obs, train_discount_sum_rewards)
        T3 = time.time()
        print "Time of train value:",T3-T2
        logger.info(
            'Steps {}, Train reward: {}, Policy loss: {},  Value loss: {}'
            .format(total_steps, total_train_rewards / args.episodes_per_batch,
                    policy_loss,  value_loss))
        sheet.write(k+1, 17, total_train_rewards / args.episodes_per_batch)
        if total_steps // args.test_every_steps >= test_flag:
            # while total_steps // args.test_every_steps >= test_flag:
            # test_flag += 1
            eval_reward, rewards_list, solutions, solution_list = run_evaluate_episode(env, agent, AnumT, AnumL1, ADV1_left,
                                                                     ADS_num, AOCtank_ini, AOtank_ini, ADS1, AFOout)#, scaler
            logger.info('Steps {}, E_Mean reward: {}, Rewards list: {}, Mean solutions: {}, Solutions list: {}'.format(total_steps,
                                                                    eval_reward, rewards_list, solutions, solution_list))
            sheet.write(k+1, 1, eval_reward)
            sheet.write(k+1, 2, rewards_list[0])
            sheet.write(k+1, 3, rewards_list[1])
            sheet.write(k+1, 4, rewards_list[2])
            sheet.write(k+1, 5, rewards_list[3])
            sheet.write(k+1, 6, rewards_list[4])
            sheet.write(k+1, 7, rewards_list[5])
            sheet.write(k+1, 8, solutions)
            sheet.write(k+1, 9, solution_list[0])
            sheet.write(k+1, 10, solution_list[1])
            sheet.write(k+1, 11, solution_list[2])
            sheet.write(k+1, 12, solution_list[3])
            sheet.write(k+1, 13, solution_list[4])
            sheet.write(k+1, 14, solution_list[5])
            if eval_reward < eval_reward_0:
                agent.save_best_program()
                eval_reward_0 = eval_reward
                solutions_0 = solutions
            T4 = time.time()
            print "Time of evaluation:",T4-T3
        k += 1
        if k % k_length == 0:
            agent.save_program()
            sheet.write(1, 0, k)
            sheet.write(1, 15, eval_reward_0)
            sheet.write(1, 16, solutions_0)
            book_main.save(reward_save_name)
            print "FINISH SAVING THE RESULT!"

steps_one_episode = 2049
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '--env',
        type=str,
        help='Mujoco environment name',
        default='HalfCheetah-v2')
    parser.add_argument(
        '--gamma', type=float, help='Discount factor', default=0.995)
    parser.add_argument(
        '--lam',
        type=float,
        help='Lambda for Generalized Advantage Estimation',
        default=0.98)
    parser.add_argument(
        '--kl_targ', type=float, help='D_KL target value', default=0.003)
    parser.add_argument(
        '--episodes_per_batch',
        type=int,
        help='Number of episodes per training batch',
        default=27)
    parser.add_argument(
        '--loss_type',
        type=str,
        help="Choose loss type of PPO algorithm, 'CLIP' or 'KLPEN'",
        default='CLIP')
    parser.add_argument(
        '--train_total_steps',
        type=int,
        default=int(1e9),
        help='maximum training steps')
    parser.add_argument(
        '--test_every_steps',
        type=int,
        default=int(6e3),
        help='the step interval between two consecutive evaluations')

    args = parser.parse_args()

    main()
